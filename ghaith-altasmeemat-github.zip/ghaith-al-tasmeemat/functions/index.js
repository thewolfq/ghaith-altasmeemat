import { GoogleGenerativeAI } from '@google/generative-ai';
import { defineSecret } from 'firebase-functions/params';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { initializeApp } from 'firebase-admin/app';
initializeApp();
const GEMINI_API_KEY = defineSecret('GEMINI_API_KEY');
const MODEL = 'gemini-2.0-flash'; // غيّره إذا تغيّر اسم النموذج المتاح لحسابك
const safe = (v, max = 120) => String(v ?? '').replace(/[<>]/g, '').slice(0, max);

// قواعد تطابق المنقّي في التطبيق (templateUtils.js): أي شيء خارجها يُحذف عند العرض
const RULES = `قواعد إلزامية لكل قالب (يُنقّى في التطبيق وأي مخالفة تُحذف):
- المخرج: <style>…</style> ثم <div class="card"> بمقاس 540px عرض × 960px ارتفاع، position:relative و overflow:hidden و direction:rtl.
- الوسوم المسموحة فقط: div, p, span, strong, em, small, br, h1-h4, hr, section, ul, li, و svg بعناصر path, rect, circle, ellipse, line, polyline, polygon, g فقط.
- ممنوع: script, img, url(), @import, @font-face, filter, clip-path, defs, linearGradient, text داخل svg, رموز & و × بين الأسماء (استخدم زخرفة SVG).
- مسموح في CSS: linear-gradient و radial-gradient، transform، border-radius، box-shadow، position:absolute، z-index (رقم من خانتين فأقل).
- لمسة فنية بلا صور: ازرع زخارف SVG بطبقات شفافة (fill-opacity) وبتدرجات CSS، وأقواس وحلقات وأشكال عضوية؛ تجنّب التصميم الكلاسيكي المسطح القديم.
- الخطوط (تُحمَّل في التطبيق): Aref Ruqaa, Reem Kufi, El Messiri, Lalezar, Markazi Text, Amiri, Cairo, Tajawal.
- مكان صورة اختياري: <div data-image="photo" style="position:absolute;…;overflow:hidden;border-radius:…"></div> بلا محتوى.
- كل نص قابل للتعديل داخل span له data-field والنص بداخله هو القيمة الافتراضية. الحقول: kicker, message, weekday, day, month, time, venue، ومعها حسب المناسبة: زفاف/خطوبة groom و bride؛ مولود child و host؛ تخرج name و degree؛ ميلاد name و age؛ غير ذلك host. الحقول التالية data-required="true": الأسماء و day و venue.
- هوامش آمنة 36px على الأقل، توازن عمودي، الأسماء 40-56px، لا فراغات كبيرة.`;
const clean = (arr, n) => (Array.isArray(arr) ? arr : []).slice(0, n).filter((x) => x && typeof x.html === 'string' && x.html.length <= 16000 && x.html.includes('data-field')).map((x) => ({ title: safe(x.title, 70), style: safe(x.style, 70), html: x.html }));
const parseJson = (t) => JSON.parse(t.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, ''));
const gen = (key) => new GoogleGenerativeAI(key).getGenerativeModel({ model: MODEL, generationConfig: { temperature: 1.2, topP: 0.95 } });

export const generateInvitationTemplates = onCall({ region: 'us-central1', secrets: [GEMINI_API_KEY], enforceAppCheck: false }, async (request) => {
  if (!request.auth?.uid) throw new HttpsError('unauthenticated', 'يجب تسجيل الدخول قبل توليد القوالب.');
  const filters = Object.fromEntries(Object.entries(request.data?.filters || {}).slice(0, 13).map(([k, v]) => [safe(k, 30), safe(v, 80)]));
  const special = safe(request.data?.special, 400);
  const dirs = (Array.isArray(request.data?.directions) ? request.data.directions : []).slice(0, 6).map((d, i) => `${i + 1}) ${safe(d, 120)}`).join('\n');
  try {
    const prompt = `أنت مدير إبداعي لدعوات المناسبات العربية، أسلوبك عصري ومبتكر يشبه تصاميم Canva الحديثة لا القوالب القديمة. صمّم 6 قوالب مختلفة جذرياً في التركيب والألوان والزخرفة، كل قالب يتبع اتجاهه:\n${dirs || 'نوّع بحرية'}\n${RULES}\nأعد JSON صالحاً فقط: {"templates":[{"title":"اسم إبداعي","style":"وصف قصير","html":"..."}]}\nالتفضيلات: ${JSON.stringify(filters)}\nالحالة الخاصة: ${special || 'لا يوجد'}\nرقم عشوائي لتجنب التكرار: ${Math.random().toString(36).slice(2)}`;
    const r = await gen(GEMINI_API_KEY.value()).generateContent(prompt);
    const templates = clean(parseJson(r.response.text()).templates, 6);
    if (templates.length < 3) throw Error('Invalid model output');
    return { templates };
  } catch (error) { console.error('Gemini generation failed', error); throw new HttpsError('internal', 'تعذّر إنشاء القوالب الآن. حاول مرة أخرى لاحقاً.'); }
});

// «صمّم على غرار صورة»: يحلل الصورة المرجعية (ألوان، تخطيط، خط، عناصر) ثم يبتكر قوالب جديدة بنفس الروح لا نسخة منها
export const designFromReference = onCall({ region: 'us-central1', secrets: [GEMINI_API_KEY], enforceAppCheck: false, memory: '512MiB' }, async (request) => {
  if (!request.auth?.uid) throw new HttpsError('unauthenticated', 'يجب تسجيل الدخول.');
  const image = String(request.data?.image || ''), mime = /^image\/(jpeg|png|webp)$/.test(request.data?.mime) ? request.data.mime : 'image/jpeg';
  if (!image || image.length > 3_000_000 || !/^[A-Za-z0-9+/=]+$/.test(image)) throw new HttpsError('invalid-argument', 'الصورة غير صالحة أو كبيرة.');
  const filters = Object.fromEntries(Object.entries(request.data?.filters || {}).slice(0, 13).map(([k, v]) => [safe(k, 30), safe(v, 80)]));
  try {
    const prompt = `حلّل الصورة المرجعية لدعوة/بطاقة: لوحة الألوان، التخطيط والتوزيع، نوع الخط وحجمه، الزخارف، الأشكال (أقواس، حلقات، سحب…)، ومكان الصورة الفوتوغرافية إن وجدت. ثم صمّم 3 قوالب جديدة ومبتكرة بنفس الروح والمستوى البصري، ولا تنسخ النصوص ولا الصور ولا العلامات المائية، بل ابتكر صياغة وتفاصيل أصلية. ضع مكاناً للصورة data-image="photo" حيث كانت الصورة الفوتوغرافية.\n${RULES}\nأعد JSON صالحاً فقط: {"templates":[{"title":"...","style":"...","html":"..."}]}\nالتفضيلات: ${JSON.stringify(filters)}`;
    const r = await gen(GEMINI_API_KEY.value()).generateContent([{ inlineData: { data: image, mimeType: mime } }, { text: prompt }]);
    const templates = clean(parseJson(r.response.text()).templates, 3);
    if (!templates.length) throw Error('Invalid model output');
    return { templates };
  } catch (error) { console.error('Reference design failed', error); throw new HttpsError('internal', 'تعذّر التصميم من الصورة الآن.'); }
});
