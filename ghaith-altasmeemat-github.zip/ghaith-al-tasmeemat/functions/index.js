import { GoogleGenerativeAI } from '@google/generative-ai';
import { defineSecret } from 'firebase-functions/params';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { initializeApp } from 'firebase-admin/app';

initializeApp();
const GEMINI_API_KEY = defineSecret('GEMINI_API_KEY');
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.0-flash';
const REQUIRE_APP_CHECK = process.env.REQUIRE_APP_CHECK === 'true';
const HOURLY_LIMIT = Number(process.env.HOURLY_LIMIT || 24);

const hits = new Map();
function rateLimit(uid) {
  const now = Date.now(), win = 3600_000;
  const arr = (hits.get(uid) || []).filter((t) => now - t < win);
  if (arr.length >= HOURLY_LIMIT) throw new HttpsError('resource-exhausted', 'بلغت الحد المسموح للتوليد هذه الساعة. حاول لاحقاً.');
  arr.push(now); hits.set(uid, arr);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.some((t) => now - t < win)) hits.delete(k);
}
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
const safe = (v, max = 120) => String(v ?? '').replace(/[<>]/g, '').slice(0, max);

const RULES = `قواعد إلزامية لكل قالب (يُنقّى في التطبيق وأي مخالفة تُحذف):
- المخرج: <style>…</style> ثم <div class="card"> بمقاس 540px عرض × 960px ارتفاع، position:relative و overflow:hidden و direction:rtl.
- الوسوم المسموحة فقط: div, p, span, strong, em, small, br, h1-h4, hr, section, ul, li, و svg بعناصر path, rect, circle, ellipse, line, polyline, polygon, g و defs و linearGradient و radialGradient و stop (للتدرجات الذهبية: fill="url(#gd)" بعد تعريف gd داخل svg صغير 1px).
- حركة ظهور اختيارية داخل <style> فقط: @keyframes مع animation (opacity/transform فقط) وبأسماء قصيرة.
- لمكان حرفين مزخرفين (مونوغرام الزوجين) ضع <div data-mono="1" style="width:140px;height:140px"></div> وسيملؤه التطبيق بأول حرف من اسمي العروسين.
- ممنوع: script, img, url() في CSS, @import, @font-face, clip-path, text داخل svg.
- مسموح في CSS: linear-gradient و radial-gradient، transform، border-radius، box-shadow، position:absolute، z-index (رقم من خانتين فأقل).
- الخطوط (تُحمَّل في التطبيق): Aref Ruqaa, Reem Kufi, El Messiri, Lalezar, Markazi Text, Amiri, Cairo, Tajawal, Scheherazade New, Katibeh, Mirza.
- مكان صورة اختياري: <div data-image="photo" style="position:absolute;…;overflow:hidden;border-radius:…"></div> بلا محتوى.
- كل نص قابل للتعديل داخل span له data-field والنص بداخله هو القيمة الافتراضية. الحقول: kicker, message, weekday, day, month, time, venue، ومعها حسب المناسبة: زفاف/خطوبة groom و bride؛ مولود child و host؛ تخرج name و degree؛ ميلاد name و age؛ غير ذلك host. الحقول التالية data-required="true": الأسماء و day و venue.
- هوامش آمنة 36px على الأقل، توازن عمودي، الأسماء 40-56px، لا فراغات كبيرة.`;

const clean = (arr, n) => (Array.isArray(arr) ? arr : []).slice(0, n)
  .filter((x) => x && typeof x.html === 'string' && x.html.length <= 16000 && x.html.includes('data-field'))
  .map((x) => ({ title: safe(x.title, 70), style: safe(x.style, 70), html: x.html }));
const parseJson = (t) => JSON.parse(String(t).replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, ''));
const gen = (key) => new GoogleGenerativeAI(key).getGenerativeModel({ model: MODEL, generationConfig: { temperature: 1.15, topP: 0.95 } });
const cleanFilters = (raw) => Object.fromEntries(Object.entries(raw || {}).slice(0, 14).map(([k, v]) => [safe(k, 30), safe(typeof v === 'object' ? JSON.stringify(v) : v, 120)]));

export const generateInvitationTemplates = onCall(
  { region: 'us-central1', secrets: [GEMINI_API_KEY], enforceAppCheck: REQUIRE_APP_CHECK, timeoutSeconds: 60 },
  async (request) => {
    const uid = request.auth?.uid;
    if (!uid) throw new HttpsError('unauthenticated', 'يجب تسجيل الدخول قبل توليد القوالب.');
    rateLimit(uid);
    const filters = cleanFilters(request.data?.filters);
    const special = safe(request.data?.special, 400);
    const dirs = (Array.isArray(request.data?.directions) ? request.data.directions : []).slice(0, 6).map((d, i) => `${i + 1}) ${safe(d, 120)}`).join('\n');
    try {
      const prompt = `أنت مدير إبداعي لدعوات المناسبات العربية، أسلوبك عصري ومبتكر يشبه تصاميم Canva الحديثة لا القوالب القديمة. صمّم 6 قوالب مختلفة جذرياً في التركيب والألوان والزخرفة، كل قالب يتبع اتجاهه:
${dirs || 'نوّع بحرية'}
${RULES}
أعد JSON صالحاً فقط: {"templates":[{"title":"اسم إبداعي","style":"وصف قصير","html":"..."}]}
التفضيلات: ${JSON.stringify(filters)}
الحالة الخاصة: ${special || 'لا يوجد'}
رقم عشوائي لتجنب التكرار: ${Math.random().toString(36).slice(2)}`;
      const r = await withTimeout(gen(GEMINI_API_KEY.value()).generateContent(prompt), 45000);
      const templates = clean(parseJson(r.response.text()).templates, 6);
      if (templates.length < 3) throw Error('Invalid model output');
      return { templates };
    } catch (error) {
      console.error('Gemini generation failed', error);
      throw new HttpsError('internal', 'تعذّر إنشاء القوالب الآن. حاول مرة أخرى لاحقاً.');
    }
  }
);

export const designFromReference = onCall(
  { region: 'us-central1', secrets: [GEMINI_API_KEY], enforceAppCheck: REQUIRE_APP_CHECK, memory: '512MiB', timeoutSeconds: 90 },
  async (request) => {
    const uid = request.auth?.uid;
    if (!uid) throw new HttpsError('unauthenticated', 'يجب تسجيل الدخول.');
    rateLimit(uid);
    const image = String(request.data?.image || '');
    const mime = /^image\/(jpeg|png|webp)$/.test(request.data?.mime) ? request.data.mime : 'image/jpeg';
    if (!image || image.length > 3_000_000 || !/^[A-Za-z0-9+/=]+$/.test(image)) throw new HttpsError('invalid-argument', 'الصورة غير صالحة أو كبيرة.');
    const filters = cleanFilters(request.data?.filters);
    try {
      const prompt = `حلّل الصورة المرجعية لدعوة/بطاقة: لوحة الألوان، التخطيط والتوزيع، نوع الخط وحجمه، الزخارف، الأشكال (أقواس، حلقات، سحب…)، ومكان الصورة الفوتوغرافية إن وجدت. ثم صمّم 3 قوالب جديدة ومبتكرة بنفس الروح والمستوى البصري، ولا تنسخ النصوص ولا الصور ولا العلامات المائية، بل ابتكر صياغة وتفاصيل أصلية. ضع مكاناً للصورة data-image="photo" حيث كانت الصورة الفوتوغرافية.
${RULES}
أعد JSON صالحاً فقط: {"templates":[{"title":"...","style":"...","html":"..."}]}
التفضيلات: ${JSON.stringify(filters)}`;
      const r = await withTimeout(gen(GEMINI_API_KEY.value()).generateContent([{ inlineData: { data: image, mimeType: mime } }, { text: prompt }]), 70000);
      const templates = clean(parseJson(r.response.text()).templates, 3);
      if (!templates.length) throw Error('Invalid model output');
      return { templates };
    } catch (error) {
      console.error('Reference design failed', error);
      throw new HttpsError('internal', 'تعذّر التصميم من الصورة الآن.');
    }
  }
);
