import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base نسبي ليعمل البناء داخل Capacitor (WebView) وعلى أي مسار استضافة محلي.
export default defineConfig({
  base: './',
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,
  },
  preview: {
    host: '0.0.0.0',
    port: 4173,
    allowedHosts: true,
  },
  build: {
    outDir: 'dist',
    target: 'es2020',
    chunkSizeWarningLimit: 900,
    rollupOptions: {
      output: {
        manualChunks: {
          react: ['react', 'react-dom', 'react-router-dom'],
          data: ['dexie', 'jszip'],
        },
      },
    },
  },
});
