import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Package, KeyRound, HardDrive, LifeBuoy, AlertTriangle, Info, ChevronLeft, Eye, EyeOff, Loader2, PlugZap, Save, Trash2, List } from 'lucide-react';
import PacksCard from '../components/PacksCard.jsx';
import { PROVIDERS, getAiSettings, saveAiSettings, testConnection, listAvailableModels, getLastRequestUrl } from '../lib/ai.js';
import { restoreMissingBase, storageUsedBytes } from '../lib/assets.js';
import { wipeEverything, formatBytes, LIMITS, APP_VERSION } from '../lib/db.js';
import { useOnline } from '../lib/hooks.js';
import { useToast } from '../components/Toast.jsx';
import { useConfirm } from '../components/ConfirmDialog.jsx';

function Section({ n, icon: Icon, title, children, danger = false }) {
  return (
    <section className={`card-ui p-4 sm:p-5 ${danger ? 'border-red-200' : ''}`}>
      <h3 className={`flex items-center gap-2 font-extrabold mb-3 ${danger ? 'text-red-700' : 'text-ink'}`}>
        <span className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs ${danger ? 'bg-red-50' : 'bg-brand-soft text-brand'}`}>{n}</span>
        <Icon size={18} /> {title}
      </h3>
      {children}
    </section>
  );
}

function AiKeys() {
  const [s, setS] = useState(null);
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(null);
  const [fetched, setFetched] = useState({});
  const online = useOnline();
  const toast = useToast();
  useEffect(() => {
    getAiSettings().then(setS);
  }, []);
  if (!s) return <Loader2 className="animate-spin text-brand" />;
  const prov = PROVIDERS.find((p) => p.id === s.provider) || PROVIDERS[0];
  const upd = (patch) => setS((x) => ({ ...x, ...patch }));
  const key = s.keys[prov.id] || '';
  const save = async () => {
    setBusy('save');
    await saveAiSettings(s);
    setBusy(null);
    toast('حُفظت إعدادات الذكاء الاصطناعي محلياً');
  };
  const test = async () => {
    setBusy('test');
    await saveAiSettings(s);
    try {
      await testConnection();
      toast('الاتصال ناجح — الميزات السحابية مفعلة');
    } catch (e) {
      toast(`فشل الاختبار: ${e.message}${getLastRequestUrl() ? ` [${getLastRequestUrl()}]` : ''}`, 'error', 9000);
    } finally {
      setBusy(null);
    }
  };
  const fetchModels = async () => {
    setBusy('models');
    await saveAiSettings(s);
    try {
      const list = await listAvailableModels();
      setFetched((f) => ({ ...f, [prov.id]: list }));
      toast(list.length ? `تم جلب ${list.length} نموذجاً متاحاً لمفتاحك — اختاري من القائمة` : 'لم يُرجع المزود أي نماذج', list.length ? 'success' : 'info', 4000);
    } catch (e) {
      toast(`تعذر جلب النماذج: ${e.message}${getLastRequestUrl() ? ` [${getLastRequestUrl()}]` : ''}`, 'error', 9000);
    } finally {
      setBusy(null);
    }
  };
  const modelOptions = [...new Set([...(fetched[prov.id] || []), ...prov.models])];
  const clear = async () => {
    const next = { ...s, keys: { ...s.keys, [prov.id]: '' } };
    setS(next);
    await saveAiSettings(next);
    toast('حُذف المفتاح — كل الميزات تعمل محلياً', 'info');
  };
  return (
    <div className="space-y-3">
      <p className="text-xs text-ink-mute leading-6">اختياري تماماً. بدون مفتاح يعمل كل شيء محلياً. المفتاح يُحفظ على هذا الجهاز فقط ويُستخدم للاتصال المباشر بالمزود لفتح: التوليد السحابي الإضافي، الاستنساخ الكامل بالرؤية، ومساعدة الفيديو النصية.</p>
      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <label className="label" htmlFor="prov">
            المزود
          </label>
          <select id="prov" className="input" value={s.provider} onChange={(e) => upd({ provider: e.target.value })}>
            {PROVIDERS.map((p) => (
              <option key={p.id} value={p.id}>
                {p.label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="model">
            النموذج
          </label>
          <input id="model" className="input" dir="ltr" list="models" value={s.models[prov.id] || ''} onChange={(e) => upd({ models: { ...s.models, [prov.id]: e.target.value.trim() } })} placeholder={prov.defaultModel} />
          <datalist id="models">
            {modelOptions.map((m) => (
              <option key={m} value={m} />
            ))}
          </datalist>
        </div>
      </div>
      {prov.needsBase && (
        <div>
          <label className="label" htmlFor="base">
            عنوان الواجهة (Base URL — HTTPS)
          </label>
          <input id="base" className="input" dir="ltr" value={s.baseUrls[prov.id] || ''} onChange={(e) => upd({ baseUrls: { ...s.baseUrls, [prov.id]: e.target.value.trim() } })} placeholder={prov.defaultBase} />
        </div>
      )}
      <div>
        <label className="label" htmlFor="key">
          مفتاح API
        </label>
        <div className="flex gap-2">
          <input id="key" className="input flex-1" dir="ltr" type={show ? 'text' : 'password'} autoComplete="off" value={key} onChange={(e) => upd({ keys: { ...s.keys, [prov.id]: e.target.value.trim() } })} placeholder="الصقي المفتاح هنا" />
          <button className="btn-icon border border-[#e3ebe7] bg-white" onClick={() => setShow((v) => !v)} aria-label={show ? 'إخفاء' : 'إظهار'}>
            {show ? <EyeOff size={17} /> : <Eye size={17} />}
          </button>
        </div>
      </div>
      <label className="flex items-center gap-2 text-xs font-semibold text-ink-soft">
        <input type="checkbox" className="accent-[#0f766e] w-4 h-4" checked={!!s.cloudExplore} onChange={(e) => upd({ cloudExplore: e.target.checked })} />
        تفعيل خيار التوليد السحابي في الاستكشاف افتراضياً (حتى 6 قوالب إضافية)
      </label>
      <div className="flex flex-wrap gap-2 items-center">
        <button className="btn-primary" onClick={save} disabled={!!busy}>
          {busy === 'save' ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} حفظ
        </button>
        <button className="btn-outline" onClick={test} disabled={!!busy || !key || !online}>
          {busy === 'test' ? <Loader2 size={16} className="animate-spin" /> : <PlugZap size={16} />} اختبار الاتصال
        </button>
        <button className="btn-outline" onClick={fetchModels} disabled={!!busy || !key || !online}>
          {busy === 'models' ? <Loader2 size={16} className="animate-spin" /> : <List size={16} />} جلب النماذج المتاحة
        </button>
        {key && (
          <button className="btn-ghost text-red-600" onClick={clear}>
            <Trash2 size={15} /> حذف المفتاح
          </button>
        )}
        <span className={`text-[11px] rounded-full px-2 py-0.5 ${key && online ? 'bg-brand-soft text-brand-dark' : 'bg-canvas text-ink-mute'}`}>{key ? (online ? 'السحابي متاح' : 'غير متصل — محلي') : 'محلي بالكامل'}</span>
      </div>
    </div>
  );
}

export default function SettingsScreen() {
  const toast = useToast();
  const confirm = useConfirm();
  const [used, setUsed] = useState(null);
  const [restoring, setRestoring] = useState(false);

  useEffect(() => {
    storageUsedBytes().then(setUsed).catch(() => setUsed(null));
  }, []);

  const restore = async () => {
    setRestoring(true);
    try {
      const r = await restoreMissingBase();
      const total = r.fonts + r.ornaments + r.templates;
      toast(total ? `أُعيد: ${r.fonts} خط، ${r.ornaments} زخرفة، ${r.templates} قالب${r.failed.length ? ` (تعذر ${r.failed.length})` : ''}` : 'كل الأصول الأساسية موجودة — لا شيء مفقود', total ? 'success' : 'info', 4500);
    } catch (e) {
      toast(`تعذرت الاستعادة: ${e.message}`, 'error');
    } finally {
      setRestoring(false);
    }
  };

  const reset = async () => {
    const ok = await confirm({
      title: 'إعادة الضبط الشامل',
      message: 'سيُمسح كل شيء نهائياً: القوالب، الخطوط، الزخارف، الحزم، الدعوات، المفضلة، الإعدادات، المفاتيح، الكاش، وعلامة أول فتح. يعود التطبيق لحالة أول تثبيت.',
      confirmText: 'مسح كل شيء',
      danger: true,
      doubleConfirm: true,
      typeWord: 'مسح',
    });
    if (!ok) return;
    try {
      await wipeEverything();
    } finally {
      window.location.hash = '#/';
      window.location.reload();
    }
  };

  return (
    <div className="space-y-4 max-w-3xl">
      <Section n="1" icon={Package} title="حزم القوالب">
        <PacksCard />
      </Section>
      <Section n="2" icon={KeyRound} title="مفاتيح الذكاء الاصطناعي">
        <AiKeys />
      </Section>
      <Section n="3" icon={HardDrive} title="إدارة التخزين">
        <Link to="/storage" className="flex items-center gap-3 rounded-xl bg-canvas p-3 hover:bg-canvas-deep transition">
          <div className="flex-1">
            <div className="font-bold text-sm">عرض الأحجام والحذف الانتقائي</div>
            <div className="text-xs text-ink-mute">{used == null ? 'جارٍ الحساب…' : `المستخدم ${formatBytes(used)} من ${formatBytes(LIMITS.budgetBytes)}`}</div>
          </div>
          <ChevronLeft size={18} className="text-ink-mute" />
        </Link>
      </Section>
      <Section n="4" icon={LifeBuoy} title="استعادة الأصول الأساسية المفقودة">
        <p className="text-xs text-ink-mute mb-3 leading-6">يعيد فقط ما حُذف من الخطوط والزخارف والقوالب المدمجة، دون المساس بالدعوات أو المفضلة أو الحزم أو القوالب المحملة أو الإعدادات والمفاتيح.</p>
        <button className="btn-soft" onClick={restore} disabled={restoring}>
          {restoring ? <Loader2 size={16} className="animate-spin" /> : <LifeBuoy size={16} />} استعادة المفقود
        </button>
      </Section>
      <Section n="5" icon={AlertTriangle} title="إعادة الضبط الشامل" danger>
        <p className="text-xs text-ink-mute mb-3 leading-6">يتطلب تأكيداً مزدوجاً وكتابة كلمة «مسح». لا يحذف التطبيق نفسه ولا أي ملفات خارج ذاكرته (مثل الملفات المصدّرة).</p>
        <button className="btn-danger" onClick={reset}>
          <AlertTriangle size={16} /> مسح كل البيانات
        </button>
      </Section>
      <Section n="6" icon={Info} title="عن التطبيق">
        <Link to="/about" className="flex items-center gap-3 rounded-xl bg-canvas p-3 hover:bg-canvas-deep transition">
          <div className="flex-1">
            <div className="font-bold text-sm">غيث التصميمات — الإصدار {APP_VERSION}</div>
            <div className="text-xs text-ink-mute">المطور: عبدالوارث الذيب</div>
          </div>
          <ChevronLeft size={18} className="text-ink-mute" />
        </Link>
      </Section>
    </div>
  );
}
