import { useEffect, useState } from 'react';
import { Sparkles, WandSparkles, ImagePlus, Info, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { TemplateCard } from '../components/TemplateCard.jsx';
import { db, storeTemplates, toggleFavorite } from '../lib/db.js';
import { generateTemplates, designFromReference } from '../lib/ai.js';

const filters = [
  { key: 'occasion', label: 'المناسبة', options: ['زفاف', 'خطوبة', 'تخرج', 'مولود جديد', 'عيد ميلاد', 'عشاء', 'مناسبة سعيدة'] },
  { key: 'inviterGender', label: 'جنس مقدم الدعوة', options: ['غير محدد', 'العريس', 'العروس', 'العائلتان', 'الأصدقاء'] },
  { key: 'namesCount', label: 'عدد الأسماء', options: ['اسم واحد', 'اسمان', 'ثلاثة أسماء', 'أكثر من ثلاثة'] },
  { key: 'colors', label: 'الألوان', options: ['زمردي', 'وردي', 'ذهبي', 'أزرق', 'بنفسجي', 'محايد'] },
  { key: 'ornaments', label: 'الزخارف', options: ['نباتية', 'هندسية', 'ورود', 'هلال ونجوم', 'بلا زخارف'] },
  { key: 'style', label: 'أسلوب التصميم', options: ['كلاسيكي', 'عصري', 'ملكي', 'بسيط', 'تراثي'] },
  { key: 'formality', label: 'طابع الدعوة', options: ['رسمي', 'ودّي', 'عائلي', 'فاخر'] },
  { key: 'language', label: 'لغة النص', options: ['العربية الفصحى', 'لهجة محلية', 'عربي وإنجليزي'] },
  { key: 'layout', label: 'التخطيط', options: ['عمودي', 'مربع', 'بطاقة صغيرة', 'أفقي'] },
  { key: 'season', label: 'الموسم', options: ['الربيع', 'الصيف', 'الخريف', 'الشتاء', 'طوال العام'] },
  { key: 'venue', label: 'مكان المناسبة', options: ['قاعة', 'منزل', 'حديقة', 'فندق', 'غير محدد'] },
  { key: 'relationship', label: 'صلة مقدم الدعوة', options: ['العائلة', 'الأصدقاء', 'الزوجان', 'جهة عمل'] },
  { key: 'detailLevel', label: 'مستوى التفاصيل', options: ['مختصر', 'متوازن', 'مفصل'] },
];

export function ExploreScreen() {
  const navigate = useNavigate();
  const [values, setValues] = useState({}), [special, setSpecial] = useState(''), [templates, setTemplates] = useState([]);
  const [busy, setBusy] = useState(false), [message, setMessage] = useState(''), [favIds, setFavIds] = useState(new Set());
  const [visible, setVisible] = useState(12), [dirty, setDirty] = useState(false), [help, setHelp] = useState(false);
  const [swatches, setSwatches] = useState(null);

  useEffect(() => { db.favorites.toArray().then((items) => setFavIds(new Set(items.map((x) => x.templateId)))); }, []);
  useEffect(() => { refresh({}, true); /* توليد أولي مرة واحدة */ }, []);

  async function refresh(vals = values, localOnly = false) {
    setBusy(true); setMessage(''); setVisible(12); setDirty(false); setSwatches(null);
    try {
      const result = await generateTemplates(vals, special, { localOnly });
      setTemplates(result.templates);
      await db.templates.clear();
      await storeTemplates(result.templates);
      setMessage(result.relaxed ? 'لا توجد قوالب بهذا التخطيط لمناسبتك بعد، فعرضنا لك أقرب التصاميم.' : result.simulated
        ? `جُهّز ${result.templates.length} تصميماً حسب اختياراتك. اضغط «تحديث القوالب» لترتيب مختلف.` : 'تم توليد القوالب بنجاح.');
    } catch (e) { setMessage(e.message || 'تعذّر إنشاء القوالب.'); }
    finally { setBusy(false); }
  }
  function setFilter(key, v) { setValues((o) => ({ ...o, [key]: v })); setDirty(true); }

  async function fromImage(ev) {
    const f = ev.target.files?.[0]; ev.target.value = '';
    if (!f) return;
    setBusy(true); setMessage('');
    try {
      const r = await designFromReference(f, values);
      setSwatches(r.swatches); setVisible(12);
      setTemplates((old) => [...r.templates, ...old.filter((t) => !r.templates.some((n) => n.id === t.id))]);
      await storeTemplates(r.templates);
      setMessage(r.cloud ? `صُمّمت ${r.templates.length} قوالب على غرار صورتك (بتحليل الذكاء الاصطناعي وبألوانها).` : `صُمّمت ${r.templates.length} قوالب بألوان صورتك ودرجة إضاءتها، وهي أول القائمة.`);
      window.scrollTo?.({ top: document.querySelector('.template-grid')?.offsetTop - 80 || 0, behavior: 'smooth' });
    } catch { setMessage('تعذّر قراءة الصورة. جرّب صورة أخرى (JPG أو PNG).'); }
    finally { setBusy(false); }
  }
  async function favorite(template) {
    try {
      const added = await toggleFavorite(template);
      setFavIds((old) => { const n = new Set(old); added ? n.add(template.id) : n.delete(template.id); return n; });
    } catch (e) { setMessage(e.message); }
  }

  return (
    <div className="page-stack">
      <div className="page-intro"><span className="eyebrow">مصممة على ذوقك</span><h2>اكتشف قالبك القادم</h2>
        <p>اختر التفاصيل التي تهمك، ثم اضغط «تحديث القوالب» لتوليد اقتراحات جديدة.</p></div>

      <section className="filter-panel">
        <div className="filter-title"><div className="section-icon"><Sparkles size={18} /></div>
          <div><h3>خصّص البحث</h3><p>13 خياراً لتقريب النتيجة إلى ذوقك</p></div></div>
        <div className="filters-grid">
          {filters.map(({ key, label, options }) => (
            <label className="field" key={key}><span>{label}</span>
              <select value={values[key] || ''} onChange={(e) => setFilter(key, e.target.value)}>
                <option value="">اختر {label}</option>
                {options.map((opt) => <option key={opt}>{opt}</option>)}
              </select>
            </label>
          ))}
        </div>
        <label className="field special-field"><span>حالة خاصة <small>اختياري</small></span>
          <textarea value={special} onChange={(e) => { setSpecial(e.target.value); setDirty(true); }} rows="2" placeholder="مثال: الدعوة ستكون في الهواء الطلق ونرغب بعبارة دافئة…" /></label>

        {swatches && <div className="palette-strip"><span>ألوان صورتك:</span>{swatches.map((c) => <i key={c} style={{ background: c }} title={c} />)}</div>}

        <div className="filter-submit">
          <p>{dirty ? 'غيّرت الاختيارات — اضغط «تحديث القوالب» لتطبيقها.' : 'أرفق صورة دعوة تعجبك لنصمّم لك قوالب بألوانها.'}</p>
          <div className="submit-actions">
            <button type="button" className="button button-outline button-sm" onClick={() => setHelp(true)}><Info size={15} /> كيف يعمل؟</button>
            <label className="button button-outline" style={{ cursor: 'pointer' }}>
              <ImagePlus size={16} /> صمّم على غرار صورة
              <input type="file" accept="image/*" hidden onChange={fromImage} />
            </label>
            <button className={`button button-primary ${dirty ? 'is-dirty' : ''}`} onClick={() => refresh()} disabled={busy}>
              <WandSparkles size={17} />{busy ? 'جارٍ تجهيز قوالبك…' : '✨ تحديث القوالب'}
            </button>
          </div>
        </div>
      </section>

      {help && (
        <div className="modal-scrim" role="dialog" aria-modal="true" onClick={() => setHelp(false)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setHelp(false)} aria-label="إغلاق"><X size={18} /></button>
            <h3>صمّم على غرار صورة</h3>
            <p>اختر أي صورة دعوة أو بطاقة تعجبك. يقرأ التطبيق <b>ألوانها وإضاءتها داخل جهازك بدون إنترنت</b> ثم يبني قوالب جديدة بها فوراً، وتظهر في أول القائمة.</p>
            <p className="modal-note">إن فعّلت خدمة Gemini السحابية يضيف التطبيق إليها قوالب يحلّل فيها الذكاء الاصطناعي تخطيط الصورة وزخارفها أيضاً. لا ننسخ نصوص الصورة ولا عناصرها.</p>
          </div>
        </div>
      )}

      {message && <div className="alert alert-info">{message}</div>}

      {templates.length > 0 && (
        <section>
          <div className="section-heading"><div><span className="eyebrow">اقتراحات غيث</span><h2>{templates.length} قالباً جاهزاً لك</h2></div></div>
          <div className="template-grid">
            {templates.slice(0, visible).map((t) => (
              <TemplateCard key={t.id} template={t} favorite={favIds.has(t.id)} onFavorite={() => favorite(t)} onUse={() => navigate(`/fill/${t.id}`)} />
            ))}
          </div>
          {templates.length > visible && (
            <button className="button button-outline" style={{ width: '100%', marginTop: 16 }} onClick={() => setVisible((v) => v + 12)}>عرض المزيد ({templates.length - visible} قالباً متبقياً)</button>
          )}
        </section>
      )}
      {!templates.length && !busy && (
        <div className="empty-state"><div className="empty-icon"><Sparkles /></div><h3>تصميمك يبدأ بخطوة</h3><p>أخبرنا بتفاصيل مناسبتك ثم اضغط «تحديث القوالب».</p></div>
      )}
    </div>
  );
}
