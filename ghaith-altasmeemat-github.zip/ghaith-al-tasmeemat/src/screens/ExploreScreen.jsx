import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { SlidersHorizontal, RefreshCw, ChevronDown, Cloud, WandSparkles, X, Loader2, SearchX } from 'lucide-react';
import { FILTER_DEFS, DEFAULT_FILTERS, newSeed, TAG_KEYS } from '../lib/tplKit.js';
import { generateBatch, recordShown, cloudGenerate, getAiSettings } from '../lib/ai.js';
import { db } from '../lib/db.js';
import { useOnline } from '../lib/hooks.js';
import TemplateCard from '../components/TemplateCard.jsx';
import { useToast } from '../components/Toast.jsx';

const SS_KEY = 'gh_explore_state';
const BATCH = 12;

function loadState() {
  try {
    return JSON.parse(sessionStorage.getItem(SS_KEY) || 'null');
  } catch {
    return null;
  }
}

export default function ExploreScreen() {
  const saved = useMemo(loadState, []);
  const [filters, setFilters] = useState(saved?.filters || DEFAULT_FILTERS);
  const [special, setSpecial] = useState(saved?.special || '');
  const [list, setList] = useState(saved?.list || null);
  const [shown, setShown] = useState(saved?.shown || BATCH);
  const [seed, setSeed] = useState(saved?.seed || 0);
  const [mode, setMode] = useState(saved?.mode || 'stored');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [panelOpen, setPanelOpen] = useState(!saved);
  const [useCloud, setUseCloud] = useState(false);
  const [hasKey, setHasKey] = useState(false);
  const [cloudNote, setCloudNote] = useState('');
  const online = useOnline();
  const toast = useToast();

  useEffect(() => {
    getAiSettings().then((s) => {
      const k = !!(s.keys[s.provider] || '').trim();
      setHasKey(k);
      setUseCloud(k && s.cloudExplore);
    });
  }, []);

  useEffect(() => {
    try {
      sessionStorage.setItem(SS_KEY, JSON.stringify({ filters, special, list, shown, seed, mode }));
    } catch {
      /* مساحة الجلسة ممتلئة — نتجاهل */
    }
  }, [filters, special, list, shown, seed, mode]);

  // العرض الأولي: القوالب المخزنة المطابقة فقط (بلا توليد تلقائي)
  useEffect(() => {
    if (list) return;
    (async () => {
      try {
        const all = await db.templates.toArray();
        setList(all.filter((t) => matches(t, filters)));
        setMode('stored');
      } catch (e) {
        setError(e);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const activeCount = Object.values(filters).filter(Boolean).length;

  const toggle = (key, opt) => setFilters((f) => ({ ...f, [key]: f[key] === opt ? undefined : opt }));

  const refresh = async () => {
    setLoading(true);
    setError(null);
    setCloudNote('');
    await new Promise((r) => setTimeout(r, 30));
    try {
      const s = newSeed();
      let batch = await generateBatch(filters, { special, seed: s });
      if (useCloud && hasKey && online) {
        const cloud = await cloudGenerate(filters, { special, userRequest: special, count: 6 });
        if (cloud.length) {
          batch = [...cloud, ...batch];
          setCloudNote(`أُضيف ${cloud.length} قالب من التوليد السحابي`);
        } else setCloudNote('تعذر التوليد السحابي — عُرضت النتائج المحلية');
      }
      setSeed(s);
      setList(batch);
      setShown(BATCH);
      setMode('generated');
      recordShown(batch.slice(0, BATCH));
      setPanelOpen(false);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  };

  const more = async () => {
    const next = shown + BATCH;
    if (list && next <= list.length + BATCH && list.length >= next) {
      setShown(next);
      recordShown(list.slice(shown, next));
      return;
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 30));
    try {
      const s = (seed || newSeed()) + 977 + list.length;
      const batch = await generateBatch(filters, { special, seed: s, includeStored: false });
      const ids = new Set(list.map((t) => t.id));
      const merged = [...list, ...batch.filter((t) => !ids.has(t.id))];
      setList(merged);
      setSeed(s);
      setShown(next);
      setMode('generated');
      recordShown(merged.slice(shown, next));
    } catch (e) {
      toast(e.message || 'تعذر توليد المزيد', 'error');
    } finally {
      setLoading(false);
    }
  };

  const visible = (list || []).slice(0, shown);

  return (
    <div className="space-y-4">
      <div className="card-ui p-4">
        <button className="w-full flex items-center gap-2" onClick={() => setPanelOpen((v) => !v)} aria-expanded={panelOpen}>
          <SlidersHorizontal size={18} className="text-brand" />
          <span className="font-bold text-ink">الفلاتر</span>
          <span className="text-xs text-ink-mute">({activeCount} مفعّل من 13)</span>
          <ChevronDown size={18} className={`mr-auto transition ${panelOpen ? 'rotate-180' : ''}`} />
        </button>

        {panelOpen && (
          <div className="mt-4 space-y-3.5">
            {FILTER_DEFS.map((def, i) => (
              <div key={def.key}>
                <div className="label">
                  {i + 1}. {def.label}
                </div>
                <div className="scroll-x">
                  {def.options.map((opt) => (
                    <button key={opt} className={filters[def.key] === opt ? 'chip-on' : 'chip-off'} onClick={() => toggle(def.key, opt)}>
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            ))}
            <div>
              <label className="label" htmlFor="special">
                حالة خاصة (وصف حر لظرف أو ذوق إضافي)
              </label>
              <textarea id="special" className="input min-h-[70px]" value={special} onChange={(e) => setSpecial(e.target.value)} placeholder="مثال: ألوان كحلي وذهبي، ورود بيضاء، بدون آية، مع مونوغرام الحرفين" />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {activeCount > 0 && (
                <button className="btn-ghost text-xs" onClick={() => setFilters({})}>
                  <X size={14} /> مسح الفلاتر
                </button>
              )}
              {hasKey && (
                <label className={`flex items-center gap-2 text-xs font-semibold ${online ? 'text-ink-soft' : 'text-ink-mute'}`}>
                  <input type="checkbox" className="accent-[#0f766e] w-4 h-4" checked={useCloud} disabled={!online} onChange={(e) => setUseCloud(e.target.checked)} />
                  <Cloud size={14} /> توليد سحابي إضافي (حتى 6) {online ? '' : '— غير متصل'}
                </label>
              )}
            </div>
          </div>
        )}

        <div className="mt-4 flex flex-wrap gap-2">
          <button className="btn-primary flex-1 sm:flex-none" onClick={refresh} disabled={loading}>
            {loading ? <Loader2 size={18} className="animate-spin" /> : <RefreshCw size={18} />} تحديث / توليد
          </button>
          <Link to="/clone" className="btn-outline">
            <WandSparkles size={18} /> استنساخ من صورة
          </Link>
        </div>
        <p className="text-[11px] text-ink-mute mt-2">كل ضغطة تعيد خلطاً عشوائياً جديداً مع ترشيح الأفضل المطابق — لا يوجد تحديث تلقائي.</p>
      </div>

      {cloudNote && <div className="text-xs text-brand-dark bg-brand-soft rounded-xl px-3 py-2">{cloudNote}</div>}
      {error && <div className="card-ui p-4 text-sm text-red-700">حدث خطأ: {error.message}</div>}

      <div className="flex items-center justify-between">
        <h3 className="section-title">{mode === 'stored' ? 'القوالب المخزنة المطابقة' : 'نتائج التوليد المرشّحة'}</h3>
        {list && <span className="text-xs text-ink-mute">{Math.min(shown, list.length)} من {list.length}</span>}
      </div>

      {!list ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {Array.from({ length: 8 }, (_, i) => (
            <div key={i} className="rounded-2xl skeleton" style={{ aspectRatio: '540/1100' }} />
          ))}
        </div>
      ) : list.length === 0 ? (
        <div className="card-ui p-8 text-center">
          <SearchX className="mx-auto text-ink-mute" size={32} />
          <p className="muted mt-2">لا توجد قوالب مخزنة مطابقة لهذه الفلاتر.</p>
          <button className="btn-primary mt-3" onClick={refresh} disabled={loading}>
            <RefreshCw size={16} /> ولّدي قوالب مطابقة الآن
          </button>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {visible.map((t) => (
              <TemplateCard key={t.id} template={t} />
            ))}
          </div>
          <div className="flex justify-center pt-2">
            <button className="btn-outline" onClick={more} disabled={loading}>
              {loading ? <Loader2 size={16} className="animate-spin" /> : null} عرض المزيد (+{BATCH})
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function matches(t, filters) {
  return TAG_KEYS.every((k) => !filters[k] || !t.tags?.[k] || t.tags[k] === filters[k]);
}
