import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { LifeBuoy, Loader2, RefreshCw, AlertTriangle } from 'lucide-react';
import { computeStorage, restoreMissingBase } from '../lib/assets.js';
import { useAsync } from '../lib/hooks.js';
import { useAppData } from '../components/AppData.jsx';
import { useToast } from '../components/Toast.jsx';
import StorageManager, { StorageBar } from '../components/StorageManager.jsx';

export default function StorageScreen() {
  const { bump } = useAppData();
  const { loading, error, data, reload } = useAsync(computeStorage, []);
  const [restoring, setRestoring] = useState(false);
  const toast = useToast();

  const changed = () => {
    bump();
    reload();
  };

  const restore = async () => {
    setRestoring(true);
    try {
      const r = await restoreMissingBase();
      const total = r.fonts + r.ornaments + r.templates;
      toast(total ? `أُعيد: ${r.fonts} خط، ${r.ornaments} زخرفة، ${r.templates} قالب` : 'لا توجد أصول أساسية مفقودة', total ? 'success' : 'info');
      changed();
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setRestoring(false);
    }
  };

  return (
    <div className="max-w-3xl space-y-4">
      <div className="card-ui p-5">
        {data ? <StorageBar total={data.total} budget={data.budget} /> : <div className="h-16 skeleton rounded-xl" />}
        <div className="flex flex-wrap gap-2 mt-4">
          <button className="btn-soft" onClick={restore} disabled={restoring}>
            {restoring ? <Loader2 size={16} className="animate-spin" /> : <LifeBuoy size={16} />} استعادة الأصول الأساسية المفقودة
          </button>
          <button className="btn-ghost" onClick={reload} disabled={loading}>
            <RefreshCw size={16} className={loading ? 'animate-spin' : ''} /> إعادة الحساب
          </button>
        </div>
        <p className="text-[11px] text-ink-mute mt-2 leading-5">الاستعادة تعيد فقط الخطوط والزخارف والقوالب المدمجة الناقصة، دون لمس الدعوات أو المفضلة أو الحزم أو الإعدادات.</p>
      </div>
      {error && <div className="card-ui p-4 text-red-700 text-sm">تعذر حساب التخزين: {error.message}</div>}
      {data && <StorageManager data={data} onChanged={changed} />}
      <Link to="/settings" className="card-ui p-4 flex items-center gap-3 text-red-700 hover:bg-red-50/40 transition">
        <AlertTriangle size={18} />
        <span className="text-sm font-semibold flex-1">إعادة الضبط الشامل موجودة في أسفل الإعدادات</span>
      </Link>
    </div>
  );
}
