import React from 'react';
import { Sparkles, ShieldCheck, Palette, Layers, Film, WifiOff, Package, Heart } from 'lucide-react';
import { APP_NAME, APP_VERSION, DEVELOPER } from '../lib/db.js';
import { Logo } from '../components/AppLayout.jsx';

const FEATURES = [
  { icon: Sparkles, title: 'توليد ذكي محلي', text: 'محركات تصميم فاخرة وإبداعية وزهرية ومرجعية تنتج دفعات متجددة مطابقة لفلاترك دون إنترنت.' },
  { icon: Layers, title: 'محرر بمسارين', text: 'تحرير مبسط سريع، أو تحرير كامل بستة تبويبات معزولة مع تراجع وإعادة مركزيين وتنسيق تلقائي.' },
  { icon: Palette, title: 'مونوغرام وخطوط عربية', text: 'ست عائلات خطوط للحروف الأولى بأنماط تشابك متعددة، و11 خطاً عربياً للقوالب.' },
  { icon: Film, title: 'تصدير محلي', text: 'حفظ PNG عالي الدقة وPDF بجودة طباعة وفيديو بتأثيرات وصوت — كله على جهازك.' },
  { icon: Package, title: 'حزم وتحديث يدوي', text: 'استيراد حزم قوالب ZIP/JSON وتحديثها من رابط عند الطلب فقط، مع تنقية صارمة.' },
  { icon: WifiOff, title: 'خصوصية كاملة', text: 'بلا حسابات ولا خوادم. بياناتك تبقى في ذاكرة التطبيق، والذكاء السحابي اختياري بمفتاحك.' },
];

export default function AboutScreen() {
  return (
    <div className="max-w-3xl space-y-4">
      <div className="card-ui p-6 text-center fade-up">
        <div className="flex justify-center">
          <Logo size={72} />
        </div>
        <h2 className="text-2xl font-extrabold text-ink mt-3">{APP_NAME}</h2>
        <div className="mt-1 inline-flex items-center gap-1.5 rounded-full bg-brand-soft text-brand-dark px-3 py-1 text-xs font-bold">الإصدار {APP_VERSION}</div>
        <p className="muted mt-4 leading-8 max-w-xl mx-auto">تطبيق شخصي لتصميم بطاقات الدعوة العربية بلمسة فاخرة: اختاري المناسبة والذوق، تصفحي قوالب مولّدة بعناية، عدّلي كل نص ولون وحرف بمعاينة حية، ثم احفظي التصميم على جهازك بالصيغة التي تريدين.</p>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        {FEATURES.map(({ icon: Icon, title, text }) => (
          <div key={title} className="card-ui p-4 flex gap-3">
            <div className="w-10 h-10 rounded-xl bg-brand-soft text-brand flex items-center justify-center shrink-0">
              <Icon size={20} />
            </div>
            <div>
              <div className="font-bold text-ink text-sm">{title}</div>
              <p className="text-xs text-ink-soft leading-6 mt-0.5">{text}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="card-ui p-5 flex items-center gap-3">
        <ShieldCheck className="text-brand" />
        <div className="flex-1">
          <div className="text-xs text-ink-mute">المطور</div>
          <div className="font-extrabold text-ink">{DEVELOPER}</div>
        </div>
        <Heart className="text-gold" size={20} fill="currentColor" />
      </div>
    </div>
  );
}
