import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ImageUp, WandSparkles, Loader2, Info, Save, CheckCircle2, Cloud, Cpu, X } from 'lucide-react';
import { fileToDataUrl, downscaleImage, extractPalette } from '../lib/palette.js';
import { generateLuxury, paletteFromExtract, LUXURY_STRUCTURES } from '../lib/luxury.js';
import { analyzeImageWithAI, cloudAvailable } from '../lib/ai.js';
import { validateTemplateHtml } from '../lib/templateUtils.js';
import { MONO_FAMILIES, MONO_STYLES, defaultMono } from '../lib/monograms.js';
import { TEMPLATE_FONTS } from '../lib/fontsManifest.js';
import { FILTER_DEFS, newSeed } from '../lib/tplKit.js';
import { saveTemplate, uid } from '../lib/db.js';
import { useOnline } from '../lib/hooks.js';
import TemplateCard from '../components/TemplateCard.jsx';
import { useToast } from '../components/Toast.jsx';

const STRUCT_BY_LAYOUT = {
  framed: ['ivory-marble', 'botanical-frame', 'royal-hall', 'embossed-paper'],
  'top-heavy': ['floral-envelope', 'watercolor', 'event-cards', 'botanical-frame'],
  arch: ['burgundy-arch', 'navy-night', 'emerald-star', 'royal-hall'],
  centered: ['embossed-paper', 'ivory-marble', 'royal-hall', 'event-cards'],
};
const DARK_STRUCTS = ['burgundy-arch', 'royal-hall', 'navy-night', 'emerald-star'];
const OCCASIONS = FILTER_DEFS.find((f) => f.key === 'occasion').options;

const oneOf = (v, list, fb) => (list.includes(v) ? v : fb);
const hex = (v) => (/^#[0-9a-f]{6}$/i.test(String(v || '')) ? v : null);

function aiPalette(p, ex, variant) {
  const base = paletteFromExtract(ex, variant);
  if (!p) return base;
  return { ...base, id: `ai-${variant}`, bg: hex(p.bg) || base.bg, c1: hex(p.c1) || base.c1, c2: hex(p.c2) || base.c2, c3: hex(p.c3) || base.c3, ink: hex(p.ink) || base.ink, bg2: base.bg2 };
}

function asClone(t, extra = {}) {
  return { ...t, id: uid('clone').replace(/[^\w-]/g, ''), origin: 'clone', title: `مستوحى: ${t.title}`, createdAt: Date.now(), ...extra };
}

/** الاستنساخ الهجين — [F3-S3]: محلي دائماً + رؤية سحابية اختيارية بمفتاح المستخدم */
export default function CloneScreen() {
  const [img, setImg] = useState(null);
  const [ex, setEx] = useState(null);
  const [occasion, setOccasion] = useState('زفاف');
  const [count, setCount] = useState(4);
  const [busy, setBusy] = useState(null);
  const [results, setResults] = useState([]);
  const [chosen, setChosen] = useState([]);
  const [source, setSource] = useState(null);
  const [note, setNote] = useState('');
  const [saved, setSaved] = useState(false);
  const [hasCloud, setHasCloud] = useState(false);
  const online = useOnline();
  const toast = useToast();

  useEffect(() => {
    cloudAvailable().then(setHasCloud);
  }, [online]);

  const onFile = async (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    if (!f.type.startsWith('image/')) {
      toast('اختاري ملف صورة', 'error');
      return;
    }
    setBusy('read');
    setResults([]);
    setSaved(false);
    try {
      const raw = await fileToDataUrl(f);
      const small = (await downscaleImage(raw, 900, 'image/jpeg', 0.85)).dataUrl;
      setImg(small);
      setEx(await extractPalette(small));
    } catch (err) {
      toast(`تعذر قراءة الصورة: ${err.message}`, 'error');
    } finally {
      setBusy(null);
    }
  };

  const localClone = (n, seed, hints = {}) => {
    const layout = hints.layout || ex.orientation;
    let structs = hints.structure ? [hints.structure] : STRUCT_BY_LAYOUT[ex.layout?.structure] || STRUCT_BY_LAYOUT.centered;
    if (!hints.structure && ex.dark) structs = [...new Set([...structs.filter((s) => DARK_STRUCTS.includes(s)), ...DARK_STRUCTS])].slice(0, 4);
    const filters = { occasion, layout, ...(hints.style ? { style: hints.style } : {}), ...(hints.ornaments ? { ornaments: hints.ornaments } : {}) };
    const out = [];
    for (let i = 0; i < n; i++) {
      const st = structs[i % structs.length];
      const [t] = generateLuxury(filters, {
        seed: seed + i * 131,
        count: 1,
        structures: [st],
        paletteOverride: hints.palette ? aiPalette(hints.palette, ex, i) : paletteFromExtract(ex, i),
        monoOverride: hints.mono || undefined,
        fontsOverride: hints.fonts || undefined,
        prefs: hints.mono ? { mono: true } : {},
      });
      out.push(asClone(t));
    }
    return out;
  };

  const run = async () => {
    if (!ex) return;
    setBusy('gen');
    setSaved(false);
    setNote('');
    const seed = newSeed();
    try {
      let list = [];
      if (hasCloud && online) {
        try {
          const a = await analyzeImageWithAI((await downscaleImage(img, 768, 'image/jpeg', 0.8)).dataUrl);
          const fonts = a?.fonts?.title ? { title: oneOf(a.fonts.title, TEMPLATE_FONTS, 'Aref Ruqaa'), body: oneOf(a.fonts.body, TEMPLATE_FONTS, 'Amiri'), deco: oneOf(a.fonts.title, TEMPLATE_FONTS, 'Aref Ruqaa') } : null;
          const m = a?.monogram;
          const mono =
            m && m.present
              ? defaultMono({
                  a: String(m.letters?.[0] || 'م').slice(0, 2),
                  b: String(m.letters?.[1] || '').slice(0, 2),
                  family: oneOf(m.family, MONO_FAMILIES.map((x) => x.family), 'Aref Ruqaa'),
                  style: oneOf(m.style, MONO_STYLES.map((x) => x.id), 'overlap'),
                  auto: false,
                })
              : null;
          const hints = {
            structure: LUXURY_STRUCTURES.some((s) => s.id === a?.structure) ? a.structure : null,
            layout: oneOf(a?.layout, FILTER_DEFS.find((f) => f.key === 'layout').options, ex.orientation),
            style: oneOf(a?.style, FILTER_DEFS.find((f) => f.key === 'style').options, undefined),
            ornaments: oneOf(a?.ornaments, FILTER_DEFS.find((f) => f.key === 'ornaments').options, undefined),
            fonts,
            mono,
            palette: a?.palette,
          };
          if (a?.occasion && OCCASIONS.includes(a.occasion) && occasion === 'زفاف' && a.occasion !== 'زفاف') setNote(`يبدو أن المناسبة في الصورة: ${a.occasion}`);
          const aiT = (Array.isArray(a?.templates) ? a.templates : [])
            .filter((t) => validateTemplateHtml(String(t?.html || ''), { maxChars: 20000 }).ok)
            .slice(0, 2)
            .map((t, i) =>
              asClone({ title: String(t.title || `تصميم مستوحى ${i + 1}`).slice(0, 50), occasion, html: t.html, tags: { occasion, layout: hints.layout, style: hints.style, ornaments: hints.ornaments }, engine: 'cloud', structure: 'vision', signature: `vision:${seed}:${i}`, mono: mono || null }),
            );
          list = [...aiT, ...localClone(Math.max(1, count - aiT.length), seed, hints)];
          setSource('vision');
        } catch {
          list = localClone(count, seed);
          setSource('local-fallback');
        }
      } else {
        list = localClone(count, seed);
        setSource('local');
      }
      list = list.slice(0, count);
      setResults(list);
      setChosen(list.map((t) => t.id));
    } catch (err) {
      toast(`تعذر الاستنساخ: ${err.message}`, 'error');
    } finally {
      setBusy(null);
    }
  };

  const saveChosen = async () => {
    const list = results.filter((t) => chosen.includes(t.id));
    if (!list.length) return;
    setBusy('save');
    try {
      for (const t of list) await saveTemplate(t);
      setSaved(true);
      toast(`حُفظ ${list.length} قالب محلياً — ستجدينها في الاستكشاف`);
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="card-ui p-4 sm:p-5">
        <div className="grid sm:grid-cols-[180px_1fr] gap-4 items-start">
          <label className={`relative rounded-2xl border-2 border-dashed ${img ? 'border-transparent' : 'border-[#cfe0d9]'} bg-canvas aspect-[9/16] flex flex-col items-center justify-center text-center cursor-pointer overflow-hidden max-w-[180px] mx-auto w-full`}>
            {img ? <img src={img} alt="الصورة المرجعية" className="absolute inset-0 w-full h-full object-cover" /> : (
              <>
                <ImageUp className="text-brand" size={30} />
                <span className="text-xs text-ink-soft mt-2 px-3">اختاري صورة دعوة من جهازك</span>
              </>
            )}
            {busy === 'read' && (
              <span className="absolute inset-0 bg-white/70 flex items-center justify-center">
                <Loader2 className="animate-spin text-brand" />
              </span>
            )}
            <input type="file" accept="image/*" className="sr-only" aria-label="صورة الدعوة المرجعية" onChange={onFile} />
          </label>
          <div className="space-y-3">
            <div className={`rounded-xl p-3 text-xs leading-6 flex gap-2 ${hasCloud && online ? 'bg-brand-soft text-brand-dark' : 'bg-gold-light/60 text-[#6b4f1d]'}`}>
              {hasCloud && online ? <Cloud size={16} className="shrink-0 mt-1" /> : <Cpu size={16} className="shrink-0 mt-1" />}
              <span>
                {hasCloud && online
                  ? 'وضع الاستنساخ الكامل: تُحلَّل نسخة مصغرة من الصورة بالرؤية (بمفتاحك) لالتقاط التوزيع والخطوط وتشابك الحروف والزخارف، ثم تُبنى قوالب مستوحاة بشدة بتغييرات ثانوية فقط.'
                  : 'وضع محلي تقريبي: يُستخرج من الصورة الألوان المهيمنة والإضاءة ونسبة الأبعاد وتخطيط تقريبي فقط. لنتائج أدق في الخطوط والحروف والزخارف أضيفي مفتاحاً في الإعدادات.'}
              </span>
            </div>
            {ex && (
              <div className="flex flex-wrap items-center gap-3 text-xs">
                <span className="flex gap-1">
                  {ex.colors.map((c) => (
                    <span key={c} className="w-6 h-6 rounded-full border border-black/10" style={{ background: c }} title={c} />
                  ))}
                </span>
                <span className="chip-off pointer-events-none">{ex.dark ? 'داكنة' : 'فاتحة'}</span>
                <span className="chip-off pointer-events-none">{ex.orientation} ({ex.aspect.toFixed(2)})</span>
                <span className="chip-off pointer-events-none">تخطيط: {{ framed: 'مؤطر', 'top-heavy': 'ثقل علوي', arch: 'مركزي/قوس', centered: 'متمركز' }[ex.layout?.structure] || '—'}</span>
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label" htmlFor="occ">
                  المناسبة
                </label>
                <select id="occ" className="input" value={occasion} onChange={(e) => setOccasion(e.target.value)}>
                  {OCCASIONS.map((o) => (
                    <option key={o}>{o}</option>
                  ))}
                </select>
              </div>
              <div>
                <div className="label">عدد النتائج</div>
                <div className="flex gap-1.5">
                  {[3, 4, 5].map((n) => (
                    <button key={n} className={count === n ? 'chip-on' : 'chip-off'} onClick={() => setCount(n)}>
                      {n}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <button className="btn-primary w-full sm:w-auto" onClick={run} disabled={!ex || !!busy}>
              {busy === 'gen' ? <Loader2 size={17} className="animate-spin" /> : <WandSparkles size={17} />} {busy === 'gen' ? 'جارٍ التحليل والبناء…' : 'استنساخ مستوحى'}
            </button>
            <p className="text-[11px] text-ink-mute flex gap-1.5">
              <Info size={13} className="shrink-0 mt-0.5" /> للاستخدام الشخصي: يُستلهم الطابع العام ولا تُنسخ النصوص أو الصور أو العلامات المائية.
            </p>
          </div>
        </div>
      </div>

      {note && (
        <div className="text-xs bg-canvas rounded-xl px-3 py-2 flex items-center justify-between">
          {note}
          <button className="btn-icon w-6 h-6" onClick={() => setNote('')} aria-label="إغلاق">
            <X size={13} />
          </button>
        </div>
      )}

      {results.length > 0 && (
        <>
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="section-title flex-1">النتائج ({results.length})</h3>
            <span className="text-[11px] text-ink-mute">{source === 'vision' ? 'تحليل بالرؤية + بناء محلي' : source === 'local-fallback' ? 'تعذر التحليل السحابي — استنساخ محلي' : 'استنساخ محلي تقريبي'}</span>
            <button className="btn-gold" onClick={saveChosen} disabled={!chosen.length || !!busy || saved}>
              {busy === 'save' ? <Loader2 size={16} className="animate-spin" /> : saved ? <CheckCircle2 size={16} /> : <Save size={16} />} {saved ? 'محفوظة' : `حفظ المحدد كقوالب محلية (${chosen.length})`}
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {results.map((t) => (
              <div key={t.id} className="relative">
                <label className="absolute top-3 right-3 z-10 bg-white/90 rounded-lg px-1.5 py-1 shadow-soft flex items-center gap-1 text-[10px] font-bold">
                  <input type="checkbox" className="accent-[#0f766e]" checked={chosen.includes(t.id)} onChange={() => setChosen((c) => (c.includes(t.id) ? c.filter((x) => x !== t.id) : [...c, t.id]))} />
                  حفظ
                </label>
                <TemplateCard template={t} />
              </div>
            ))}
          </div>
          {saved && (
            <Link to="/explore" className="btn-outline">
              الذهاب للاستكشاف
            </Link>
          )}
        </>
      )}
    </div>
  );
}
