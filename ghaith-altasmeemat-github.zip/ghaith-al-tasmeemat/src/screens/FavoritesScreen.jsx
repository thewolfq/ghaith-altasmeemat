import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Compass, Loader2 } from 'lucide-react';
import { listFavorites, LIMITS } from '../lib/db.js';
import { useAsync, formatDate } from '../lib/hooks.js';
import { useAppData } from '../components/AppData.jsx';
import TemplateCard from '../components/TemplateCard.jsx';

export default function FavoritesScreen() {
  const { version } = useAppData();
  const { loading, error, data } = useAsync(listFavorites, [version]);
  const list = data || [];
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="section-title flex items-center gap-2">
          <Heart size={18} className="text-red-500" /> المفضلة
        </h2>
        <span className={`text-xs font-semibold rounded-full px-2.5 py-1 ${list.length >= LIMITS.favorites ? 'bg-red-50 text-red-700' : 'bg-brand-soft text-brand-dark'}`}>
          {list.length} / {LIMITS.favorites}
        </span>
      </div>
      <p className="muted text-xs">تُحفظ في المفضلة بيانات القالب كاملة، فتبقى متاحة حتى لو تغيّرت نتائج التوليد لاحقاً.</p>
      {loading && !data ? (
        <div className="flex justify-center py-16 text-brand">
          <Loader2 className="animate-spin" />
        </div>
      ) : error ? (
        <div className="card-ui p-4 text-red-700 text-sm">تعذر تحميل المفضلة: {error.message}</div>
      ) : list.length === 0 ? (
        <div className="card-ui p-10 text-center">
          <Heart className="mx-auto text-ink-mute" size={34} />
          <p className="muted mt-3">لا توجد قوالب في المفضلة بعد. اضغطي على القلب في أي قالب لإضافته.</p>
          <Link to="/explore" className="btn-primary mt-4">
            <Compass size={16} /> استكشاف القوالب
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {list.map((f) => (
            <div key={f.id} className="relative">
              <TemplateCard template={f.template} />
              <div className="text-[10px] text-ink-mute text-center mt-1">أُضيف {formatDate(f.savedAt)}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
