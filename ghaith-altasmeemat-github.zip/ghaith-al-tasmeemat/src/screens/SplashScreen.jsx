import React from 'react';
import { Heart } from 'lucide-react';

// شاشة الإهداء — [F1-S2]: تظهر مرة واحدة فقط بعد التثبيت (علامة local_first_launch_done)، وتعود بعد إعادة التثبيت/الضبط الشامل.
const ORN = (
  <svg viewBox="0 0 200 40" className="w-48 h-10 mx-auto" aria-hidden="true">
    <line x1="10" y1="20" x2="78" y2="20" stroke="#d6a85f" strokeWidth="1" />
    <line x1="122" y1="20" x2="190" y2="20" stroke="#d6a85f" strokeWidth="1" />
    <path d="M100 6C104 16 110 18 116 20C110 22 104 24 100 34C96 24 90 22 84 20C90 18 96 16 100 6Z" fill="#d6a85f" />
    <circle cx="74" cy="20" r="2.2" fill="#d6a85f" />
    <circle cx="126" cy="20" r="2.2" fill="#d6a85f" />
  </svg>
);

function Corner({ className }) {
  return (
    <svg viewBox="0 0 100 100" className={`absolute w-28 h-28 sm:w-40 sm:h-40 text-[#d6a85f] opacity-60 ${className}`} aria-hidden="true">
      <path d="M6 94C6 46 46 6 94 6" fill="none" stroke="currentColor" strokeWidth="1.6" />
      <path d="M16 94C16 54 54 16 94 16" fill="none" stroke="currentColor" strokeWidth="0.8" />
      <circle cx="6" cy="94" r="3" fill="currentColor" />
      <circle cx="94" cy="6" r="3" fill="currentColor" />
      <path d="M30 30C34 20 40 18 46 16C40 22 38 28 30 30Z" fill="currentColor" />
    </svg>
  );
}

export default function SplashScreen({ onEnter }) {
  return (
    <div className="relative min-h-screen overflow-hidden flex items-center justify-center px-6 py-10" style={{ background: 'radial-gradient(ellipse at 50% 0%, #fffaf0 0%, #f8f0df 55%, #f1e5cc 100%)' }}>
      <Corner className="top-3 right-3 -scale-x-100" />
      <Corner className="top-3 left-3" />
      <Corner className="bottom-3 right-3 -scale-100" />
      <Corner className="bottom-3 left-3 -scale-y-100" />

      <div className="relative max-w-lg w-full text-center">
        <div className="fade-up" style={{ animationDuration: '.7s' }}>
          <div className="mx-auto mb-4 w-14 h-14 rounded-full bg-white/70 border border-[#ead7b0] flex items-center justify-center shadow-soft">
            <Heart className="text-[#b5473f]" size={26} fill="#b5473f" />
          </div>
          <p className="text-[#8a6a2f] text-sm tracking-wide">إهداء خاص</p>
          <h1 className="mt-1 text-3xl sm:text-4xl font-bold text-[#3d2f17]" style={{ fontFamily: "'Aref Ruqaa','Amiri',serif" }}>
            إلى رفيقة عمري
          </h1>
        </div>

        <div className="fade-up mt-4" style={{ animationDelay: '.25s', animationDuration: '.8s' }}>
          {ORN}
        </div>

        <div className="fade-up mt-4 space-y-4 text-[#4a3b22] leading-9 text-[17px]" style={{ fontFamily: "'Amiri','Scheherazade New',serif", animationDelay: '.45s', animationDuration: '.8s' }}>
          <p>في ذلك اليوم بدأت أجمل حكاياتي، حين صار اسمكِ أقرب الأسماء إلى قلبي، وصار بيتنا وطناً صغيراً يتّسع لأحلامنا معاً.</p>
          <p>صنعتُ هذا التطبيق لأجلكِ، لتصمّمي به أفراح الآخرين كما زيّنتِ أنتِ أيامي بالفرح.</p>
        </div>

        <div className="fade-up mt-6" style={{ animationDelay: '.8s', animationDuration: '.8s' }}>
          <div className="text-xs text-[#8a6a2f]">ذكرى زواجنا</div>
          <div className="gold-text text-4xl sm:text-5xl font-extrabold mt-1" style={{ fontFamily: "'El Messiri','Cairo',sans-serif" }}>
            ٣٠ نوفمبر ٢٠٢٥
          </div>
          <p className="mt-3 text-[#4a3b22] text-lg" style={{ fontFamily: "'Aref Ruqaa','Amiri',serif" }}>
            كل عامٍ وأنتِ الحبُّ الذي لا ينتهي
          </p>
          <p className="mt-1 text-sm text-[#8a6a2f]">زوجكِ المحب</p>
        </div>

        <div className="fade-up mt-8" style={{ animationDelay: '1.2s', animationDuration: '.6s' }}>
          <button className="btn bg-[#0f766e] text-white px-8 py-3 text-base rounded-2xl shadow-lift hover:bg-[#115e59]" onClick={onEnter}>
            الدخول إلى التطبيق
          </button>
        </div>
      </div>
    </div>
  );
}
