import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Compass, Loader2, PenLine, Copy, Trash2, Zap, Layers } from 'lucide-react';
import { listInvitations, deleteInvitation, LIMITS, byteSize, formatBytes } from '../lib/db.js';
import { useAsync, formatDate } from '../lib/hooks.js';
import { useAppData } from '../components/AppData.jsx';
import { useConfirm } from '../components/ConfirmDialog.jsx';
import { useToast } from '../components/Toast.jsx';
import FitHtml from '../components/FitHtml.jsx';

export default function InvitationsScreen() {
  const { version, bump, duplicateSafe } = useAppData();
  const { loading, error, data } = useAsync(listInvitations, [version]);
  const navigate = useNavigate();
  const confirm = useConfirm();
  const toast = useToast();
  const [busy, setBusy] = useState(null);
  const list = data || [];

  const open = (inv, mode) => navigate(`/edit/${mode || inv.mode || 'full'}?inv=${inv.id}`);

  const dup = async (inv) => {
    setBusy(inv.id);
    try {
      const row = await duplicateSafe(inv.id);
      if (row) toast('تم إنشاء نسخة جديدة بمعرّف مستقل');
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setBusy(null);
    }
  };

  const del = async (inv) => {
    const ok = await confirm({ title: 'حذف الدعوة؟', message: 'ستُحذف الدعوة ونسخة القالب المحفوظة معها نهائياً من الجهاز.', items: [{ label: inv.title, size: formatBytes(byteSize(inv)) }], confirmText: 'حذف نهائي', danger: true });
    if (!ok) return;
    await deleteInvitation(inv.id);
    bump();
    toast('تم حذف الدعوة', 'info');
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="section-title flex items-center gap-2">
          <Mail size={18} className="text-brand" /> دعواتي
        </h2>
        <span className={`text-xs font-semibold rounded-full px-2.5 py-1 ${list.length >= LIMITS.invitations ? 'bg-red-50 text-red-700' : 'bg-brand-soft text-brand-dark'}`}>
          {list.length} / {LIMITS.invitations}
        </span>
      </div>
      {loading && !data ? (
        <div className="flex justify-center py-16 text-brand">
          <Loader2 className="animate-spin" />
        </div>
      ) : error ? (
        <div className="card-ui p-4 text-red-700 text-sm">تعذر تحميل الدعوات: {error.message}</div>
      ) : list.length === 0 ? (
        <div className="card-ui p-10 text-center">
          <Mail className="mx-auto text-ink-mute" size={34} />
          <p className="muted mt-3">لم تحفظي أي دعوة بعد.</p>
          <Link to="/explore" className="btn-primary mt-4">
            <Compass size={16} /> ابدئي بتصميم دعوة
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {list.map((inv) => (
            <div key={inv.id} className="card-ui p-2 flex flex-col fade-up">
              <button onClick={() => open(inv)} aria-label={`فتح ${inv.title}`}>
                <FitHtml template={inv.template} state={inv.state} lazy noAnim />
              </button>
              <div className="px-1.5 pt-2">
                <div className="font-bold text-[13px] text-ink truncate">{inv.title}</div>
                <div className="text-[11px] text-ink-mute">
                  {inv.occasion || inv.template?.occasion} • {formatDate(inv.updatedAt || inv.createdAt)}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-1.5 mt-2 px-1">
                <button className="btn-soft py-1.5 text-[11px]" onClick={() => open(inv, 'simple')} title="فتح في التحرير المبسط">
                  <Zap size={13} /> مبسط
                </button>
                <button className="btn-primary py-1.5 text-[11px]" onClick={() => open(inv, 'full')} title="فتح في التحرير الكامل">
                  <Layers size={13} /> كامل
                </button>
              </div>
              <div className="flex gap-1 mt-1.5 px-1 pb-1">
                <button className="btn-ghost flex-1 py-1.5 text-[11px]" onClick={() => open(inv)}>
                  <PenLine size={13} /> تعديل
                </button>
                <button className="btn-icon w-8 h-8" onClick={() => dup(inv)} disabled={busy === inv.id} title="نسخ كدعوة جديدة" aria-label="نسخ">
                  {busy === inv.id ? <Loader2 size={15} className="animate-spin" /> : <Copy size={15} />}
                </button>
                <button className="btn-icon w-8 h-8 text-red-600" onClick={() => del(inv)} title="حذف" aria-label="حذف">
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
