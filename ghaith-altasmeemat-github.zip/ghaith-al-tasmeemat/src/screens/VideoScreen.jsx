import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Play, Square, Music, Film, Loader2, X, Sparkles, ChevronRight, AlertTriangle, Trash2 } from 'lucide-react';
import { getVideoSource } from '../lib/session.js';
import { renderToCanvas, saveBlob, safeFileName } from '../lib/exportUtils.js';
import { VIDEO_W, VIDEO_H, videoSupported, pickVideoMime, buildLocalPlan, sanitizePlan, drawFrame, recordVideo } from '../lib/videoUtils.js';
import { VIDEO_EFFECTS, planVideoWithAI, cloudAvailable } from '../lib/ai.js';
import { formatBytes } from '../lib/db.js';
import { useOnline } from '../lib/hooks.js';
import { useToast } from '../components/Toast.jsx';

const BG_PRESETS = ['#101413', '#0d3b33', '#2a0f18', '#0f1f3d', '#f5f1e8', '#ffffff'];

/** فرع الصوت والفيديو — [F3-S5]: Canvas + rAF + MediaRecorder + دمج صوت محلي */
export default function VideoScreen() {
  const src = useMemo(() => getVideoSource(), []);
  const navigate = useNavigate();
  const toast = useToast();
  const online = useOnline();
  const previewRef = useRef(null);
  const frameRef = useRef(null);
  const rafRef = useRef(0);
  const abortRef = useRef(null);
  const [ready, setReady] = useState(false);
  const [renderErr, setRenderErr] = useState('');
  const [effects, setEffects] = useState(src?.media?.effects?.length ? src.media.effects : ['fade', 'zoom']);
  const [duration, setDuration] = useState(src?.media?.duration || 12);
  const [bg, setBg] = useState('#101413');
  const [audio, setAudio] = useState(null);
  const [aiPlan, setAiPlan] = useState(null);
  const [aiText, setAiText] = useState('');
  const [hasCloud, setHasCloud] = useState(false);
  const [busy, setBusy] = useState(null);
  const [progress, setProgress] = useState(0);
  const [playing, setPlaying] = useState(false);
  const supported = videoSupported();
  const fmt = pickVideoMime();

  const plan = useMemo(() => {
    const p = aiPlan ? sanitizePlan(aiPlan, duration) : sanitizePlan(buildLocalPlan(effects, duration), duration);
    return { ...p, background: aiPlan?.background && /^#[0-9a-f]{6}$/i.test(aiPlan.background) ? aiPlan.background : bg };
  }, [aiPlan, effects, duration, bg]);

  useEffect(() => {
    cloudAvailable().then(setHasCloud);
  }, [online]);

  // تجهيز إطار التصميم مرة واحدة (نفس مسار تصدير PNG لضمان التطابق)
  useEffect(() => {
    if (!src) return undefined;
    let alive = true;
    renderToCanvas(src.template, src.state, 2)
      .then((c) => {
        if (!alive) return;
        frameRef.current = c;
        setReady(true);
      })
      .catch((e) => alive && setRenderErr(e.message || 'تعذر تجهيز التصميم'));
    return () => {
      alive = false;
    };
  }, [src]);

  // رسم الإطار الأول عند تغير الخطة
  useEffect(() => {
    if (!ready || playing || !previewRef.current) return;
    const ctx = previewRef.current.getContext('2d');
    drawFrame(ctx, frameRef.current, plan, Math.min(plan.duration * 0.5, 2));
  }, [ready, plan, playing]);

  useEffect(
    () => () => {
      cancelAnimationFrame(rafRef.current);
      abortRef.current?.abort();
    },
    [],
  );

  const play = () => {
    if (!ready) return;
    if (playing) {
      cancelAnimationFrame(rafRef.current);
      setPlaying(false);
      return;
    }
    setPlaying(true);
    const ctx = previewRef.current.getContext('2d');
    const start = performance.now();
    const tick = () => {
      const t = (performance.now() - start) / 1000;
      drawFrame(ctx, frameRef.current, plan, Math.min(t, plan.duration));
      if (t < plan.duration) rafRef.current = requestAnimationFrame(tick);
      else setPlaying(false);
    };
    rafRef.current = requestAnimationFrame(tick);
  };

  const onAudio = (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    if (!f.type.startsWith('audio/') && !/\.(mp3|m4a|aac|wav|ogg|opus)$/i.test(f.name)) {
      toast('اختاري ملفاً صوتياً', 'error');
      return;
    }
    if (f.size > 40 * 1024 * 1024) {
      toast('الملف الصوتي أكبر من 40MB', 'error');
      return;
    }
    setAudio(f);
  };

  const askAi = async () => {
    if (!aiText.trim()) return;
    setBusy('ai');
    try {
      const p = await planVideoWithAI(aiText.trim(), { duration });
      setAiPlan(p);
      if (p.duration) setDuration(Math.max(4, Math.min(60, Math.round(p.duration))));
      toast('تم تطبيق الخطة كما وصفتِها');
    } catch {
      setAiPlan(null);
      toast('تعذر تنفيذ الطلب سحابياً — تُستخدم التأثيرات المحلية المختارة', 'info', 4000);
    } finally {
      setBusy(null);
    }
  };

  const record = async () => {
    if (!ready) return;
    cancelAnimationFrame(rafRef.current);
    setPlaying(false);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setBusy('rec');
    setProgress(0);
    // مهلة أمان: ضعف المدة + 20 ثانية
    let timedOut = false;
    const guard = setTimeout(() => {
      timedOut = true;
      ctrl.abort();
    }, (plan.duration * 2 + 20) * 1000);
    try {
      const out = await recordVideo({ source: frameRef.current, audioFile: audio, plan, fps: 30, onProgress: setProgress, signal: ctrl.signal });
      setBusy('save');
      const res = await saveBlob(out.blob, safeFileName(src.title || src.template.title, out.ext));
      toast(`حُفظ الفيديو (${out.ext.toUpperCase()} • ${formatBytes(out.blob.size)}): ${res.location}`, 'success', 5000);
    } catch (e) {
      if (e?.name === 'AbortError') toast(timedOut ? 'انتهت المهلة دون اكتمال التسجيل — جرّبي مدة أقصر' : 'أُلغي التسجيل', timedOut ? 'error' : 'info');
      else toast(`فشل إنشاء الفيديو: ${e.message || 'خطأ'} — جرّبي بدون صوت أو بمدة أقصر`, 'error', 6000);
    } finally {
      clearTimeout(guard);
      abortRef.current = null;
      setBusy(null);
    }
  };

  const back = () => navigate(src?.returnTo || '/invitations');

  if (!src) {
    return (
      <div className="card-ui p-8 text-center max-w-md mx-auto">
        <Film className="mx-auto text-ink-mute" size={32} />
        <p className="muted mt-2">افتحي شاشة الفيديو من تبويب «صوت وفيديو» في المحرر أو من زر الفيديو بعد إكمال التصميم.</p>
        <Link to="/invitations" className="btn-primary mt-4">
          دعواتي
        </Link>
      </div>
    );
  }

  const recording = busy === 'rec' || busy === 'save';

  return (
    <div className="space-y-4">
      <button className="btn-ghost -mr-2" onClick={back} disabled={recording}>
        <ChevronRight size={18} /> الرجوع للمحرر
      </button>
      {!supported && (
        <div className="card-ui p-4 flex gap-3 text-sm text-[#7a4b12] bg-gold-light/50">
          <AlertTriangle className="shrink-0" />
          <span>هذا المتصفح/الجهاز لا يدعم تسجيل الفيديو عبر MediaRecorder. يمكنك المعاينة فقط، أو تصدير الصورة PNG/PDF من المحرر.</span>
        </div>
      )}
      <div className="grid lg:grid-cols-[340px_1fr] gap-4 items-start">
        <div className="card-ui p-3 lg:sticky lg:top-20">
          <div className="relative mx-auto max-w-[300px] rounded-xl overflow-hidden bg-[#101413]" style={{ aspectRatio: `${VIDEO_W}/${VIDEO_H}` }}>
            <canvas ref={previewRef} width={VIDEO_W} height={VIDEO_H} className="w-full h-full block" />
            {!ready && (
              <div className="absolute inset-0 flex items-center justify-center text-white/80 text-sm">
                {renderErr ? renderErr : <Loader2 className="animate-spin" />}
              </div>
            )}
          </div>
          <div className="flex justify-center gap-2 mt-3">
            <button className="btn-soft" onClick={play} disabled={!ready || recording}>
              {playing ? <Square size={16} /> : <Play size={16} />} {playing ? 'إيقاف' : 'معاينة الحركة'}
            </button>
          </div>
          <div className="text-center text-[11px] text-ink-mute mt-2">
            {VIDEO_W}×{VIDEO_H} • {plan.duration} ث • {fmt ? fmt.ext.toUpperCase() : 'غير مدعوم'}
          </div>
        </div>

        <div className="space-y-4">
          <div className="card-ui p-4 space-y-4">
            <div>
              <div className="label">التأثيرات {aiPlan && <span className="text-brand">(خطة نصية مطبّقة)</span>}</div>
              <div className="flex flex-wrap gap-1.5">
                {VIDEO_EFFECTS.map((e) => (
                  <button
                    key={e.id}
                    className={effects.includes(e.id) && !aiPlan ? 'chip-on' : 'chip-off'}
                    onClick={() => {
                      setAiPlan(null);
                      setEffects((x) => (x.includes(e.id) ? x.filter((y) => y !== e.id) : [...x, e.id]));
                    }}
                  >
                    {e.label}
                  </button>
                ))}
              </div>
            </div>
            <label className="block">
              <span className="label">المدة ({duration} ثانية)</span>
              <input type="range" min="4" max="60" value={duration} onChange={(e) => setDuration(Number(e.target.value))} className="w-full accent-[#0f766e]" />
            </label>
            <div>
              <div className="label">لون الخلفية</div>
              <div className="flex gap-2">
                {BG_PRESETS.map((c) => (
                  <button key={c} className={`w-8 h-8 rounded-full border ${bg === c ? 'ring-2 ring-brand ring-offset-2' : 'border-black/10'}`} style={{ background: c }} onClick={() => setBg(c)} aria-label={c} />
                ))}
              </div>
            </div>
            <div>
              <div className="label">الصوت (اختياري — من جهازك)</div>
              {audio ? (
                <div className="flex items-center gap-2 rounded-xl bg-canvas px-3 py-2">
                  <Music size={16} className="text-brand" />
                  <span className="flex-1 text-xs truncate">
                    {audio.name} • {formatBytes(audio.size)}
                  </span>
                  <button className="btn-icon w-7 h-7 text-red-600" onClick={() => setAudio(null)} aria-label="إزالة الصوت" disabled={recording}>
                    <Trash2 size={14} />
                  </button>
                </div>
              ) : (
                <label className="btn-outline cursor-pointer">
                  <Music size={16} /> اختيار ملف صوتي
                  <input type="file" accept="audio/*" className="sr-only" aria-label="ملف صوتي" onChange={onAudio} />
                </label>
              )}
              <p className="text-[11px] text-ink-mute mt-1">يُقص الصوت على مدة الفيديو مع تلاشٍ ناعم في البداية والنهاية.</p>
            </div>
          </div>

          {hasCloud && (
            <div className="card-ui p-4 space-y-2">
              <div className="label flex items-center gap-1.5">
                <Sparkles size={14} className="text-gold-dark" /> وصف نصي للتأثير (يُنفَّذ كما تكتبينه)
              </div>
              <textarea className="input min-h-[70px]" value={aiText} onChange={(e) => setAiText(e.target.value)} placeholder="مثال: تبدأ البطاقة بقلب أفقي ثم تكبير بطيء على الأسماء وتنتهي بتلاشٍ خلال 15 ثانية" />
              <div className="flex gap-2">
                <button className="btn-soft" onClick={askAi} disabled={!aiText.trim() || !!busy || !online}>
                  {busy === 'ai' ? <Loader2 size={15} className="animate-spin" /> : <Sparkles size={15} />} تطبيق الوصف
                </button>
                {aiPlan && (
                  <button className="btn-ghost" onClick={() => setAiPlan(null)}>
                    <X size={15} /> العودة للتأثيرات المحلية
                  </button>
                )}
              </div>
            </div>
          )}

          <div className="card-ui p-4">
            {recording ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm font-bold">
                  <span>{busy === 'save' ? 'جارٍ الحفظ على الجهاز…' : 'جارٍ تسجيل الفيديو…'}</span>
                  <span>{Math.round(progress * 100)}٪</span>
                </div>
                <div className="h-2.5 rounded-full bg-canvas-deep overflow-hidden">
                  <div className="h-full bg-brand transition-all" style={{ width: `${progress * 100}%` }} />
                </div>
                <p className="text-[11px] text-ink-mute">أبقي الشاشة مفتوحة حتى انتهاء التسجيل (يتم بسرعة التشغيل الفعلية).</p>
                {busy === 'rec' && (
                  <button className="btn-outline" onClick={() => abortRef.current?.abort()}>
                    <X size={16} /> إلغاء
                  </button>
                )}
              </div>
            ) : (
              <button className="btn-primary w-full" onClick={record} disabled={!ready || !supported || !!busy}>
                <Film size={17} /> إنشاء الفيديو وحفظه ({fmt ? fmt.ext.toUpperCase() : '—'})
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
