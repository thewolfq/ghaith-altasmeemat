import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Compass, Mail, Heart, WandSparkles, LayoutTemplate, HardDrive, PenLine, Sparkles } from 'lucide-react';
import { db, formatBytes, LIMITS, APP_NAME } from '../lib/db.js';
import { computeStorage } from '../lib/assets.js';
import { useAsync, formatDate } from '../lib/hooks.js';
import { useAppData } from '../components/AppData.jsx';
import FitHtml from '../components/FitHtml.jsx';

function Stat({ icon: Icon, label, value, sub, to }) {
  const body = (
    <div className="card-ui p-4 h-full hover:shadow-lift transition">
      <div className="flex items-center gap-2 text-ink-mute text-xs font-semibold">
        <Icon size={16} className="text-brand" />
        {label}
      </div>
      <div className="mt-2 text-2xl font-extrabold text-ink">{value}</div>
      {sub && <div className="text-[11px] text-ink-mute mt-0.5">{sub}</div>}
    </div>
  );
  return to ? <Link to={to}>{body}</Link> : body;
}

export default function HomeScreen() {
  const navigate = useNavigate();
  const { version } = useAppData();
  const stats = useAsync(async () => {
    const [templates, favorites, invitations, storage, last] = await Promise.all([
      db.templates.count(),
      db.favorites.count(),
      db.invitations.count(),
      computeStorage(),
      db.invitations.orderBy('updatedAt').reverse().first(),
    ]);
    return { templates, favorites, invitations, storage, last };
  }, [version]);

  const s = stats.data;
  const pct = s ? Math.min(100, (s.storage.total / LIMITS.budgetBytes) * 100) : 0;
  const shortcuts = [
    { to: '/explore', label: 'استكشف القوالب', desc: 'فلاتر ذكية وتوليد محلي', icon: Compass, tone: 'bg-brand text-white' },
    { to: '/invitations', label: 'دعواتي', desc: 'المحفوظة والقابلة للتعديل', icon: Mail, tone: 'bg-white text-ink' },
    { to: '/favorites', label: 'المفضلة', desc: 'قوالبك المختارة', icon: Heart, tone: 'bg-white text-ink' },
    { to: '/clone', label: 'استنساخ من صورة', desc: 'تصميم مستوحى يحافظ على الهوية', icon: WandSparkles, tone: 'bg-gold-light text-ink' },
  ];

  return (
    <div className="space-y-6 fade-up">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-l from-[#0f766e] to-[#0b4f4a] text-white p-6 sm:p-8 shadow-lift">
        <svg viewBox="0 0 100 100" className="absolute -left-10 -bottom-12 w-56 h-56 text-[#d6a85f] opacity-20" aria-hidden="true">
          <path d="M50 4L59 38L94 50L59 62L50 96L41 62L6 50L41 38Z" fill="currentColor" />
        </svg>
        <div className="relative">
          <div className="flex items-center gap-2 text-gold-light text-sm">
            <Sparkles size={16} /> أهلاً بكِ
          </div>
          <h2 className="mt-1 text-2xl sm:text-3xl font-extrabold">{APP_NAME}</h2>
          <p className="mt-2 text-white/80 text-sm leading-7 max-w-xl">اختاري المناسبة، احصلي على قوالب أنيقة، عدّلي النصوص بمعاينة حية، ثم احفظي وصدّري — كل ذلك على جهازك دون إنترنت.</p>
          <button className="btn-gold mt-4" onClick={() => navigate('/explore')}>
            <Compass size={18} /> ابدئي التصميم
          </button>
        </div>
      </section>

      <section className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {shortcuts.map(({ to, label, desc, icon: Icon, tone }) => (
          <Link key={to} to={to} className={`rounded-2xl border border-[#e3ebe7] p-4 shadow-soft hover:shadow-lift transition ${tone}`}>
            <Icon size={22} />
            <div className="mt-3 font-bold text-sm">{label}</div>
            <div className="text-[11px] opacity-75 mt-0.5 leading-5">{desc}</div>
          </Link>
        ))}
      </section>

      <section>
        <h3 className="section-title mb-3">إحصاءات حية</h3>
        {stats.loading && !s ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="h-24 rounded-2xl skeleton" />
            ))}
          </div>
        ) : stats.error ? (
          <div className="card-ui p-4 text-sm text-red-700">تعذر قراءة الإحصاءات: {stats.error.message}</div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Stat icon={LayoutTemplate} label="القوالب المخزنة" value={s.templates} sub="+ توليد محلي غير محدود" to="/explore" />
            <Stat icon={Heart} label="المفضلة" value={`${s.favorites} / ${LIMITS.favorites}`} to="/favorites" />
            <Stat icon={Mail} label="الدعوات المحفوظة" value={`${s.invitations} / ${LIMITS.invitations}`} to="/invitations" />
            <Link to="/storage" className="card-ui p-4 hover:shadow-lift transition">
              <div className="flex items-center gap-2 text-ink-mute text-xs font-semibold">
                <HardDrive size={16} className="text-brand" /> التخزين
              </div>
              <div className="mt-2 text-lg font-extrabold text-ink">{formatBytes(s.storage.total)}</div>
              <div className="mt-2 h-2 rounded-full bg-canvas-deep overflow-hidden">
                <div className="h-full bg-brand rounded-full" style={{ width: `${Math.max(2, pct)}%` }} />
              </div>
              <div className="text-[11px] text-ink-mute mt-1">من 50 م.ب — متبقٍ {formatBytes(s.storage.remaining)}</div>
            </Link>
          </div>
        )}
      </section>

      <section>
        <h3 className="section-title mb-3">آخر دعوة محفوظة</h3>
        {s?.last ? (
          <div className="card-ui p-4 flex gap-4 items-center">
            <div className="w-24 shrink-0">
              <FitHtml template={s.last.template} state={s.last.state} noAnim />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-ink truncate">{s.last.title}</div>
              <div className="text-xs text-ink-mute mt-1">آخر تعديل: {formatDate(s.last.updatedAt)} — {s.last.mode === 'simple' ? 'تحرير مبسط' : 'تحرير كامل'}</div>
              <button className="btn-primary mt-3" onClick={() => navigate(`/edit/${s.last.mode || 'full'}?inv=${encodeURIComponent(s.last.id)}`)}>
                <PenLine size={16} /> متابعة التعديل
              </button>
            </div>
          </div>
        ) : (
          <div className="card-ui p-6 text-center">
            <p className="muted">لا توجد دعوات محفوظة بعد.</p>
            <Link to="/explore" className="btn-soft mt-3">
              استكشف القوالب وابدئي أول دعوة
            </Link>
          </div>
        )}
      </section>
    </div>
  );
}
