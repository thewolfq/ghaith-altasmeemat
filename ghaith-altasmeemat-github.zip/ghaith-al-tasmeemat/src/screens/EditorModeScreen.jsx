import React, { useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Zap, Layers, ArrowLeft, Compass } from 'lucide-react';
import { getPendingTemplate } from '../lib/session.js';
import FitHtml from '../components/FitHtml.jsx';

// شاشة اختيار مسار التحرير — [F1-S5]: إلزامية ومنفصلة قبل فتح أي قالب.
export default function EditorModeScreen() {
  const navigate = useNavigate();
  const template = useMemo(() => getPendingTemplate(), []);

  if (!template) {
    return (
      <div className="card-ui p-8 text-center max-w-md mx-auto">
        <p className="muted">لم يتم اختيار قالب بعد.</p>
        <Link to="/explore" className="btn-primary mt-4">
          <Compass size={16} /> اختاري قالباً من الاستكشاف
        </Link>
      </div>
    );
  }

  const options = [
    {
      id: 'simple',
      tag: 'المسار (أ)',
      title: 'تحرير مبسط',
      icon: Zap,
      desc: 'واجهة خفيفة وسريعة: تعديل النصوص فوراً داخل القالب، منتقي ألوان عام، ومنتقي شكل الأحرف والمونوغرام. مناسب للتعديل السريع على قالب جاهز.',
      points: ['النصوص كلها', 'لوحة ألوان عامة', 'المونوغرام وشكل الأحرف'],
    },
    {
      id: 'full',
      tag: 'المسار (ب)',
      title: 'تحرير كامل',
      icon: Layers,
      desc: 'تبويبات منفصلة معزولة: النصوص، الألوان، الخطوط وأشكال الأحرف، الصور، الزخارف والحواف، الصوت والفيديو — مع حفظ اختياري لكل تبويب وتراجع/إعادة مركزي.',
      points: ['6 تبويبات معزولة', 'تنسيق تلقائي بنقاط ارتكاز', 'Undo/Redo متعدد الخطوات'],
    },
  ];

  return (
    <div className="grid lg:grid-cols-[320px_1fr] gap-5 items-start fade-up">
      <div className="card-ui p-3 max-w-[280px] mx-auto w-full lg:sticky lg:top-20">
        <FitHtml template={template} />
        <div className="text-center mt-2 font-bold text-sm text-ink">{template.title}</div>
        <div className="text-center text-xs text-ink-mute">{template.occasion}</div>
      </div>
      <div className="space-y-3">
        <p className="muted">اختاري طريقة التحرير قبل فتح القالب. لا يمكن الخلط بين الواجهتين داخل الجلسة نفسها إلا بالرجوع وإعادة الاختيار.</p>
        {options.map(({ id, tag, title, icon: Icon, desc, points }) => (
          <button key={id} className="card-ui w-full text-right p-5 hover:shadow-lift hover:border-brand/40 transition group" onClick={() => navigate(`/edit/${id}`)}>
            <div className="flex items-start gap-4">
              <div className={`rounded-2xl p-3 ${id === 'simple' ? 'bg-gold-light text-[#8a6a2f]' : 'bg-brand-soft text-brand'}`}>
                <Icon size={26} />
              </div>
              <div className="flex-1">
                <div className="text-xs font-bold text-ink-mute">{tag}</div>
                <div className="text-lg font-extrabold text-ink">{title}</div>
                <p className="text-sm text-ink-soft leading-7 mt-1">{desc}</p>
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {points.map((p) => (
                    <span key={p} className="chip-off pointer-events-none">
                      {p}
                    </span>
                  ))}
                </div>
              </div>
              <ArrowLeft className="text-ink-mute group-hover:text-brand transition mt-2" size={20} />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
