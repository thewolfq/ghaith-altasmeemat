import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Undo2, Redo2, Save, Check, X, Compass, Loader2, RotateCcw, History, Eye, PenLine, ChevronDown } from 'lucide-react';
import { db } from '../lib/db.js';
import { EditorStore, useEditorStore } from '../lib/editorStore.js';
import { initialStateFor, missingRequired, templateMeta } from '../lib/compose.js';
import { getPendingTemplate, setVideoSource, setEditorDraft, takeEditorDraft } from '../lib/session.js';
import { setLeaveGuard } from '../lib/leaveGuard.js';
import { useAppData } from '../components/AppData.jsx';
import { useToast } from '../components/Toast.jsx';
import { useConfirm } from '../components/ConfirmDialog.jsx';
import FitHtml from '../components/FitHtml.jsx';
import EditorTabs, { TABS, TabPanel, TextFields, GlobalColors } from '../components/EditorTabs.jsx';
import MonogramPicker from '../components/MonogramPicker.jsx';
import ExportBar from '../components/ExportBar.jsx';

function cleanTemplate(t) {
  const c = { ...t };
  delete c._score;
  return JSON.parse(JSON.stringify(c));
}

/** محمّل المحرر: دعوة محفوظة (?inv=) أو قالب جديد من شاشة اختيار المسار */
export default function FillScreen() {
  const { mode } = useParams();
  const [params] = useSearchParams();
  const invParam = params.get('inv');
  const [load, setLoad] = useState({ status: 'loading' });

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        if (invParam) {
          const rec = await db.invitations.get(invParam);
          if (!rec) throw new Error('الدعوة غير موجودة — ربما حُذفت.');
          if (alive) setLoad({ status: 'ready', template: rec.template, state: { ...initialStateFor(rec.template), ...rec.state }, invId: rec.id, title: rec.title });
        } else {
          const t = getPendingTemplate();
          if (!t) throw new Error('none');
          if (alive) setLoad({ status: 'ready', template: t, state: initialStateFor(t), invId: null, title: '' });
        }
      } catch (e) {
        if (alive) setLoad({ status: 'error', message: e.message });
      }
    })();
    return () => {
      alive = false;
    };
    // تحميل مرة واحدة لكل فتح للمحرر (يتجنب إعادة التحميل بعد تحديث الرابط عند الحفظ)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (mode !== 'simple' && mode !== 'full') {
    return (
      <div className="card-ui p-8 text-center">
        <p className="muted">مسار تحرير غير معروف.</p>
        <Link className="btn-primary mt-3" to="/mode">
          اختيار المسار
        </Link>
      </div>
    );
  }
  if (load.status === 'loading') {
    return (
      <div className="flex justify-center py-20 text-brand">
        <Loader2 className="animate-spin" size={30} />
      </div>
    );
  }
  if (load.status === 'error') {
    return (
      <div className="card-ui p-8 text-center max-w-md mx-auto">
        <p className="muted">{load.message === 'none' ? 'لا يوجد قالب مفتوح للتحرير.' : load.message}</p>
        <div className="flex gap-2 justify-center mt-4">
          <Link to="/explore" className="btn-primary">
            <Compass size={16} /> الاستكشاف
          </Link>
          <Link to="/invitations" className="btn-outline">
            دعواتي
          </Link>
        </div>
      </div>
    );
  }
  return <Editor mode={mode} initial={load} />;
}

function Editor({ mode, initial }) {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToast();
  const confirm = useConfirm();
  const { saveInvitationSafe } = useAppData();
  const template = initial.template;
  const draftKey = `${mode}|${initial.invId || 'new'}|${template.id}`;

  const restored = useMemo(() => takeEditorDraft(draftKey), [draftKey]);
  const storeRef = useRef(null);
  if (!storeRef.current) {
    const st = new EditorStore(restored ? restored.state : initial.state);
    if (restored) st.lastSavedSignature = restored.savedSignature;
    storeRef.current = st;
  }
  const store = useEditorStore(storeRef.current);
  const meta = useMemo(() => templateMeta(template), [template]);
  const [invId, setInvId] = useState(restored?.invId ?? initial.invId);
  const [title, setTitle] = useState(restored?.title ?? (initial.title || template.title || 'دعوتي'));
  const [titleDirty, setTitleDirty] = useState(false);
  const [activeTab, setActiveTab] = useState(mode === 'full' ? restored?.tab || null : null);
  const [saving, setSaving] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [mobileView, setMobileView] = useState('edit');
  const [simpleOpen, setSimpleOpen] = useState({ text: true, colors: false, mono: false });

  // استعادة جلسة التبويب عند الرجوع من شاشة الفيديو
  useEffect(() => {
    if (mode === 'full' && activeTab && !store.session) store.beginTab(activeTab);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const dirty = store.isDirtySinceSave() || titleDirty || !invId;
  const tabDirty = store.isTabDirty();
  const tabLabel = (id) => TABS.find((t) => t.id === id)?.label || '';

  // حارس المغادرة
  useEffect(() => {
    const unsub = setLeaveGuard(async () => {
      if (!(store.isDirtySinceSave() || titleDirty)) return true;
      return confirm({ title: 'مغادرة المحرر؟', message: 'لديكِ تعديلات غير محفوظة في الدعوة. ستضيع إذا غادرتِ الآن.', confirmText: 'مغادرة دون حفظ', cancelText: 'البقاء', danger: true });
    });
    const onUnload = (e) => {
      if (store.isDirtySinceSave() || titleDirty) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', onUnload);
    return () => {
      unsub();
      window.removeEventListener('beforeunload', onUnload);
    };
  }, [store, titleDirty, confirm]);

  // ===== التبويبات (مسار كامل) =====
  const openTab = async (id) => {
    if (id === activeTab) return;
    if (store.session) {
      if (store.isTabDirty()) {
        const keep = await confirm({ title: `تعديلات تبويب «${tabLabel(activeTab)}»`, message: 'هل تريدين اعتماد تعديلات هذا التبويب قبل الانتقال؟ اختيار «تجاهل» يحذفها فقط دون المساس ببقية التبويبات.', confirmText: 'اعتماد وحفظ التبويب', cancelText: 'تجاهل التعديلات' });
        if (keep === null) return;
        if (keep) store.saveTab();
        else store.discardTab();
      } else store.discardTab();
    }
    store.beginTab(id);
    setActiveTab(id);
  };
  const saveTab = () => {
    store.saveTab();
    toast(`اعتُمدت تعديلات «${tabLabel(activeTab)}»`);
    setActiveTab(null);
  };
  const discardTab = () => {
    store.discardTab();
    toast('تم تجاهل تعديلات التبويب', 'info');
    setActiveTab(null);
  };

  // ===== الحفظ =====
  const save = useCallback(async () => {
    if (saving) return;
    if (store.session && store.isTabDirty()) {
      const keep = await confirm({ title: 'تبويب بتعديلات غير معتمدة', message: `تبويب «${tabLabel(store.activeTab)}» يحتوي تعديلات لم تُعتمد بعد. اعتمادها وتضمينها في الحفظ؟`, confirmText: 'اعتماد وحفظ', cancelText: 'حفظ بدونها' });
      if (keep === null) return;
      if (keep) store.saveTab();
      else store.discardTab();
      setActiveTab(null);
    }
    const missing = missingRequired(template, store.state.values);
    if (missing.length) {
      toast(`أكملي الحقول الإلزامية: ${missing.map((f) => f.label).join('، ')}`, 'error', 4500);
      return;
    }
    setSaving(true);
    try {
      const record = {
        ...(invId ? { id: invId } : {}),
        title: title.trim() || template.title || 'دعوتي',
        templateId: template.id,
        occasion: template.occasion,
        mode,
        template: cleanTemplate(template),
        state: store.snapshot(),
      };
      const row = await saveInvitationSafe(record);
      if (row) {
        store.markSaved();
        setTitleDirty(false);
        if (!invId) {
          setInvId(row.id);
          navigate(`/edit/${mode}?inv=${row.id}`, { replace: true });
        }
        toast(invId ? 'تم تحديث الدعوة في مكانها' : 'تم حفظ الدعوة في «دعواتي»');
      }
    } catch (e) {
      toast(`تعذر الحفظ: ${e.message}`, 'error');
    } finally {
      setSaving(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [saving, store, template, title, invId, mode]);

  // اختصارات لوحة المفاتيح
  useEffect(() => {
    const onKey = (e) => {
      const mod = e.ctrlKey || e.metaKey;
      if (!mod) return;
      // e.code يعمل مع لوحة المفاتيح العربية أيضاً
      const k = { KeyZ: 'z', KeyY: 'y', KeyS: 's' }[e.code] || e.key.toLowerCase();
      if (k === 'z' && !e.shiftKey) {
        e.preventDefault();
        store.undo();
      } else if (k === 'y' || (k === 'z' && e.shiftKey)) {
        e.preventDefault();
        store.redo();
      } else if (k === 's') {
        e.preventDefault();
        save();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [store, save]);

  const openVideo = () => {
    const state = store.snapshot();
    setEditorDraft({ key: draftKey, state, savedSignature: store.lastSavedSignature, invId, title, tab: null });
    if (store.session) store.saveTab();
    setVideoSource({ template: cleanTemplate(template), state, title, media: state.media || null, returnTo: `${location.pathname}${invId ? `?inv=${invId}` : location.search}` });
    setLeaveGuard(null);
    navigate('/video');
  };

  const resetAll = async () => {
    const ok = await confirm({ title: 'إعادة القالب لحالته الأصلية؟', message: 'تُستبدل كل القيم والألوان والخطوط بإعدادات القالب الافتراضية (يمكن التراجع بعدها).', confirmText: 'إعادة', danger: true });
    if (!ok) return;
    const base = initialStateFor(template);
    store.exec(Object.keys({ ...base, ...store.state }).map((k) => ({ path: k, value: base[k] })), { tab: activeTab || 'general', label: 'إعادة للأصل' });
  };

  const state = store.state;
  const info = store.historyInfo();

  const toolbar = (
    <div className="card-ui p-2.5 flex flex-wrap items-center gap-2">
      <input className="input flex-1 min-w-[150px] py-2" value={title} onChange={(e) => { setTitle(e.target.value); setTitleDirty(true); }} aria-label="اسم الدعوة" placeholder="اسم الدعوة" />
      <div className="flex items-center gap-1">
        <button className="btn-icon disabled:opacity-30" onClick={() => store.undo()} disabled={!store.canUndo()} title="تراجع (Ctrl+Z)" aria-label="تراجع">
          <Undo2 size={19} />
        </button>
        <button className="btn-icon disabled:opacity-30" onClick={() => store.redo()} disabled={!store.canRedo()} title="إعادة (Ctrl+Y)" aria-label="إعادة">
          <Redo2 size={19} />
        </button>
        <button className={`btn-icon ${showHistory ? 'text-brand' : ''}`} onClick={() => setShowHistory((v) => !v)} title="سجل التعديلات" aria-label="سجل التعديلات">
          <History size={19} />
        </button>
        <button className="btn-icon" onClick={resetAll} title="إعادة للأصل" aria-label="إعادة القالب للأصل">
          <RotateCcw size={18} />
        </button>
      </div>
      <button className="btn-primary py-2" onClick={save} disabled={saving}>
        {saving ? <Loader2 size={16} className="animate-spin" /> : dirty ? <Save size={16} /> : <Check size={16} />} {invId ? (dirty ? 'حفظ التعديلات' : 'محفوظة') : 'حفظ الدعوة'}
      </button>
    </div>
  );

  const historyPanel = showHistory && (
    <div className="card-ui p-3 max-h-52 overflow-y-auto">
      <div className="text-xs font-bold text-ink-soft mb-2">سجل التعديلات ({info.pointer}/{info.total})</div>
      {info.labels.length === 0 ? (
        <p className="text-xs text-ink-mute">لا توجد تعديلات بعد.</p>
      ) : (
        <ol className="space-y-1">
          {info.labels.map((c, i) => (
            <li key={c.id} className={`text-xs flex items-center gap-2 ${c.applied ? 'text-ink' : 'text-ink-mute line-through'}`}>
              <span className="w-5 text-ink-mute">{i + 1}</span>
              <span className="flex-1">{c.label}</span>
              <span className="text-[10px] text-ink-mute">{tabLabel(c.tab) || (c.tab === 'simple' ? 'مبسط' : '')}</span>
              {!c.committed && <span className="text-[10px] text-gold-dark">مسودة</span>}
            </li>
          ))}
        </ol>
      )}
    </div>
  );

  const preview = (
    <div className="lg:sticky lg:top-20 space-y-3">
      <div className="mx-auto w-full max-w-[330px]">
        <div className="rounded-2xl shadow-lift overflow-hidden bg-white">
          <FitHtml template={template} state={state} noAnim rounded={false} />
        </div>
      </div>
      <div className="flex justify-center">
        <ExportBar template={template} getState={() => store.snapshot()} title={title} onVideo={openVideo} compact />
      </div>
    </div>
  );

  const section = (id, label, body) => (
    <div className="card-ui overflow-hidden">
      <button className="w-full flex items-center justify-between px-4 py-3 font-bold text-ink" onClick={() => setSimpleOpen((s) => ({ ...s, [id]: !s[id] }))} aria-expanded={simpleOpen[id]}>
        {label}
        <ChevronDown size={18} className={`transition ${simpleOpen[id] ? 'rotate-180' : ''}`} />
      </button>
      {simpleOpen[id] && <div className="px-4 pb-4">{body}</div>}
    </div>
  );

  const controls =
    mode === 'simple' ? (
      <div className="space-y-3">
        {section('text', 'النصوص', <TextFields store={store} meta={meta} tab="simple" />)}
        {section('colors', 'الألوان (منتقي عام)', <GlobalColors store={store} tab="simple" template={template} />)}
        {section(
          'mono',
          'المونوغرام وشكل الأحرف',
          <MonogramPicker
            mono={state.mono}
            names={state.values}
            vars={{ '--c1': state.colors?.c1 || template.palette?.c1, '--c2': state.colors?.c2 || template.palette?.c2, '--bg': state.colors?.bg || template.palette?.bg }}
            onChange={(patch) => {
              const ops = Object.entries(patch).map(([k, v]) => ({ path: `mono.${k}`, value: v }));
              if (!meta.hasMono && patch.enabled) ops.push({ path: 'monoOverlay', value: true });
              store.exec(ops, { tab: 'simple', label: 'المونوغرام', coalesceKey: Object.keys(patch).join(',') === 'size' ? 'mono-size' : null });
            }}
          />,
        )}
        <p className="text-[11px] text-ink-mute text-center">للتحكم في الخطوط والصور والزخارف والفيديو استخدمي مسار «التحرير الكامل».</p>
      </div>
    ) : (
      <div className="space-y-3">
        <div className="card-ui p-3">
          <EditorTabs active={activeTab} dirty={tabDirty} onSelect={openTab} />
        </div>
        {activeTab ? (
          <div className="card-ui p-4 fade-up" key={activeTab}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-extrabold text-ink">{tabLabel(activeTab)}</h3>
              <span className={`text-[11px] rounded-full px-2 py-0.5 ${tabDirty ? 'bg-gold-light text-[#7a5a22]' : 'bg-canvas text-ink-mute'}`}>{tabDirty ? 'مسودة غير معتمدة' : 'لا تعديلات'}</span>
            </div>
            <TabPanel id={activeTab} store={store} meta={meta} tab={activeTab} template={template} onOpenVideo={openVideo} />
            <div className="flex gap-2 mt-5 pt-4 border-t border-[#eef3f1]">
              <button className="btn-primary flex-1" onClick={saveTab}>
                <Check size={16} /> حفظ التبويب
              </button>
              <button className="btn-outline flex-1" onClick={discardTab}>
                <X size={16} /> {tabDirty ? 'تجاهل التعديلات' : 'إغلاق'}
              </button>
            </div>
          </div>
        ) : (
          <div className="card-ui p-6 text-center">
            <PenLine className="mx-auto text-brand" size={28} />
            <p className="font-bold text-ink mt-2">اختاري تبويباً للبدء</p>
            <p className="text-xs text-ink-mute mt-1 leading-6">كل تبويب مسودة معزولة: «حفظ التبويب» يعتمد تعديلاته، و«تجاهل» يحذفها وحده دون المساس بالتبويبات الأخرى. التراجع والإعادة مركزيان هنا عبر كل التبويبات المعتمدة.</p>
          </div>
        )}
      </div>
    );

  return (
    <div className="space-y-3">
      {toolbar}
      {historyPanel}
      <div className="lg:hidden flex rounded-xl bg-white border border-[#e3ebe7] p-1">
        {[
          ['edit', 'التحرير', PenLine],
          ['preview', 'المعاينة والتصدير', Eye],
        ].map(([id, l, I]) => (
          <button key={id} className={`flex-1 rounded-lg py-2 text-sm font-semibold flex items-center justify-center gap-1.5 ${mobileView === id ? 'bg-brand text-white' : 'text-ink-soft'}`} onClick={() => setMobileView(id)}>
            <I size={15} /> {l}
          </button>
        ))}
      </div>
      <div className="grid lg:grid-cols-[minmax(0,1fr)_380px] gap-4 items-start">
        <div className={mobileView === 'edit' ? '' : 'hidden lg:block'}>
          {/* معاينة مصغرة ثابتة على الجوال أثناء التحرير */}
          <div className="lg:hidden sticky top-16 z-10 flex justify-center mb-3 pointer-events-none">
            <div className="w-[118px] rounded-xl overflow-hidden shadow-lift bg-white border-2 border-white">
              <FitHtml template={template} state={state} noAnim rounded={false} />
            </div>
          </div>
          {controls}
        </div>
        <div className={mobileView === 'preview' ? '' : 'hidden lg:block'}>{preview}</div>
      </div>
    </div>
  );
}
