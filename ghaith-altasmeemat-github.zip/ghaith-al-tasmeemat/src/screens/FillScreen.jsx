import { useEffect, useMemo, useState } from 'react';
import { ArrowRight, Check, CircleAlert, Save, Sparkles } from 'lucide-react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { db, saveInvitation } from '../lib/db.js';
import { extractFields, fileToDataUri, hasMonoSlot, renderFilledHtml } from '../lib/templateUtils.js';
import { MONO_CHOICES, MONO_FONTS, monoLetters } from '../lib/monograms.js';
import { FitHtml } from '../components/FitHtml.jsx';

export function FillScreen() {
  const { id } = useParams(), location = useLocation(), navigate = useNavigate();
  const invitation = location.state?.invitation || null;
  const [template, setTemplate] = useState(null), [fields, setFields] = useState([]), [values, setValues] = useState({});
  const [confirmed, setConfirmed] = useState({}), [message, setMessage] = useState(''), [saving, setSaving] = useState(false), [play, setPlay] = useState(0);

  useEffect(() => {
    let live = true;
    (async () => {
      // قالب الدعوة المحفوظة أولاً: القوالب المولّدة تُستبدل عند كل تحديث للقائمة
      let item = invitation?.templateId === id ? invitation.template : null;
      if (!item) item = await db.templates.get(id);
      if (!item) { const fav = await db.favorites.where('templateId').equals(id).first(); item = fav?.template; }
      if (!item) { const inv = await db.invitations.where('templateId').equals(id).first(); item = inv?.template; }
      if (!live || !item) return;
      setTemplate(item);
      const parsed = extractFields(item.html);
      setFields(parsed);
      setValues(invitation?.values || Object.fromEntries(parsed.map((f) => [f.key, f.defaultValue])));
      setConfirmed(invitation?.values ? Object.fromEntries(parsed.map((f) => [f.key, true])) : {});
    })();
    return () => { live = false; };
  }, [id, invitation]);

  const complete = useMemo(() => fields.filter((f) => f.required).every((f) => String(values[f.key] || '').trim() && confirmed[f.key]), [fields, values, confirmed]);
  const change = (key, value) => { setValues((o) => ({ ...o, [key]: value })); setConfirmed((o) => ({ ...o, [key]: true })); };
  const keep = (key) => setConfirmed((o) => ({ ...o, [key]: true }));
  const hasMono = template ? hasMonoSlot(template.html) : false;
  const auto = useMemo(() => monoLetters(values), [values]);
  const style = String(values.__mono || 'auto');
  const duo = style === 'auto' || style.startsWith('duo:');
  const setMono = (patch) => setValues((o) => ({ ...o, ...patch }));

  async function save() {
    if (!complete) return;
    setSaving(true); setMessage('');
    try {
      await saveInvitation({ id: invitation?.id, templateId: id, title: template.title, occasion: template.occasion, template, values: { ...values }, createdAt: invitation?.createdAt });
      navigate('/invitations', { replace: true });
    } catch (e) { setMessage(e.message || 'تعذّر حفظ الدعوة.'); }
    finally { setSaving(false); }
  }

  if (!template) return (
    <div className="empty-state"><div className="empty-icon"><CircleAlert /></div><h3>القالب غير موجود</h3>
      <p>قد يكون قد حُذف من التخزين المحلي.</p><Link className="button button-primary" to="/explore">العودة للاستكشاف</Link></div>
  );

  return (
    <div className="page-stack">
      <Link className="back-link" to="/explore"><ArrowRight size={16} /> العودة للقوالب</Link>
      <div className="page-intro">
        <span className="eyebrow">{invitation ? 'تعديل دعوة محفوظة' : 'خطوتك الأخيرة'}</span>
        <h2>أكمل تفاصيل الدعوة</h2>
        <p>القيم المقترحة تحتاج إلى تأكيد منك قبل حفظ الدعوة.</p>
      </div>

      <div className="fill-layout">
        <section className="fill-form panel">
          <div className="fill-heading"><div className="section-icon"><Sparkles size={18} /></div>
            <div><h3>{template.title}</h3><p>املأ الحقول أو احتفظ بالقيمة المقترحة.</p></div></div>

          {hasMono && (
            <div className="mono-box">
              <div className="mono-box-head"><b>✦ المونوغرام</b><span>حرف الزوج + حرف الزوجة، يتغيّران وحدهما ويمكنك كتابتهما</span></div>
              <div className="mono-letters">
                <label><span>الحرف الأول</span><input maxLength={2} dir="rtl" value={values.__m1 ?? ''} placeholder={auto[0]} onChange={(e) => setMono({ __m1: [...e.target.value.trim()][0] || '' })} /></label>
                <label><span>الحرف الثاني</span><input maxLength={2} dir="rtl" value={values.__m2 ?? ''} placeholder={auto[1] || '—'} onChange={(e) => setMono({ __m2: [...e.target.value.trim()][0] || '' })} /></label>
              </div>
              <div className="mono-grid2">
                <label className="mono-field"><span>طريقة الدمج</span>
                  <select value={style} onChange={(e) => setMono({ __mono: e.target.value })}>
                    {MONO_CHOICES.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}
                  </select></label>
                {duo && (
                  <label className="mono-field"><span>خط الحرفين</span>
                    <select value={values.__mfont ?? 0} onChange={(e) => setMono({ __mfont: Number(e.target.value) })}>
                      {MONO_FONTS.map((f, i) => <option key={f.label} value={i}>{f.label}</option>)}
                    </select></label>
                )}
              </div>
            </div>
          )}

          {fields.length ? (
            <div className="field-table">
              {fields.map((field, index) => (
                <div className="field-row" key={field.key}>
                  <div className="field-number">{String(index + 1).padStart(2, '0')}</div>
                  <div className="fill-field">
                    <label htmlFor={`field-${field.key}`}>{field.label}{field.required && <span className="required-star"> *</span>}</label>
                    {field.type === 'image' ? (
                      <div>
                        <input id={`field-${field.key}`} type="file" accept="image/*" onChange={async (e) => {
                          const f = e.target.files?.[0];
                          if (f) { try { change(field.key, await fileToDataUri(f)); } catch { setMessage('تعذّر قراءة الصورة.'); } }
                        }} />
                        {values[field.key] && <small>تم اختيار الصورة ✓</small>}
                      </div>
                    ) : (
                      <input id={`field-${field.key}`} value={values[field.key] ?? ''} onChange={(e) => change(field.key, e.target.value)} placeholder={`اكتب ${field.label}`} />
                    )}
                    {!confirmed[field.key]
                      ? <span className="unconfirmed"><CircleAlert size={13} /> غير مؤكد · قيمة مقترحة: {field.defaultValue || 'فارغة'}</span>
                      : <span className="confirmed"><Check size={13} /> تم التأكيد</span>}
                  </div>
                  <button className={`keep-button ${confirmed[field.key] ? 'kept' : ''}`} onClick={() => keep(field.key)}>
                    <Check size={14} />{confirmed[field.key] ? 'تم' : 'احتفظ'}
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="alert alert-warning">لم نعثر على حقول data-field في القالب. اختر قالباً آخر.</div>
          )}

          <div className="save-row">
            <p>{complete ? 'اكتملت الحقول الإلزامية.' : 'أكّد الحقول المطلوبة (*) لتفعيل الحفظ.'}</p>
            <button className="button button-primary" disabled={!complete || saving} onClick={save}>
              <Save size={16} />{saving ? 'جارٍ الحفظ…' : invitation ? 'تحديث الدعوة' : 'حفظ الدعوة'}
            </button>
          </div>
          {message && <div className="alert alert-error">{message}</div>}
        </section>

        <aside className="fill-preview panel">
          <div className="preview-header">
            <span className="eyebrow">معاينة مباشرة</span>
            <button type="button" className="button button-outline button-sm" onClick={() => setPlay((p) => p + 1)}>▶ إعادة التشغيل</button>
          </div>
          <div className="invitation-paper"><FitHtml key={play} className="paper-content" html={renderFilledHtml(template.html, values)} /></div>
          <small>قالب: {template.title}</small>
        </aside>
      </div>
    </div>
  );
}
