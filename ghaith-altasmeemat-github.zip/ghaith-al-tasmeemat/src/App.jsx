import React, { useEffect, useState } from 'react';
import { Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import AppLayout from './components/AppLayout.jsx';
import { ToastProvider } from './components/Toast.jsx';
import { ConfirmProvider } from './components/ConfirmDialog.jsx';
import { AppDataProvider } from './components/AppData.jsx';
import SplashScreen from './screens/SplashScreen.jsx';
import HomeScreen from './screens/HomeScreen.jsx';
import ExploreScreen from './screens/ExploreScreen.jsx';
import EditorModeScreen from './screens/EditorModeScreen.jsx';
import FillScreen from './screens/FillScreen.jsx';
import FavoritesScreen from './screens/FavoritesScreen.jsx';
import InvitationsScreen from './screens/InvitationsScreen.jsx';
import SettingsScreen from './screens/SettingsScreen.jsx';
import AboutScreen from './screens/AboutScreen.jsx';
import StorageScreen from './screens/StorageScreen.jsx';
import CloneScreen from './screens/CloneScreen.jsx';
import VideoScreen from './screens/VideoScreen.jsx';
import { isFirstLaunchDone, markFirstLaunchDone } from './lib/db.js';
import { seedIfNeeded, loadInstalledFonts } from './lib/assets.js';

export default function App() {
  const [showSplash, setShowSplash] = useState(() => !isFirstLaunchDone());
  const [ready, setReady] = useState(false);
  const [bootError, setBootError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        await seedIfNeeded();
        await loadInstalledFonts();
      } catch (e) {
        if (alive) setBootError(e?.message || 'تعذر تجهيز البيانات المحلية');
      } finally {
        if (alive) setReady(true);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  if (showSplash) {
    return (
      <SplashScreen
        ready={ready}
        onEnter={() => {
          markFirstLaunchDone();
          setShowSplash(false);
          navigate('/', { replace: true });
        }}
      />
    );
  }

  if (!ready) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-3 text-ink-soft">
        <div className="w-10 h-10 rounded-full border-4 border-brand/20 border-t-brand animate-spin" />
        <div className="text-sm">جارٍ تجهيز الأصول المحلية…</div>
      </div>
    );
  }

  return (
    <ToastProvider>
      <ConfirmProvider>
        <AppDataProvider>
          {bootError && <div className="bg-amber-50 text-amber-800 text-sm text-center py-2 px-3">{bootError} — يمكنك استعادة الأصول من إدارة التخزين.</div>}
          <Routes>
            <Route element={<AppLayout />}>
              <Route index element={<HomeScreen />} />
              <Route path="explore" element={<ExploreScreen />} />
              <Route path="mode" element={<EditorModeScreen />} />
              <Route path="edit/:mode" element={<FillScreen />} />
              <Route path="favorites" element={<FavoritesScreen />} />
              <Route path="invitations" element={<InvitationsScreen />} />
              <Route path="settings" element={<SettingsScreen />} />
              <Route path="about" element={<AboutScreen />} />
              <Route path="storage" element={<StorageScreen />} />
              <Route path="clone" element={<CloneScreen />} />
              <Route path="video" element={<VideoScreen />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Route>
          </Routes>
        </AppDataProvider>
      </ConfirmProvider>
    </ToastProvider>
  );
}
