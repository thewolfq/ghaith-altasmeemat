import React, { useEffect, useState } from 'react';
import { Wand2 } from 'lucide-react';
import { MONO_FAMILIES, MONO_STYLES, renderMonogram, ensureMonoMetrics, deriveLetters } from '../lib/monograms.js';
import ColorPicker from './ColorPicker.jsx';

function MiniMono({ mono, size = 64, vars }) {
  return (
    <div className="pointer-events-none" style={{ ...vars, '--mono-size': `${size}px`, width: size, height: size }} dangerouslySetInnerHTML={{ __html: renderMonogram({ ...mono, enabled: true, size: 1 }) }} />
  );
}

/** منتقي المونوغرام وشكل الأحرف: 6 عائلات + أنماط الدمج + نماذج جاهزة + اشتقاق تلقائي + معاينة فورية */
export default function MonogramPicker({ mono, names = {}, onChange, vars = {} }) {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let alive = true;
    Promise.all(MONO_FAMILIES.map((f) => ensureMonoMetrics({ ...mono, family: f.family }))).then(() => alive && setTick((t) => t + 1));
    return () => {
      alive = false;
    };
  }, [mono.a, mono.b, mono.family]);
  const derived = deriveLetters(names.name1 || '', names.name2 || '');
  const previewVars = { '--c1': vars['--c1'] || '#0f5e4f', '--c2': vars['--c2'] || '#c09743', '--bg': vars['--bg'] || '#ffffff' };

  return (
    <div className="space-y-4" data-tick={tick}>
      <label className="flex items-center gap-2 text-sm font-semibold text-ink">
        <input type="checkbox" className="accent-[#0f766e] w-4 h-4" checked={!!mono.enabled} onChange={(e) => onChange({ enabled: e.target.checked })} />
        إظهار المونوغرام (الحرفان الأولان)
      </label>

      <div>
        <div className="label">الحرفان</div>
        <div className="flex items-center gap-2">
          <input className="input w-16 text-center text-lg" maxLength={2} value={mono.a || ''} onChange={(e) => onChange({ a: e.target.value.trim().slice(0, 2), auto: false })} aria-label="الحرف الأول" />
          <span className="text-ink-mute">+</span>
          <input className="input w-16 text-center text-lg" maxLength={2} value={mono.b || ''} onChange={(e) => onChange({ b: e.target.value.trim().slice(0, 2), auto: false })} aria-label="الحرف الثاني" />
          <button className={`btn text-xs ${mono.auto ? 'bg-brand text-white' : 'btn-outline'}`} onClick={() => onChange({ auto: !mono.auto, ...(mono.auto ? {} : { a: derived.a || mono.a, b: derived.b }) })}>
            <Wand2 size={14} /> تلقائي من الاسمين
          </button>
        </div>
        <p className="text-[11px] text-ink-mute mt-1">التلقائي يشتق الحرفين من أول حرف في الاسمين ({derived.a || '—'} + {derived.b || '—'}) ويتحدث مع الكتابة.</p>
      </div>

      <div>
        <div className="label">عائلة الخط (6)</div>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {MONO_FAMILIES.map((f) => (
            <button key={f.family} style={{ background: previewVars['--bg'] }} className={`rounded-xl border p-2 flex flex-col items-center gap-1 ${mono.family === f.family ? 'border-brand ring-2 ring-brand/20' : 'border-[#e3ebe7]'}`} onClick={() => onChange({ family: f.family })}>
              <MiniMono mono={{ ...mono, family: f.family, style: mono.style }} size={46} vars={previewVars} />
              <span className="text-[10px] rounded bg-white/85 px-1 text-ink-soft">{f.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div>
        <div className="label">نمط دمج الحرفين والنماذج الجاهزة</div>
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
          {MONO_STYLES.map((s) => (
            <button key={s.id} style={{ background: previewVars['--bg'] }} className={`rounded-xl border p-2 flex flex-col items-center gap-1 ${mono.style === s.id ? 'border-brand ring-2 ring-brand/20' : 'border-[#e3ebe7]'}`} onClick={() => onChange({ style: s.id })}>
              <MiniMono mono={{ ...mono, style: s.id }} size={52} vars={previewVars} />
              <span className="text-[10px] rounded bg-white/85 px-1 text-ink-soft text-center leading-4">{s.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <ColorPicker label="لون الحروف" value={mono.color} fallback={previewVars['--c1']} onChange={(v) => onChange({ color: v })} compact />
        <div>
          <div className="label">حجم المونوغرام ({Math.round((mono.size || 1) * 100)}٪)</div>
          <input type="range" min="0.7" max="1.35" step="0.05" value={mono.size || 1} onChange={(e) => onChange({ size: Number(e.target.value) })} className="w-full accent-[#0f766e]" />
        </div>
      </div>
    </div>
  );
}
