import React, { createContext, useCallback, useContext, useRef, useState } from 'react';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';

const ToastCtx = createContext(() => {});

export function ToastProvider({ children }) {
  const [items, setItems] = useState([]);
  const seq = useRef(0);
  const push = useCallback((message, type = 'success', ms = 3200) => {
    const id = ++seq.current;
    setItems((list) => [...list.slice(-2), { id, message, type }]);
    setTimeout(() => setItems((list) => list.filter((t) => t.id !== id)), ms);
  }, []);
  const icons = { success: CheckCircle2, error: AlertTriangle, info: Info };
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="fixed inset-x-0 top-3 z-[90] flex flex-col items-center gap-2 px-3 pointer-events-none" aria-live="polite">
        {items.map((t) => {
          const Icon = icons[t.type] || Info;
          return (
            <div
              key={t.id}
              className={`fade-up pointer-events-auto flex items-start gap-2 rounded-2xl px-4 py-3 text-sm font-semibold shadow-lift max-w-md w-full ${
                t.type === 'error' ? 'bg-red-50 text-red-800 border border-red-200' : t.type === 'info' ? 'bg-white text-ink border border-[#e3ebe7]' : 'bg-brand text-white'
              }`}
            >
              <Icon size={18} className="shrink-0 mt-0.5" />
              <span className="flex-1 leading-6">{t.message}</span>
              <button className="opacity-70 hover:opacity-100" onClick={() => setItems((l) => l.filter((x) => x.id !== t.id))} aria-label="إغلاق">
                <X size={16} />
              </button>
            </div>
          );
        })}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast() {
  return useContext(ToastCtx);
}
