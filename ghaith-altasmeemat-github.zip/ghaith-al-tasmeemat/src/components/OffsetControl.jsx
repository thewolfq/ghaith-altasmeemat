import React from 'react';
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';
import { OFFSET_LIMITS, clampOffset } from '../lib/compose.js';

/** تحريك محدود في 4 اتجاهات + تكبير/تصغير ضمن حدود آمنة — [F1-S8] */
export default function OffsetControl({ value, onChange, label = 'الموضع والحجم' }) {
  const o = clampOffset(value);
  const { step, scaleStep } = OFFSET_LIMITS;
  const upd = (patch) => onChange(clampOffset({ ...o, ...patch }));
  const atEdge = (axis, dir) => (axis === 's' ? (dir > 0 ? o.s >= OFFSET_LIMITS.maxScale : o.s <= OFFSET_LIMITS.minScale) : dir > 0 ? o[axis] >= OFFSET_LIMITS.move : o[axis] <= -OFFSET_LIMITS.move);
  const B = ({ icon: I, onClick, dis, title }) => (
    <button className="btn-icon w-9 h-9 bg-white border border-[#e3ebe7] disabled:opacity-30" onClick={onClick} disabled={dis} title={title} aria-label={title}>
      <I size={16} />
    </button>
  );
  const changed = o.x || o.y || o.s !== 1;
  return (
    <div className="rounded-xl bg-canvas p-3">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-bold text-ink-soft">{label}</span>
        {changed ? (
          <button className="text-[11px] text-ink-mute hover:text-brand inline-flex items-center gap-1" onClick={() => onChange(undefined)}>
            <RotateCcw size={12} /> إعادة
          </button>
        ) : null}
      </div>
      <div className="flex items-center gap-3 flex-wrap">
        <div className="grid grid-cols-3 gap-1 w-[118px]">
          <span />
          <B icon={ArrowUp} title="أعلى" dis={atEdge('y', -1)} onClick={() => upd({ y: o.y - step })} />
          <span />
          <B icon={ArrowRight} title="يمين" dis={atEdge('x', 1)} onClick={() => upd({ x: o.x + step })} />
          <span className="text-[10px] text-ink-mute flex items-center justify-center">{o.x},{o.y}</span>
          <B icon={ArrowLeft} title="يسار" dis={atEdge('x', -1)} onClick={() => upd({ x: o.x - step })} />
          <span />
          <B icon={ArrowDown} title="أسفل" dis={atEdge('y', 1)} onClick={() => upd({ y: o.y + step })} />
          <span />
        </div>
        <div className="flex items-center gap-1">
          <B icon={ZoomOut} title="تصغير" dis={atEdge('s', -1)} onClick={() => upd({ s: +(o.s - scaleStep).toFixed(2) })} />
          <span className="text-xs font-bold w-12 text-center">{Math.round(o.s * 100)}٪</span>
          <B icon={ZoomIn} title="تكبير" dis={atEdge('s', 1)} onClick={() => upd({ s: +(o.s + scaleStep).toFixed(2) })} />
        </div>
      </div>
      <p className="text-[10px] text-ink-mute mt-2">الحركة محدودة بـ ±{OFFSET_LIMITS.move}px والحجم بين {OFFSET_LIMITS.minScale * 100}٪ و{OFFSET_LIMITS.maxScale * 100}٪ للحفاظ على الهوامش الآمنة.</p>
    </div>
  );
}
