import React from 'react';
import { RotateCcw, Check } from 'lucide-react';
import { ALL_PALETTES } from '../lib/tplKit.js';

const SWATCHES = ['#0f5e4f', '#0f766e', '#2f6f5e', '#a24b5d', '#5a1f2e', '#bb5b55', '#86662b', '#c8a157', '#d6a85f', '#1e3a8a', '#0f1f3d', '#2c5282', '#6b4c9a', '#3b1f4a', '#8a4f7d', '#3f4a48', '#5c5145', '#161513', '#ffffff', '#fbf6ea', '#f3f8f4', '#fdf5f3'];

/** منتقي لون: عينات جاهزة + منتقي النظام + إعادة للافتراضي */
export default function ColorPicker({ label, value, fallback = '#888888', onChange, compact = false }) {
  const current = value || fallback;
  return (
    <div>
      {label && (
        <div className="flex items-center justify-between mb-1.5">
          <span className="label mb-0">{label}</span>
          {value && (
            <button className="text-[11px] text-ink-mute hover:text-brand inline-flex items-center gap-1" onClick={() => onChange('')}>
              <RotateCcw size={12} /> افتراضي
            </button>
          )}
        </div>
      )}
      <div className="flex items-center gap-2 flex-wrap">
        <label className="relative w-9 h-9 rounded-full border-2 border-white shadow-soft overflow-hidden cursor-pointer shrink-0" style={{ background: current }} title="اختيار لون مخصص">
          <input type="color" className="absolute inset-0 opacity-0 cursor-pointer" value={/^#[0-9a-f]{6}$/i.test(current) ? current : '#888888'} onChange={(e) => onChange(e.target.value)} aria-label={label || 'لون'} />
        </label>
        {!compact &&
          SWATCHES.map((c) => (
            <button key={c} className={`w-6 h-6 rounded-full border ${current.toLowerCase() === c ? 'ring-2 ring-brand ring-offset-1' : 'border-black/10'}`} style={{ background: c }} onClick={() => onChange(c)} aria-label={`لون ${c}`} />
          ))}
      </div>
    </div>
  );
}

/** لوحات ألوان كاملة جاهزة (منتقي ألوان عام) */
export function PalettePresets({ activeId, onPick }) {
  return (
    <div className="scroll-x">
      {ALL_PALETTES.map((p) => (
        <button key={p.id} className={`shrink-0 rounded-xl border p-1.5 bg-white transition ${activeId === p.id ? 'border-brand ring-2 ring-brand/20' : 'border-[#e3ebe7]'}`} onClick={() => onPick(p)} title={p.color}>
          <div className="flex w-16 h-8 rounded-lg overflow-hidden relative" style={{ background: p.bg }}>
            <span className="flex-1" style={{ background: p.c1 }} />
            <span className="w-3" style={{ background: p.c2 }} />
            <span className="flex-1" style={{ background: p.bg }} />
            {activeId === p.id && <Check size={14} className="absolute inset-0 m-auto text-white drop-shadow" />}
          </div>
          <div className="text-[10px] text-ink-mute mt-1">{p.color}</div>
        </button>
      ))}
    </div>
  );
}
