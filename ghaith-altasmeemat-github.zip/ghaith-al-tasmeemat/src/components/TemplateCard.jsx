import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, PenLine, Cloud, Package, WandSparkles } from 'lucide-react';
import FitHtml from './FitHtml.jsx';
import { useAppData } from './AppData.jsx';
import { setPendingTemplate } from '../lib/session.js';

const ORIGIN = {
  cloud: { label: 'سحابي', icon: Cloud },
  pack: { label: 'حزمة', icon: Package },
  clone: { label: 'مستنسخ', icon: WandSparkles },
};

/** بطاقة قالب: معاينة كسولة + عنوان + مناسبة + مفضلة + استخدام (يمر إلزامياً بشاشة اختيار المسار) */
export default function TemplateCard({ template, onUse, extraAction = null }) {
  const navigate = useNavigate();
  const { favMap, toggleFavorite } = useAppData();
  const fav = favMap.has(template.id);
  const origin = ORIGIN[template.origin];
  const use = () => {
    if (onUse) return onUse(template);
    setPendingTemplate(template);
    navigate('/mode');
    return null;
  };
  return (
    <div className="card-ui p-2 flex flex-col fade-up">
      <button className="block w-full text-right" onClick={use} aria-label={`استخدام ${template.title}`}>
        <FitHtml template={template} lazy />
      </button>
      <div className="px-1.5 pt-2 pb-1 flex-1">
        <div className="flex items-start gap-1">
          <div className="flex-1 min-w-0">
            <div className="font-bold text-[13px] text-ink truncate">{template.title}</div>
            <div className="text-[11px] text-ink-mute mt-0.5 flex items-center gap-1 flex-wrap">
              <span>{template.occasion}</span>
              {template.tags?.style && <span>• {template.tags.style}</span>}
              {origin && (
                <span className="inline-flex items-center gap-0.5 text-brand">
                  • <origin.icon size={11} /> {origin.label}
                </span>
              )}
            </div>
          </div>
          <button className={`btn-icon w-8 h-8 ${fav ? 'text-red-500' : ''}`} onClick={() => toggleFavorite(template)} aria-label={fav ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}>
            <Heart size={17} fill={fav ? 'currentColor' : 'none'} />
          </button>
        </div>
      </div>
      <div className="flex gap-1.5 px-1 pb-1">
        <button className="btn-primary flex-1 py-2 text-xs" onClick={use}>
          <PenLine size={14} /> استخدام
        </button>
        {extraAction}
      </div>
    </div>
  );
}
