import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { Heart, WandSparkles } from 'lucide-react';
import { renderFilledHtml } from '../lib/templateUtils.js';
import { FitHtml } from './FitHtml.jsx';

function CardInner({ template, favorite = false, onFavorite, onUse }) {
  const box = useRef(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = box.current;
    if (!el || shown) return undefined;
    if (typeof IntersectionObserver === 'undefined') { setShown(true); return undefined; }
    const io = new IntersectionObserver((entries) => { if (entries.some((e) => e.isIntersecting)) { setShown(true); io.disconnect(); } }, { rootMargin: '260px' });
    io.observe(el);
    return () => io.disconnect();
  }, [shown]);
  const html = useMemo(() => (shown ? renderFilledHtml(template.html, {}) : ''), [shown, template.html]);
  return (
    <article className="template-card">
      <div className="template-preview" ref={box}>
        {shown ? <FitHtml className="preview-inner" fitHeight html={html} /> : <div className="preview-skeleton"><span>جارٍ تجهيز المعاينة…</span></div>}
      </div>
      <div className="template-info">
        <div>
          <span className="eyebrow">{template.occasion || 'دعوة مميزة'}</span>
          <h3>{template.title}</h3>
          <p>{template.style || 'تصميم عربي أنيق'} · {template.palette || 'ألوان متناسقة'}</p>
        </div>
        <div className="card-actions">
          <button className={`icon-button ${favorite ? 'is-fav' : ''}`} onClick={onFavorite} title={favorite ? 'إزالة من المفضلة' : 'إضافة للمفضلة'} aria-label={favorite ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}>
            <Heart size={18} fill={favorite ? 'currentColor' : 'none'} />
          </button>
          <button className="button button-primary button-sm" onClick={onUse}><WandSparkles size={15} /> استخدم القالب</button>
        </div>
      </div>
    </article>
  );
}
export const TemplateCard = memo(CardInner, (a, b) => a.template.id === b.template.id && a.template.html === b.template.html && a.favorite === b.favorite);
