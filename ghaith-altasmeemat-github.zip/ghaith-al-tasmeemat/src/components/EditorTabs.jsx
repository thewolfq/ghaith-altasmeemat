import React, { useEffect, useMemo, useState } from 'react';
import { Type, Palette, CaseSensitive, ImagePlus, Flower2, Clapperboard, Trash2, Upload, Film } from 'lucide-react';
import { deriveLetters } from '../lib/monograms.js';
import { ALL_PALETTES, fontStack } from '../lib/tplKit.js';
import { TEMPLATE_FONTS } from '../lib/fontsManifest.js';
import { installedFontFamilies } from '../lib/assets.js';
import { ORNAMENT_PATTERNS, FRAME_STYLES, PHOTO_SLOTS, PHOTO_SHAPES } from '../lib/compose.js';
import { ORNAMENT_CATEGORIES, BUILTIN_ORNAMENTS } from '../lib/ornaments.js';

const ORN_CAT = new Map(BUILTIN_ORNAMENTS.map((o) => [o.id, o.category]));
import { fileToDataUrl, downscaleImage } from '../lib/palette.js';
import { isSafeImageDataUri } from '../lib/templateUtils.js';
import { VIDEO_EFFECTS } from '../lib/ai.js';
import { useOrnamentSvgs } from '../lib/hooks.js';
import ColorPicker, { PalettePresets } from './ColorPicker.jsx';
import MonogramPicker from './MonogramPicker.jsx';
import OffsetControl from './OffsetControl.jsx';
import { useToast } from './Toast.jsx';

export const TABS = [
  { id: 'text', label: 'نصوص', icon: Type },
  { id: 'colors', label: 'ألوان', icon: Palette },
  { id: 'fonts', label: 'خطوط وأشكال أحرف', icon: CaseSensitive },
  { id: 'images', label: 'صور', icon: ImagePlus },
  { id: 'ornaments', label: 'زخارف وحواف', icon: Flower2 },
  { id: 'media', label: 'صوت وفيديو', icon: Clapperboard },
];

/** شريط التبويبات: مؤشر للتبويب ذي المسودة غير المحفوظة */
export default function EditorTabs({ active, dirty, onSelect }) {
  return (
    <div className="scroll-x pb-1" role="tablist">
      {TABS.map(({ id, label, icon: Icon }) => (
        <button key={id} role="tab" aria-selected={active === id} className={`${active === id ? 'chip-on' : 'chip-off'} relative`} onClick={() => onSelect(id)}>
          <Icon size={14} /> {label}
          {active === id && dirty && <span className="absolute -top-0.5 -left-0.5 w-2.5 h-2.5 rounded-full bg-gold border-2 border-white" />}
        </button>
      ))}
    </div>
  );
}

const PALETTE_KEYS = ['bg', 'bg2', 'c1', 'c2', 'c3', 'ink'];
const COLOR_LABELS = { bg: 'الخلفية', bg2: 'الخلفية الثانية', c1: 'اللون الرئيسي', c2: 'لون الزينة (ذهبي)', c3: 'لون مساعد', ink: 'لون النصوص' };

function setValueOps(state, key, value) {
  const ops = [{ path: `values.${key}`, value }];
  if ((key === 'name1' || key === 'name2') && state.mono?.auto) {
    const v = { ...state.values, [key]: value };
    const L = deriveLetters(v.name1 || '', v.name2 || '');
    if (L.a) ops.push({ path: 'mono.a', value: L.a });
    ops.push({ path: 'mono.b', value: L.b || '' });
  }
  return ops;
}

/** حقول النصوص — تعديل فوري في كل المسارات */
export function TextFields({ store, meta, tab, showOffsets = false }) {
  const st = store.state;
  const [target, setTarget] = useState(meta.fields[0]?.key || '');
  return (
    <div className="space-y-3">
      {meta.fields.map((f) => {
        const v = st.values?.[f.key] ?? '';
        const missing = f.required && !String(v).trim();
        const props = {
          id: `f-${f.key}`,
          className: `input ${missing ? 'border-red-300 bg-red-50/40' : ''}`,
          value: v,
          onChange: (e) => store.exec(setValueOps(st, f.key, e.target.value), { tab, label: `نص: ${f.label}`, coalesceKey: `v:${f.key}` }),
        };
        return (
          <div key={f.key}>
            <label className="label" htmlFor={props.id}>
              {f.label} {f.required && <span className="text-red-500">*</span>}
            </label>
            {f.multiline ? <textarea {...props} rows={2} /> : <input {...props} />}
          </div>
        );
      })}
      {!meta.fields.length && <p className="muted">لا توجد حقول نصية في هذا القالب.</p>}
      {showOffsets && meta.fields.length > 0 && (
        <div className="pt-2 space-y-2">
          <label className="label" htmlFor="off-target">
            تحريك نص محدد
          </label>
          <select id="off-target" className="input" value={target} onChange={(e) => setTarget(e.target.value)}>
            {meta.fields.map((f) => (
              <option key={f.key} value={f.key}>
                {f.label}
              </option>
            ))}
          </select>
          <OffsetControl value={st.offsets?.[`field:${target}`]} onChange={(v) => store.set(`offsets.field:${target}`, v, { tab, label: 'تحريك نص', coalesceKey: `off:${target}` })} />
        </div>
      )}
    </div>
  );
}

function activePaletteId(colors) {
  const p = ALL_PALETTES.find((x) => PALETTE_KEYS.every((k) => (colors?.[k] || '').toLowerCase() === x[k].toLowerCase()));
  return p ? p.id : null;
}

export function applyPaletteOps(p) {
  return PALETTE_KEYS.map((k) => ({ path: `colors.${k}`, value: p[k] }));
}

/** منتقي الألوان العام (المسار المبسط) */
export function GlobalColors({ store, tab, template }) {
  const colors = store.state.colors || {};
  const base = template.palette || {};
  return (
    <div className="space-y-3">
      <PalettePresets activeId={activePaletteId(colors)} onPick={(p) => store.exec(applyPaletteOps(p), { tab, label: 'لوحة ألوان' })} />
      <div className="grid sm:grid-cols-2 gap-3">
        <ColorPicker label="اللون الرئيسي" value={colors.c1} fallback={base.c1 || '#0f5e4f'} onChange={(v) => store.set('colors.c1', v || undefined, { tab, label: 'لون رئيسي', coalesceKey: 'c:c1' })} compact />
        <ColorPicker label="لون الزينة" value={colors.c2} fallback={base.c2 || '#c09743'} onChange={(v) => store.set('colors.c2', v || undefined, { tab, label: 'لون الزينة', coalesceKey: 'c:c2' })} compact />
      </div>
    </div>
  );
}

function ColorsPanel({ store, tab, template }) {
  const colors = store.state.colors || {};
  const base = template.palette || {};
  const any = Object.keys(colors).length > 0;
  return (
    <div className="space-y-4">
      <div>
        <div className="label">لوحات جاهزة متناسقة</div>
        <PalettePresets activeId={activePaletteId(colors)} onPick={(p) => store.exec(applyPaletteOps(p), { tab, label: 'لوحة ألوان' })} />
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        {PALETTE_KEYS.map((k) => (
          <ColorPicker key={k} label={COLOR_LABELS[k]} value={colors[k]} fallback={base[k] || '#888888'} onChange={(v) => store.set(`colors.${k}`, v || undefined, { tab, label: COLOR_LABELS[k], coalesceKey: `c:${k}` })} />
        ))}
      </div>
      {any && (
        <button className="btn-ghost text-xs" onClick={() => store.set('colors', {}, { tab, label: 'ألوان القالب الأصلية' })}>
          استعادة ألوان القالب الأصلية
        </button>
      )}
    </div>
  );
}

function FontSelect({ label, value, fallback, fonts, onChange }) {
  return (
    <div>
      <div className="label">{label}</div>
      <select className="input" value={value || ''} onChange={(e) => onChange(e.target.value || undefined)} style={{ fontFamily: fontStack(value || fallback || 'Cairo') }}>
        <option value="">خط القالب الأصلي{fallback ? ` (${fallback})` : ''}</option>
        {fonts.map((f) => (
          <option key={f} value={f} style={{ fontFamily: fontStack(f) }}>
            {f}
          </option>
        ))}
      </select>
      <div className="mt-1.5 rounded-lg bg-canvas px-3 py-2 text-xl text-ink text-center truncate" style={{ fontFamily: fontStack(value || fallback || 'Cairo') }}>
        محمد وسارة — ٣٠ نوفمبر
      </div>
    </div>
  );
}

function FontsPanel({ store, tab, template, meta }) {
  const st = store.state;
  const [extra, setExtra] = useState([]);
  useEffect(() => {
    installedFontFamilies().then(setExtra).catch(() => setExtra([]));
  }, []);
  const fonts = useMemo(() => [...new Set([...TEMPLATE_FONTS, ...extra])], [extra]);
  const tf = template.fonts || {};
  const setFont = (k, v, l) => store.set(`fonts.${k}`, v, { tab, label: l });
  return (
    <div className="space-y-5">
      <div className="grid sm:grid-cols-3 gap-4">
        <FontSelect label="خط الأسماء والعناوين" value={st.fonts?.title} fallback={tf.title} fonts={fonts} onChange={(v) => setFont('title', v, 'خط العناوين')} />
        <FontSelect label="خط النصوص" value={st.fonts?.body} fallback={tf.body} fonts={fonts} onChange={(v) => setFont('body', v, 'خط النصوص')} />
        <FontSelect label="خط الزخرفة (الافتتاحية/الآية)" value={st.fonts?.deco} fallback={tf.deco} fonts={fonts} onChange={(v) => setFont('deco', v, 'خط الزخرفة')} />
      </div>
      <hr className="border-[#e3ebe7]" />
      <div>
        <h4 className="font-bold text-ink mb-2">المونوغرام وأشكال الأحرف</h4>
        {!meta.hasMono && (
          <label className="flex items-center gap-2 text-xs font-semibold text-ink-soft mb-3">
            <input type="checkbox" className="accent-[#0f766e] w-4 h-4" checked={!!st.monoOverlay} onChange={(e) => store.exec([{ path: 'monoOverlay', value: e.target.checked }, ...(e.target.checked ? [{ path: 'mono.enabled', value: true }] : [])], { tab, label: 'إضافة مونوغرام' })} />
            القالب لا يحتوي موضعاً للمونوغرام — أضيفيه أعلى البطاقة
          </label>
        )}
        <MonogramPicker mono={st.mono} names={st.values} vars={{ '--c1': st.colors?.c1 || template.palette?.c1, '--c2': st.colors?.c2 || template.palette?.c2, '--bg': st.colors?.bg || template.palette?.bg }} onChange={(patch) => store.exec(Object.entries(patch).map(([k, v]) => ({ path: `mono.${k}`, value: v })), { tab, label: 'المونوغرام', coalesceKey: Object.keys(patch).join(',') === 'size' ? 'mono-size' : null })} />
        {(meta.hasMono || st.monoOverlay) && st.mono?.enabled && (
          <div className="mt-3">
            <OffsetControl label="موضع المونوغرام" value={st.offsets?.mono} onChange={(v) => store.set('offsets.mono', v, { tab, label: 'تحريك المونوغرام', coalesceKey: 'off:mono' })} />
          </div>
        )}
      </div>
    </div>
  );
}

async function readImage(file) {
  if (!file.type.startsWith('image/')) throw new Error('الملف ليس صورة');
  if (file.size > 25 * 1024 * 1024) throw new Error('الصورة أكبر من 25MB');
  const raw = await fileToDataUrl(file);
  const small = (await downscaleImage(raw, 1100, 'image/jpeg', 0.85)).dataUrl;
  if (!isSafeImageDataUri(small)) throw new Error('تعذر تجهيز الصورة بحجم مناسب');
  return small;
}

function ImageSlot({ k, label, im, onSet, onClear, onPatch }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const pick = async (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    setBusy(true);
    try {
      onSet(await readImage(f));
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="rounded-xl border border-[#e3ebe7] p-3 bg-white space-y-3">
      <div className="flex items-center gap-3">
        <div className="w-16 h-16 rounded-xl bg-canvas bg-cover bg-center shrink-0 border" style={im?.src ? { backgroundImage: `url("${im.src}")` } : {}} />
        <div className="flex-1">
          <div className="font-bold text-sm">{label}</div>
          <div className="flex gap-2 mt-1.5 flex-wrap">
            <label className="btn-soft text-xs cursor-pointer">
              <Upload size={14} /> {busy ? 'جارٍ التجهيز…' : im?.src ? 'تغيير' : 'اختيار صورة'}
              <input type="file" accept="image/*" className="sr-only" aria-label="ملف صورة" onChange={pick} disabled={busy} />
            </label>
            {im?.src && (
              <button className="btn-ghost text-xs text-red-600" onClick={onClear}>
                <Trash2 size={14} /> إزالة
              </button>
            )}
          </div>
        </div>
      </div>
      {im?.src && (
        <div className="grid grid-cols-3 gap-3 text-[11px]">
          {[
            ['zoom', 'تكبير', 1, 2.5, 0.05, 1],
            ['posX', 'أفقي', 0, 100, 1, 50],
            ['posY', 'رأسي', 0, 100, 1, 50],
          ].map(([p, l, min, max, step, def]) => (
            <label key={p} className="block">
              <span className="text-ink-mute">{l}</span>
              <input type="range" min={min} max={max} step={step} value={im[p] ?? def} onChange={(e) => onPatch(p, Number(e.target.value))} className="w-full accent-[#0f766e]" />
            </label>
          ))}
        </div>
      )}
      <span className="sr-only">{k}</span>
    </div>
  );
}

function ImagesPanel({ store, tab, meta }) {
  const st = store.state;
  const imgs = st.images || {};
  const slots = meta.images.length ? meta.images : ['photo'];
  const overlay = !meta.images.length;
  const setImg = (k, src) =>
    store.exec([{ path: `images.${k}`, value: { src, zoom: 1, posX: 50, posY: 50 } }, ...(overlay ? [{ path: 'photo.enabled', value: true }] : [])], { tab, label: 'صورة' });
  return (
    <div className="space-y-4">
      <p className="text-xs text-ink-mute">تُحفظ الصور محلياً داخل الدعوة فقط بعد تصغيرها، ولا تُرفع إلى أي مكان.</p>
      {overlay && (
        <div className="space-y-3">
          <label className="flex items-center gap-2 text-sm font-semibold">
            <input type="checkbox" className="accent-[#0f766e] w-4 h-4" checked={!!st.photo?.enabled} onChange={(e) => store.set('photo.enabled', e.target.checked, { tab, label: 'إظهار الصورة' })} />
            إظهار صورة على البطاقة
          </label>
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <div className="label">الموضع</div>
              <div className="flex gap-1.5 flex-wrap">
                {PHOTO_SLOTS.map((p) => (
                  <button key={p.id} className={st.photo?.slot === p.id ? 'chip-on' : 'chip-off'} onClick={() => store.set('photo.slot', p.id, { tab, label: 'موضع الصورة' })}>
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div className="label">الشكل</div>
              <div className="flex gap-1.5 flex-wrap">
                {PHOTO_SHAPES.map((p) => (
                  <button key={p.id} className={st.photo?.shape === p.id ? 'chip-on' : 'chip-off'} onClick={() => store.set('photo.shape', p.id, { tab, label: 'شكل الصورة' })}>
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
      {slots.map((k) => (
        <div key={k} className="space-y-2">
          <ImageSlot
            k={k}
            label={overlay ? 'الصورة' : `خانة الصورة: ${k}`}
            im={imgs[k]}
            onSet={(src) => setImg(k, src)}
            onClear={() => store.set(`images.${k}`, undefined, { tab, label: 'إزالة صورة' })}
            onPatch={(p, v) => store.set(`images.${k}.${p}`, v, { tab, label: 'ضبط الصورة', coalesceKey: `img:${k}:${p}` })}
          />
          {imgs[k]?.src && <OffsetControl label="موضع خانة الصورة" value={st.offsets?.[`image:${k}`]} onChange={(v) => store.set(`offsets.image:${k}`, v, { tab, label: 'تحريك صورة', coalesceKey: `off:img:${k}` })} />}
        </div>
      ))}
    </div>
  );
}

function OrnamentsPanel({ store, tab }) {
  const st = store.state;
  const orn = st.ornament || {};
  const svgs = useOrnamentSvgs();
  const [cat, setCat] = useState('all');
  const ids = Object.keys(svgs);
  const catIds = cat === 'all' ? ids : ids.filter((id) => ORN_CAT.get(id) === cat);
  const set = (p, v, l, ck) => store.set(`ornament.${p}`, v, { tab, label: l, coalesceKey: ck });
  return (
    <div className="space-y-4">
      <div>
        <div className="label">زخرفة مضافة بنقاط الارتكاز (تنسيق تلقائي)</div>
        <div className="scroll-x mb-2">
          <button className={cat === 'all' ? 'chip-on' : 'chip-off'} onClick={() => setCat('all')}>
            الكل ({ids.length})
          </button>
          {ORNAMENT_CATEGORIES.map((c) => (
            <button key={c} className={cat === c ? 'chip-on' : 'chip-off'} onClick={() => setCat(c)}>
              {c}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-6 sm:grid-cols-8 gap-1.5 max-h-56 overflow-y-auto p-0.5">
          <button className={`aspect-square rounded-lg border text-[10px] ${!orn.id ? 'border-brand ring-2 ring-brand/20 bg-brand-soft' : 'border-[#e3ebe7] bg-white'}`} onClick={() => set('id', null, 'إزالة الزخرفة')}>
            بلا
          </button>
          {catIds.map((id) => (
            <button key={id} title={id} className={`aspect-square rounded-lg border p-1 text-gold-dark ${orn.id === id ? 'border-brand ring-2 ring-brand/20 bg-brand-soft' : 'border-[#e3ebe7] bg-white'}`} onClick={() => set('id', id, 'زخرفة')}>
              <svg viewBox="0 0 100 100" className="w-full h-full" dangerouslySetInnerHTML={{ __html: svgs[id] }} />
            </button>
          ))}
        </div>
      </div>
      {orn.id && (
        <>
          <div>
            <div className="label">نمط التوزيع</div>
            <div className="flex gap-1.5 flex-wrap">
              {ORNAMENT_PATTERNS.map((p) => (
                <button key={p.id} className={orn.pattern === p.id ? 'chip-on' : 'chip-off'} onClick={() => set('pattern', p.id, 'توزيع الزخرفة')}>
                  {p.label}
                </button>
              ))}
            </div>
          </div>
          <div className="grid sm:grid-cols-3 gap-4">
            <ColorPicker label="لون الزخرفة" value={orn.color} fallback="#c09743" onChange={(v) => set('color', v, 'لون الزخرفة', 'orn-color')} compact />
            <label className="block">
              <span className="label">الحجم ({orn.size || 64}px)</span>
              <input type="range" min="24" max="120" step="2" value={orn.size || 64} onChange={(e) => set('size', Number(e.target.value), 'حجم الزخرفة', 'orn-size')} className="w-full accent-[#0f766e]" />
            </label>
            <label className="block">
              <span className="label">الشفافية ({Math.round((orn.opacity ?? 0.9) * 100)}٪)</span>
              <input type="range" min="0.2" max="1" step="0.05" value={orn.opacity ?? 0.9} onChange={(e) => set('opacity', Number(e.target.value), 'شفافية الزخرفة', 'orn-op')} className="w-full accent-[#0f766e]" />
            </label>
          </div>
          <OffsetControl label="إزاحة طبقة الزخرفة" value={st.offsets?.orn} onChange={(v) => store.set('offsets.orn', v, { tab, label: 'تحريك الزخرفة', coalesceKey: 'off:orn' })} />
        </>
      )}
      <hr className="border-[#e3ebe7]" />
      <div>
        <div className="label">الحواف والإطار</div>
        <div className="flex gap-1.5 flex-wrap">
          {FRAME_STYLES.map((f) => (
            <button key={f.id} className={(st.frame?.style || 'none') === f.id ? 'chip-on' : 'chip-off'} onClick={() => store.set('frame.style', f.id, { tab, label: 'الإطار' })}>
              {f.label}
            </button>
          ))}
        </div>
        {st.frame?.style && st.frame.style !== 'none' && (
          <div className="mt-3">
            <ColorPicker label="لون الإطار" value={st.frame?.color} fallback="#c09743" onChange={(v) => store.set('frame.color', v, { tab, label: 'لون الإطار', coalesceKey: 'frame-color' })} compact />
          </div>
        )}
      </div>
    </div>
  );
}

function MediaPanel({ store, tab, onOpenVideo }) {
  const media = store.state.media || { effects: ['fade', 'zoom'], duration: 12 };
  const effects = media.effects || [];
  const toggle = (id) => store.set('media.effects', effects.includes(id) ? effects.filter((e) => e !== id) : [...effects, id], { tab, label: 'تأثير فيديو' });
  return (
    <div className="space-y-4">
      <p className="text-sm text-ink-soft leading-7">حوّلي الدعوة إلى فيديو بتأثيرات حركة مع صوت اختياري من جهازك. يتم كل شيء محلياً عبر Canvas وMediaRecorder ويُحفظ على الجهاز.</p>
      <div>
        <div className="label">التأثيرات الافتراضية</div>
        <div className="flex gap-1.5 flex-wrap">
          {VIDEO_EFFECTS.map((e) => (
            <button key={e.id} className={effects.includes(e.id) ? 'chip-on' : 'chip-off'} onClick={() => toggle(e.id)}>
              {e.label}
            </button>
          ))}
        </div>
      </div>
      <label className="block">
        <span className="label">المدة ({media.duration || 12} ثانية)</span>
        <input type="range" min="4" max="60" step="1" value={media.duration || 12} onChange={(e) => store.set('media.duration', Number(e.target.value), { tab, label: 'مدة الفيديو', coalesceKey: 'media-dur' })} className="w-full accent-[#0f766e]" />
      </label>
      <button className="btn-primary" onClick={onOpenVideo}>
        <Film size={16} /> فتح شاشة الفيديو واختيار الصوت
      </button>
      <p className="text-[11px] text-ink-mute">يُختار ملف الصوت داخل شاشة الفيديو، وتبقى تعديلاتك في المحرر كما هي عند الرجوع.</p>
    </div>
  );
}

export function TabPanel({ id, ...props }) {
  switch (id) {
    case 'text':
      return <TextFields {...props} showOffsets />;
    case 'colors':
      return <ColorsPanel {...props} />;
    case 'fonts':
      return <FontsPanel {...props} />;
    case 'images':
      return <ImagesPanel {...props} />;
    case 'ornaments':
      return <OrnamentsPanel {...props} />;
    case 'media':
      return <MediaPanel {...props} />;
    default:
      return null;
  }
}
