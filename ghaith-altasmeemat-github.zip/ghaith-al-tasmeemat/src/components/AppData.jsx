import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { db, addFavorite, removeFavorite, saveInvitation, duplicateInvitation, LimitError, LIMITS } from '../lib/db.js';
import { LimitDialog } from './ConfirmDialog.jsx';
import { useToast } from './Toast.jsx';
import { formatDate } from '../lib/hooks.js';

const Ctx = createContext(null);

/** بيانات مشتركة: المفضلة (مع حد 50) وحفظ/نسخ الدعوات (مع حد 30) بخيار الاستبدال */
export function AppDataProvider({ children }) {
  const [favMap, setFavMap] = useState(new Map());
  const [version, setVersion] = useState(0);
  const [limit, setLimit] = useState(null);
  const pending = useRef(null);
  const toast = useToast();
  const navigate = useNavigate();

  const refreshFavs = useCallback(async () => {
    const rows = await db.favorites.toArray();
    setFavMap(new Map(rows.map((r) => [r.templateId, r.id])));
  }, []);

  useEffect(() => {
    refreshFavs();
  }, [refreshFavs, version]);

  const bump = useCallback(() => setVersion((v) => v + 1), []);

  const askLimit = useCallback(async (kind, action) => {
    const table = kind === 'favorites' ? db.favorites : db.invitations;
    const rows = kind === 'favorites' ? await table.orderBy('savedAt').toArray() : await table.orderBy('updatedAt').toArray();
    const items = rows.map((r) => ({ id: r.id, label: kind === 'favorites' ? r.template?.title || 'قالب' : r.title, date: formatDate(r.savedAt || r.updatedAt) }));
    return new Promise((resolve) => {
      pending.current = { action, resolve };
      setLimit({ kind, limit: kind === 'favorites' ? LIMITS.favorites : LIMITS.invitations, items });
    });
  }, []);

  const toggleFavorite = useCallback(
    async (template) => {
      const existing = favMap.get(template.id);
      if (existing) {
        await removeFavorite(existing);
        toast('أُزيل من المفضلة', 'info');
        bump();
        return false;
      }
      try {
        await addFavorite(template);
        toast('أُضيف إلى المفضلة');
        bump();
        return true;
      } catch (e) {
        if (e instanceof LimitError) {
          const res = await askLimit('favorites', (replaceId) => addFavorite(template, { replaceId }));
          if (res) {
            toast('تم الاستبدال وإضافة القالب للمفضلة');
            bump();
          }
          return !!res;
        }
        toast(e.message || 'تعذر الحفظ', 'error');
        return false;
      }
    },
    [favMap, toast, bump, askLimit],
  );

  const saveInvitationSafe = useCallback(
    async (record) => {
      try {
        const row = await saveInvitation(record);
        bump();
        return row;
      } catch (e) {
        if (e instanceof LimitError) {
          const row = await askLimit('invitations', (replaceId) => saveInvitation(record, { replaceId }));
          if (row) bump();
          return row || null;
        }
        throw e;
      }
    },
    [bump, askLimit],
  );

  const duplicateSafe = useCallback(
    async (id) => {
      try {
        const row = await duplicateInvitation(id);
        bump();
        return row;
      } catch (e) {
        if (e instanceof LimitError) {
          const row = await askLimit('invitations', (replaceId) => duplicateInvitation(id, { replaceId }));
          if (row) bump();
          return row || null;
        }
        throw e;
      }
    },
    [bump, askLimit],
  );

  const closeLimit = (value) => {
    pending.current?.resolve(value);
    pending.current = null;
    setLimit(null);
  };

  return (
    <Ctx.Provider value={{ favMap, toggleFavorite, saveInvitationSafe, duplicateSafe, version, bump }}>
      {children}
      <LimitDialog
        open={!!limit}
        kind={limit?.kind}
        limit={limit?.limit}
        items={limit?.items || []}
        onCancel={() => closeLimit(null)}
        onManage={() => {
          const kind = limit?.kind;
          closeLimit(null);
          navigate(kind === 'favorites' ? '/favorites' : '/invitations');
        }}
        onReplace={async (replaceId) => {
          try {
            const res = await pending.current.action(replaceId);
            closeLimit(res || true);
          } catch (err) {
            toast(err.message || 'تعذر الاستبدال', 'error');
            closeLimit(null);
          }
        }}
      />
    </Ctx.Provider>
  );
}

export function useAppData() {
  return useContext(Ctx);
}
