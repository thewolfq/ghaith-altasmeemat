import React from 'react';
import { canLeave } from '../lib/leaveGuard.js';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Home, Compass, Heart, Mail, Settings, ChevronRight, WandSparkles, HardDrive, Info } from 'lucide-react';
import { APP_NAME, APP_VERSION } from '../lib/db.js';

export const NAV = [
  { to: '/', label: 'الرئيسية', icon: Home, end: true },
  { to: '/explore', label: 'استكشف', icon: Compass },
  { to: '/favorites', label: 'المفضلة', icon: Heart },
  { to: '/invitations', label: 'دعواتي', icon: Mail },
  { to: '/settings', label: 'الإعدادات', icon: Settings },
];

const TITLES = {
  '/': APP_NAME,
  '/explore': 'استكشف القوالب',
  '/favorites': 'المفضلة',
  '/invitations': 'دعواتي',
  '/settings': 'الإعدادات',
  '/about': 'عن التطبيق',
  '/storage': 'إدارة التخزين',
  '/clone': 'استنساخ من صورة',
  '/mode': 'اختيار مسار التحرير',
  '/video': 'الصوت والفيديو',
};

export function Logo({ size = 36 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 512 512" aria-hidden="true">
      <defs>
        <linearGradient id="lg-bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#0f766e" />
          <stop offset="1" stopColor="#0b4f4a" />
        </linearGradient>
        <linearGradient id="lg-gd" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f1d39a" />
          <stop offset="1" stopColor="#c8944a" />
        </linearGradient>
      </defs>
      <rect width="512" height="512" rx="112" fill="url(#lg-bg)" />
      <path d="M332 214c0-48-34-82-80-82-50 0-88 40-88 92 0 56 40 96 96 96 26 0 46-6 62-16v-58h-64" fill="none" stroke="url(#lg-gd)" strokeWidth="30" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="256" cy="392" r="14" fill="url(#lg-gd)" />
    </svg>
  );
}

export default function AppLayout() {
  const loc = useLocation();
  const nav = useNavigate();
  const path = loc.pathname;
  const isEditor = path.startsWith('/edit') || path.startsWith('/video');
  const isRoot = NAV.some((n) => n.to === path);
  const guarded = (e, to) => {
    if (!isEditor) return;
    e.preventDefault();
    canLeave().then((ok) => ok && nav(to));
  };
  const goBack = async () => {
    if (!(await canLeave())) return;
    if (window.history.length > 1) nav(-1);
    else nav('/');
  };
  const title = path.startsWith('/edit') ? (path.includes('simple') ? 'التحرير المبسط' : 'التحرير الكامل') : TITLES[path] || APP_NAME;

  return (
    <div className="min-h-screen lg:pr-[250px]">
      {/* الشريط الجانبي للشاشات الكبيرة */}
      <aside className="hidden lg:flex fixed top-0 right-0 bottom-0 w-[250px] flex-col bg-white border-l border-[#e3ebe7] z-30">
        <div className="flex items-center gap-3 px-5 py-5 border-b border-[#eef3f1]">
          <Logo size={40} />
          <div>
            <div className="font-extrabold text-ink">{APP_NAME}</div>
            <div className="text-[11px] text-ink-mute">الإصدار {APP_VERSION}</div>
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink key={to} to={to} end={end} onClick={(e) => guarded(e, to)} className={({ isActive }) => `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition ${isActive ? 'bg-brand text-white shadow-soft' : 'text-ink-soft hover:bg-canvas'}`}>
              <Icon size={19} />
              {label}
            </NavLink>
          ))}
          <div className="pt-3 mt-3 border-t border-[#eef3f1] space-y-1">
            {[
              { to: '/clone', label: 'استنساخ من صورة', icon: WandSparkles },
              { to: '/storage', label: 'إدارة التخزين', icon: HardDrive },
              { to: '/about', label: 'عن التطبيق', icon: Info },
            ].map(({ to, label, icon: Icon }) => (
              <NavLink key={to} to={to} onClick={(e) => guarded(e, to)} className={({ isActive }) => `flex items-center gap-3 rounded-xl px-3 py-2 text-sm transition ${isActive ? 'bg-brand-soft text-brand-dark font-semibold' : 'text-ink-soft hover:bg-canvas'}`}>
                <Icon size={17} />
                {label}
              </NavLink>
            ))}
          </div>
        </nav>
        <div className="p-4 text-[11px] text-ink-mute leading-5">يعمل محلياً بالكامل على جهازك.</div>
      </aside>

      {/* الرأس العلوي */}
      <header className="sticky top-0 z-20 bg-canvas/85 backdrop-blur border-b border-[#e6eeea]">
        <div className="mx-auto max-w-[1260px] flex items-center gap-2 px-4 h-14">
          {!isRoot ? (
            <button className="btn-icon -mr-2" onClick={goBack} aria-label="رجوع">
              <ChevronRight size={22} />
            </button>
          ) : (
            <span className="lg:hidden">
              <Logo size={30} />
            </span>
          )}
          <h1 className="font-extrabold text-ink text-[17px] truncate flex-1">{title}</h1>
        </div>
      </header>

      <main className={`mx-auto max-w-[1260px] px-4 ${isEditor ? 'pb-6' : 'pb-28 lg:pb-10'} pt-4`}>
        <Outlet />
      </main>

      {/* شريط التنقل السفلي العائم */}
      {!isEditor && (
        <nav className="lg:hidden fixed inset-x-3 bottom-3 z-30 safe-bottom">
          <div className="mx-auto max-w-md flex items-center justify-between rounded-2xl bg-white/95 backdrop-blur border border-[#e3ebe7] shadow-lift px-1.5 py-1.5">
            {NAV.map(({ to, label, icon: Icon, end }) => (
              <NavLink key={to} to={to} end={end} className={({ isActive }) => `flex-1 flex flex-col items-center gap-0.5 rounded-xl py-1.5 text-[10.5px] xs:text-[11px] font-semibold transition ${isActive ? 'bg-brand text-white' : 'text-ink-mute'}`}>
                <Icon size={19} />
                {label}
              </NavLink>
            ))}
          </div>
        </nav>
      )}
    </div>
  );
}
