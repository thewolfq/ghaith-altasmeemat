import { useEffect, useState } from 'react';
import { CloudDownload, PackagePlus, RefreshCw, Trash2 } from 'lucide-react';
import { checkAutoUpdate, clearPacks, getAutoConfig, getPackCounts, importPackFile, saveAutoConfig } from '../lib/packs.js';

const when = (t) => (t ? new Date(t).toLocaleString('ar') : 'لم يتم بعد');

export function PacksCard() {
  const [cfg, setCfg] = useState(null);
  const [counts, setCounts] = useState({ manual: 0, auto: 0 });
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const [url, setUrl] = useState('');

  async function refresh() {
    const c = await getAutoConfig();
    setCfg(c);
    setUrl((old) => old || c.url || '');
    setCounts(await getPackCounts());
  }
  useEffect(() => { refresh(); }, []);

  async function onFile(e) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setBusy(true); setMsg('');
    try {
      const r = await importPackFile(file);
      setMsg(`تمت إضافة ${r.added} قالب${r.skipped ? ` (تم تجاهل ${r.skipped} ملف غير صالح)` : ''}.`);
    } catch (err) { setMsg(err.message || 'تعذّر قراءة الملف.'); }
    finally { setBusy(false); refresh(); }
  }
  async function toggleAuto(on) { await saveAutoConfig({ enabled: on, url: url.trim() }); refresh(); if (on) updateNow(); }
  async function saveUrl() { await saveAutoConfig({ url: url.trim() }); setMsg('تم حفظ الرابط.'); refresh(); }
  async function updateNow() {
    setBusy(true); setMsg('');
    await saveAutoConfig({ url: url.trim() });
    const r = await checkAutoUpdate({ force: true });
    setMsg(r.status === 'updated' ? `تم التحديث (${r.count} قالب).` : r.status === 'no-url' ? 'أدخل رابط ملف القوالب أولاً (يبدأ بـ https).' : `تعذّر التحديث: ${r.message || r.status}`);
    setBusy(false); refresh();
  }
  async function removeAll() {
    if (!window.confirm('سيتم حذف القوالب المضافة (اليدوية والتلقائية) فقط. دعواتك المحفوظة لن تتأثر. متابعة؟')) return;
    await clearPacks(); setMsg('تم حذف القوالب المضافة.'); refresh();
  }
  if (!cfg) return null;

  return (
    <section className="settings-card packs-card">
      <div className="settings-leading">
        <div className="settings-icon"><PackagePlus /></div>
        <div>
          <h3>تحديث القوالب</h3>
          <p>القوالب المضافة: {counts.manual} يدوياً · {counts.auto} تلقائياً. تظهر ضمن اقتراحات «استكشف».</p>
        </div>
      </div>

      <div className="packs-block">
        <b>١) تحديث يدوي</b>
        <p>أضف ملف ZIP فيه ملفات القوالب (JSON أو HTML).</p>
        <label className={`button button-outline ${busy ? 'is-disabled' : ''}`}>
          <PackagePlus size={16} /> إضافة ملف ZIP
          <input type="file" accept=".zip,.json,application/zip,application/json" onChange={onFile} disabled={busy} hidden />
        </label>
      </div>

      <div className="packs-block">
        <b>٢) تحديث تلقائي</b>
        <p>يجلب القوالب من رابط ملف JSON عند فتح التطبيق (مرة كل ٦ ساعات).</p>
        <div className="fill-field">
          <input dir="ltr" value={url} onChange={(e) => setUrl(e.target.value)} onBlur={saveUrl} placeholder="https://raw.githubusercontent.com/.../templates.json" />
        </div>
        <label className="packs-toggle">
          <input type="checkbox" checked={cfg.enabled} onChange={(e) => toggleAuto(e.target.checked)} /> تفعيل التحديث التلقائي
        </label>
        <button className="button button-outline" disabled={busy} onClick={updateNow}><RefreshCw size={16} /> تحديث الآن</button>
        <small>آخر تحديث: {when(cfg.lastUpdate)}</small>
      </div>

      {msg && <div className="alert alert-info packs-msg">{msg}</div>}
      <button className="button button-danger-outline" disabled={busy || (!counts.manual && !counts.auto)} onClick={removeAll}><Trash2 size={16} /> حذف القوالب المضافة</button>
    </section>
  );
}
