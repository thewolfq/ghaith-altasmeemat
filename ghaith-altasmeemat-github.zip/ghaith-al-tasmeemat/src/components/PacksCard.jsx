import React, { useEffect, useState } from 'react';
import { Package, Upload, Link2, RefreshCw, Trash2, Loader2, Plus, X } from 'lucide-react';
import { listPacks, importPackFile, updateFromUrl, getUpdateUrls, saveUpdateUrls, deletePack, PACK_LIMITS } from '../lib/packs.js';
import { formatBytes } from '../lib/db.js';
import { formatDate } from '../lib/hooks.js';
import { useToast } from './Toast.jsx';
import { useConfirm } from './ConfirmDialog.jsx';

/** حزم القوالب: استيراد يدوي ZIP/JSON + تحديث يدوي من رابط HTTPS بزر صريح فقط */
export default function PacksCard() {
  const [packs, setPacks] = useState([]);
  const [urls, setUrls] = useState([]);
  const [newUrl, setNewUrl] = useState('');
  const [busy, setBusy] = useState(null);
  const [report, setReport] = useState(null);
  const toast = useToast();
  const confirm = useConfirm();

  const reload = async () => {
    setPacks(await listPacks());
    setUrls(await getUpdateUrls());
  };
  useEffect(() => {
    reload();
  }, []);

  const showResult = (res, label) => {
    setReport({ label, accepted: res.accepted, rejected: res.rejected || [], upToDate: res.upToDate });
    toast(res.upToDate ? 'الحزمة محدثة بالفعل' : `تم قبول ${res.accepted} قالب${res.rejected?.length ? ` ورفض ${res.rejected.length}` : ''}`);
  };

  const onFile = async (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    setBusy('file');
    try {
      showResult(await importPackFile(f), f.name);
      await reload();
    } catch (err) {
      toast(err.message, 'error', 4500);
    } finally {
      setBusy(null);
    }
  };

  const addUrl = async () => {
    const u = newUrl.trim();
    if (!/^https:\/\/\S+$/i.test(u)) {
      toast('الرابط يجب أن يبدأ بـ https://', 'error');
      return;
    }
    if (urls.includes(u)) return;
    const next = [...urls, u];
    await saveUpdateUrls(next);
    setUrls(next);
    setNewUrl('');
  };

  const check = async (u) => {
    setBusy(u);
    try {
      showResult(await updateFromUrl(u), u);
      await reload();
    } catch (err) {
      toast(`فشل التحديث: ${err.message}`, 'error', 4500);
    } finally {
      setBusy(null);
    }
  };

  const removeUrl = async (u) => {
    const next = urls.filter((x) => x !== u);
    await saveUpdateUrls(next);
    setUrls(next);
  };

  const del = async (p) => {
    const ok = await confirm({ title: 'حذف الحزمة؟', message: 'تُحذف قوالب الحزمة فقط. الدعوات المحفوظة المبنية عليها تبقى سليمة لأنها تحمل نسختها الكاملة.', items: [{ label: `${p.name} (${p.count} قالب)`, size: formatBytes(p.size) }], confirmText: 'حذف الحزمة', danger: true });
    if (!ok) return;
    await deletePack(p.id);
    await reload();
    toast('تم حذف الحزمة', 'info');
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <label className="btn-primary cursor-pointer">
          {busy === 'file' ? <Loader2 size={16} className="animate-spin" /> : <Upload size={16} />} استيراد ملف ZIP / JSON
          <input type="file" accept=".zip,.json,application/zip,application/json" className="sr-only" aria-label="ملف الحزمة" onChange={onFile} disabled={!!busy} />
        </label>
      </div>
      <p className="text-[11px] text-ink-mute leading-5">
        الحدود: الملف ≤ {formatBytes(PACK_LIMITS.fileBytes)}، ≤ {PACK_LIMITS.zipFiles} ملف داخل ZIP، ≤ {PACK_LIMITS.perPack} قالب لكل حزمة، وكل قالب ≤ {PACK_LIMITS.htmlChars.toLocaleString('ar')} حرف ويحتوي حقلاً قابلاً للتعديل على الأقل. كل قالب يمر بالمنقّي قبل حفظه.
      </p>

      {report && (
        <div className="rounded-xl bg-canvas p-3 text-xs space-y-1">
          <div className="flex items-center justify-between">
            <b className="truncate">نتيجة: {report.label}</b>
            <button className="btn-icon w-6 h-6" onClick={() => setReport(null)} aria-label="إغلاق">
              <X size={13} />
            </button>
          </div>
          {report.upToDate ? <div>لا يوجد إصدار جديد.</div> : <div className="text-brand-dark">مقبول: {report.accepted}</div>}
          {report.rejected.length > 0 && (
            <ul className="text-red-700 max-h-28 overflow-y-auto list-disc pr-4">
              {report.rejected.slice(0, 30).map((r, i) => (
                <li key={i}>
                  {r.title}: {r.reason}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      <div>
        <div className="label flex items-center gap-1.5">
          <Link2 size={14} /> روابط التحديث اليدوي (HTTPS — JSON ≤ 3MB)
        </div>
        <div className="flex gap-2">
          <input className="input flex-1" dir="ltr" placeholder="https://example.com/pack.json" value={newUrl} onChange={(e) => setNewUrl(e.target.value)} />
          <button className="btn-soft" onClick={addUrl} aria-label="إضافة رابط">
            <Plus size={16} />
          </button>
        </div>
        {urls.length > 0 && (
          <ul className="mt-2 space-y-1.5">
            {urls.map((u) => (
              <li key={u} className="flex items-center gap-2 rounded-xl border border-[#e3ebe7] bg-white px-3 py-2">
                <span className="flex-1 text-xs truncate" dir="ltr">
                  {u}
                </span>
                <button className="btn-soft py-1.5 px-2.5 text-xs" onClick={() => check(u)} disabled={!!busy}>
                  {busy === u ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />} فحص وتحديث
                </button>
                <button className="btn-icon w-8 h-8 text-red-600" onClick={() => removeUrl(u)} aria-label="حذف الرابط">
                  <Trash2 size={14} />
                </button>
              </li>
            ))}
          </ul>
        )}
        <p className="text-[11px] text-ink-mute mt-1">لا يوجد أي فحص تلقائي — التحديث يتم فقط عند ضغطك على الزر.</p>
      </div>

      <div>
        <div className="label">الحزم المثبتة ({packs.length})</div>
        {packs.length === 0 ? (
          <p className="text-xs text-ink-mute">لا توجد حزم مستوردة.</p>
        ) : (
          <ul className="space-y-1.5">
            {packs.map((p) => (
              <li key={p.id} className="flex items-center gap-3 rounded-xl border border-[#e3ebe7] bg-white px-3 py-2">
                <Package size={18} className="text-brand shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-bold truncate">
                    {p.name} {p.version && <span className="text-[10px] text-ink-mute">v{p.version}</span>}
                  </div>
                  <div className="text-[11px] text-ink-mute">
                    {p.count} قالب • {formatBytes(p.size)} • {p.source === 'url' ? 'من رابط' : p.source.toUpperCase()} • {formatDate(p.importedAt)}
                  </div>
                </div>
                <button className="btn-icon w-8 h-8 text-red-600" onClick={() => del(p)} aria-label="حذف الحزمة">
                  <Trash2 size={15} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
