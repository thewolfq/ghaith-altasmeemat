import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { AlertTriangle, X, Replace } from 'lucide-react';

const ConfirmCtx = createContext(async () => false);

/** نافذة تأكيد عامة؛ تدعم التأكيد المزدوج وكتابة كلمة تفعيل (مثل "مسح") وسرد العناصر المتأثرة */
export function ConfirmDialog({ open, title, message, items = [], confirmText = 'تأكيد', cancelText = 'إلغاء', danger = false, typeWord = '', doubleConfirm = false, extra = null, onConfirm, onCancel, onDismiss }) {
  const dismiss = onDismiss || onCancel;
  const [typed, setTyped] = useState('');
  const [stage, setStage] = useState(1);
  useEffect(() => {
    if (open) {
      setTyped('');
      setStage(1);
    }
  }, [open]);
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && dismiss?.();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, dismiss]);
  if (!open) return null;
  const needsWord = !!typeWord;
  const ready = !needsWord || typed.trim() === typeWord;
  const handleConfirm = () => {
    if (doubleConfirm && stage === 1) {
      setStage(2);
      return;
    }
    onConfirm?.();
  };
  return (
    <div className="fixed inset-0 z-[80] flex items-end sm:items-center justify-center bg-black/40 p-3" role="dialog" aria-modal="true" onClick={dismiss}>
      <div className="fade-up card-ui w-full max-w-md p-5 max-h-[88vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start gap-3">
          <div className={`rounded-xl p-2 ${danger ? 'bg-red-50 text-red-600' : 'bg-brand-soft text-brand'}`}>
            <AlertTriangle size={20} />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-ink text-base">{stage === 2 ? 'تأكيد نهائي' : title}</h3>
            <p className="muted mt-1 leading-7 whitespace-pre-line">{stage === 2 ? 'هل أنت متأكد تماماً؟ لا يمكن التراجع عن هذه العملية.' : message}</p>
          </div>
          <button className="btn-icon w-8 h-8" onClick={dismiss} aria-label="إغلاق">
            <X size={16} />
          </button>
        </div>
        {items.length > 0 && (
          <ul className="mt-3 max-h-40 overflow-y-auto rounded-xl bg-canvas p-3 text-sm text-ink-soft space-y-1">
            {items.slice(0, 60).map((it, i) => (
              <li key={i} className="flex justify-between gap-2">
                <span className="truncate">• {it.label || it}</span>
                {it.size != null && <span className="text-ink-mute shrink-0">{it.size}</span>}
              </li>
            ))}
            {items.length > 60 && <li className="text-ink-mute">… و{items.length - 60} عنصر آخر</li>}
          </ul>
        )}
        {extra}
        {needsWord && stage === (doubleConfirm ? 2 : 1) && (
          <div className="mt-4">
            <label className="label">اكتب كلمة «{typeWord}» للتفعيل</label>
            <input className="input" value={typed} onChange={(e) => setTyped(e.target.value)} placeholder={typeWord} autoFocus />
          </div>
        )}
        <div className="mt-5 flex gap-2 justify-end">
          <button className="btn-ghost" onClick={onCancel}>
            {cancelText}
          </button>
          <button className={danger ? 'btn-danger' : 'btn-primary'} disabled={(stage === (doubleConfirm ? 2 : 1) && !ready)} onClick={handleConfirm}>
            {doubleConfirm && stage === 1 ? 'متابعة' : confirmText}
          </button>
        </div>
      </div>
    </div>
  );
}

export function ConfirmProvider({ children }) {
  const [state, setState] = useState(null);
  const confirm = useCallback(
    (opts) =>
      new Promise((resolve) => {
        setState({ ...opts, resolve });
      }),
    [],
  );
  const close = (v) => {
    state?.resolve(v);
    setState(null);
  };
  return (
    <ConfirmCtx.Provider value={confirm}>
      {children}
      <ConfirmDialog open={!!state} {...(state || {})} onConfirm={() => close(true)} onCancel={() => close(false)} onDismiss={() => close(null)} />
    </ConfirmCtx.Provider>
  );
}

export function useConfirm() {
  return useContext(ConfirmCtx);
}

/** نافذة بلوغ الحد [F3-S8]: رسالة واضحة + خيار استبدال عنصر قائم أو الذهاب للإدارة — بلا إسقاط صامت */
export function LimitDialog({ open, kind, limit, items = [], onReplace, onManage, onCancel }) {
  const [selected, setSelected] = useState(null);
  useEffect(() => {
    if (open) setSelected(null);
  }, [open]);
  if (!open) return null;
  const name = kind === 'favorites' ? 'المفضلة' : 'الدعوات المحفوظة';
  return (
    <div className="fixed inset-0 z-[80] flex items-end sm:items-center justify-center bg-black/40 p-3" role="dialog" aria-modal="true" onClick={onCancel}>
      <div className="fade-up card-ui w-full max-w-md p-5 max-h-[88vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <h3 className="font-bold text-ink">بلغت {name} الحد الأقصى ({limit})</h3>
        <p className="muted mt-1 leading-7">لن يُحذف أي شيء تلقائياً. اختر عنصراً ليُستبدل بالجديد، أو افتح الإدارة لحذف ما لا تحتاجه.</p>
        <div className="mt-3 flex-1 overflow-y-auto rounded-xl border border-[#e3ebe7] divide-y divide-[#eef3f1]">
          {items.map((it) => (
            <label key={it.id} className={`flex items-center gap-3 px-3 py-2.5 cursor-pointer text-sm ${selected === it.id ? 'bg-brand-soft' : ''}`}>
              <input type="radio" name="limit-replace" checked={selected === it.id} onChange={() => setSelected(it.id)} className="accent-[#0f766e]" />
              <span className="flex-1 truncate">{it.label}</span>
              <span className="text-ink-mute text-xs">{it.date}</span>
            </label>
          ))}
        </div>
        <div className="mt-4 flex flex-wrap gap-2 justify-end">
          <button className="btn-ghost" onClick={onCancel}>
            إلغاء
          </button>
          <button className="btn-outline" onClick={onManage}>
            إدارة {name}
          </button>
          <button className="btn-primary" disabled={!selected} onClick={() => onReplace(selected)}>
            <Replace size={16} /> استبدال المحدد
          </button>
        </div>
      </div>
    </div>
  );
}
