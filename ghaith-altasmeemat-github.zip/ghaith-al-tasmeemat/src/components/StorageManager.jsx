import React, { useState } from 'react';
import { ChevronDown, Trash2, Loader2, Lock } from 'lucide-react';
import { CATEGORY_LABELS, deleteStorageItems } from '../lib/assets.js';
import { formatBytes } from '../lib/db.js';
import { useConfirm } from './ConfirmDialog.jsx';
import { useToast } from './Toast.jsx';

const ORDER = ['invitations', 'images', 'favorites', 'templates', 'packs', 'fonts', 'ornaments', 'cache', 'settings'];

export function StorageBar({ total, budget }) {
  const pct = Math.min(100, (total / budget) * 100);
  const color = pct > 90 ? 'bg-red-500' : pct > 70 ? 'bg-gold' : 'bg-brand';
  return (
    <div>
      <div className="flex items-end justify-between mb-1.5">
        <div>
          <div className="text-2xl font-extrabold text-ink">{formatBytes(total)}</div>
          <div className="text-xs text-ink-mute">مستخدم من {formatBytes(budget)}</div>
        </div>
        <div className="text-left">
          <div className="text-sm font-bold text-brand-dark">{formatBytes(Math.max(0, budget - total))}</div>
          <div className="text-xs text-ink-mute">متبقٍ</div>
        </div>
      </div>
      <div className="h-3 rounded-full bg-canvas-deep overflow-hidden" role="progressbar" aria-valuenow={Math.round(pct)} aria-valuemin={0} aria-valuemax={100}>
        <div className={`h-full ${color} transition-all`} style={{ width: `${Math.max(pct, 1)}%` }} />
      </div>
    </div>
  );
}

/** إدارة التخزين: حجم كل عنصر + حذف فردي/متعدد/فئة كاملة مع تأكيد مزدوج للجماعي */
export default function StorageManager({ data, onChanged }) {
  const [open, setOpen] = useState({});
  const [sel, setSel] = useState({});
  const [busy, setBusy] = useState(null);
  const confirm = useConfirm();
  const toast = useToast();

  const run = async (cat, items, bulk) => {
    const hasCore = items.some((i) => i.core);
    const ok = await confirm({
      title: bulk ? `حذف ${items.length} عنصر من «${CATEGORY_LABELS[cat]}»؟` : 'حذف هذا العنصر؟',
      message: `${hasCore ? 'تنبيه: بعض العناصر أساسية مدمجة — يمكن إعادتها لاحقاً بزر «استعادة الأصول الأساسية المفقودة». ' : ''}${cat === 'templates' || cat === 'packs' ? 'الدعوات المحفوظة لن تتأثر لأنها تحمل نسختها الكاملة.' : 'هذا الإجراء نهائي.'}`,
      items: items.slice(0, 60).map((i) => ({ label: i.label, size: formatBytes(i.size) })).concat(items.length > 60 ? [{ label: `و${items.length - 60} عنصراً آخر`, size: '' }] : []),
      confirmText: 'حذف',
      danger: true,
      doubleConfirm: bulk,
    });
    if (!ok) return;
    setBusy(cat);
    try {
      await deleteStorageItems(
        cat,
        items.map((i) => i.id),
      );
      setSel((s) => ({ ...s, [cat]: [] }));
      toast(`تم حذف ${items.length} عنصر`);
      onChanged();
    } catch (e) {
      toast(`تعذر الحذف: ${e.message}`, 'error');
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-2.5">
      {ORDER.filter((c) => data.cats[c]).map((cat) => {
        const items = data.cats[cat];
        const size = items.reduce((s, i) => s + (i.size || 0), 0);
        const locked = cat === 'settings';
        const selected = sel[cat] || [];
        const isOpen = !!open[cat];
        const toggleSel = (id) => setSel((s) => ({ ...s, [cat]: selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id] }));
        return (
          <div key={cat} className="card-ui overflow-hidden">
            <button className="w-full flex items-center gap-3 px-4 py-3" onClick={() => setOpen((o) => ({ ...o, [cat]: !isOpen }))} aria-expanded={isOpen}>
              <div className="flex-1 text-right">
                <div className="font-bold text-sm text-ink">{CATEGORY_LABELS[cat]}</div>
                <div className="text-[11px] text-ink-mute">{items.length} عنصر</div>
              </div>
              <span className="text-sm font-bold text-brand-dark">{formatBytes(size)}</span>
              <ChevronDown size={18} className={`text-ink-mute transition ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            {isOpen && (
              <div className="border-t border-[#eef3f1]">
                {locked ? (
                  <div className="px-4 py-3 text-xs text-ink-mute flex items-center gap-2">
                    <Lock size={14} /> {items[0]?.label} — {formatBytes(items[0]?.size || 0)}. تُمسح فقط بإعادة الضبط الشامل أو من قسم المفاتيح.
                  </div>
                ) : items.length === 0 ? (
                  <div className="px-4 py-3 text-xs text-ink-mute">لا توجد عناصر.</div>
                ) : (
                  <>
                    <div className="flex flex-wrap items-center gap-2 px-4 py-2 bg-canvas/60">
                      <label className="flex items-center gap-1.5 text-xs font-semibold">
                        <input type="checkbox" className="accent-[#0f766e] w-4 h-4" checked={selected.length === items.length} onChange={(e) => setSel((s) => ({ ...s, [cat]: e.target.checked ? items.map((i) => i.id) : [] }))} />
                        تحديد الكل
                      </label>
                      <span className="flex-1" />
                      <button className="btn-outline py-1.5 px-2.5 text-xs" disabled={!selected.length || !!busy} onClick={() => run(cat, items.filter((i) => selected.includes(i.id)), selected.length > 1)}>
                        <Trash2 size={13} /> حذف المحدد ({selected.length})
                      </button>
                      <button className="btn-danger py-1.5 px-2.5 text-xs" disabled={!!busy} onClick={() => run(cat, items, true)}>
                        {busy === cat ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />} حذف الفئة كاملة
                      </button>
                    </div>
                    <ul className="max-h-80 overflow-y-auto divide-y divide-[#f0f4f2]">
                      {items.map((i) => (
                        <li key={i.id} className="flex items-center gap-3 px-4 py-2">
                          <input type="checkbox" className="accent-[#0f766e] w-4 h-4 shrink-0" checked={selected.includes(i.id)} onChange={() => toggleSel(i.id)} aria-label={`تحديد ${i.label}`} />
                          <div className="flex-1 min-w-0">
                            <div className="text-[13px] text-ink truncate">{i.label}</div>
                            <div className="text-[10px] text-ink-mute">
                              {i.sub}
                              {i.core ? ' • أساسي' : ''}
                            </div>
                          </div>
                          <span className="text-xs font-semibold text-ink-soft whitespace-nowrap">{formatBytes(i.size)}</span>
                          <button className="btn-icon w-8 h-8 text-red-600" onClick={() => run(cat, [i], false)} disabled={!!busy} aria-label={`حذف ${i.label}`}>
                            <Trash2 size={14} />
                          </button>
                        </li>
                      ))}
                    </ul>
                  </>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
