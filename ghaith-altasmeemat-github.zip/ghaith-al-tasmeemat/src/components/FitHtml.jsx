import { useLayoutEffect, useRef } from 'react';
import { layoutMonograms } from '../lib/monograms.js';

const supportsZoom = typeof CSS !== 'undefined' && CSS.supports && CSS.supports('zoom', '0.5');

export function FitHtml({ html, className = '', fitHeight = false }) {
  const host = useRef(null);
  useLayoutEffect(() => {
    const el = host.current;
    if (!el) return undefined;
    let raf = 0, lastW = 0, lastH = 0, alive = true;
    const fit = () => {
      const target = el.querySelector('.tpl-scope');
      if (!target) return;
      target.style.zoom = ''; target.style.transform = ''; target.style.width = '2400px';
      let left = Infinity, right = -Infinity, top = Infinity, bottom = -Infinity;
      for (const node of target.querySelectorAll('*')) {
        if (node.tagName === 'STYLE' || (node instanceof SVGElement && node.tagName !== 'svg')) continue;
        const r = node.getBoundingClientRect();
        if (!r.width || !r.height) continue;
        if (r.left < left) left = r.left; if (r.right > right) right = r.right;
        if (r.top < top) top = r.top; if (r.bottom > bottom) bottom = r.bottom;
      }
      if (!isFinite(left)) { target.style.width = ''; return; }
      const w = right - left, h = bottom - top;
      let s = Math.min(1, el.clientWidth / w);
      if (fitHeight && el.clientHeight) s = Math.min(s, el.clientHeight / h);
      s = Math.max(0.05, s);
      if (supportsZoom) { target.style.zoom = String(s); target.style.width = s < 1 ? `${el.clientWidth / s}px` : ''; }
      else {
        target.style.width = '2400px'; target.style.transformOrigin = 'top center'; target.style.transform = `scale(${s})`;
        el.style.height = fitHeight && el.clientHeight ? '' : `${Math.round(h * s)}px`;
      }
    };
    const run = () => { layoutMonograms(el); fit(); };
    const schedule = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => { if (alive) run(); }); };
    schedule();
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver((entries) => {
      const r = entries[0]?.contentRect;
      if (!r) return schedule();
      if (Math.abs(r.width - lastW) < 1 && Math.abs(r.height - lastH) < 1) return;
      lastW = r.width; lastH = r.height; schedule();
    }) : null;
    ro?.observe(el);
    document.fonts?.ready?.then(schedule).catch(() => {});
    const tm = setTimeout(schedule, 1200);
    return () => { alive = false; cancelAnimationFrame(raf); clearTimeout(tm); ro?.disconnect(); };
  }, [html, fitHeight]);
  return <div ref={host} className={className} dangerouslySetInnerHTML={{ __html: html }} />;
}
