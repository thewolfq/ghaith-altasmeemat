import { useLayoutEffect, useRef } from 'react';

// يعرض HTML القالب ويصغّره (zoom) ليتّسع للحاوية — لأن القوالب المصمَّمة بمقاسات ثابتة (540×960 مثلاً)
// أكبر من البطاقات وشاشة المعاينة. القوالب البسيطة بلا .tpl-scope لا تتأثر.
export function FitHtml({ html, className = '', fitHeight = false }) {
  const host = useRef(null);
  useLayoutEffect(() => {
    const el = host.current;
    if (!el) return undefined;
    const fit = () => {
      const target = el.querySelector('.tpl-scope');
      if (!target) return;
      target.style.zoom = '1';
      target.style.width = '2400px'; // قياس المقاس الطبيعي بلا ضغط من الحاوية
      let left = Infinity, right = -Infinity, top = Infinity, bottom = -Infinity;
      for (const node of target.querySelectorAll('*')) {
        if (node.tagName === 'STYLE') continue;
        const r = node.getBoundingClientRect();
        if (!r.width || !r.height) continue;
        left = Math.min(left, r.left); right = Math.max(right, r.right);
        top = Math.min(top, r.top); bottom = Math.max(bottom, r.bottom);
      }
      if (!isFinite(left)) { target.style.width = ''; return; }
      const w = right - left, h = bottom - top;
      let s = Math.min(1, el.clientWidth / w);
      if (fitHeight && el.clientHeight) s = Math.min(s, el.clientHeight / h);
      s = Math.max(0.05, s);
      target.style.zoom = String(s);
      target.style.width = s < 1 ? `${el.clientWidth / s}px` : '';
    };
    fit();
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(fit) : null;
    ro?.observe(el);
    return () => ro?.disconnect();
  }, [html, fitHeight]);
  return <div ref={host} className={className} dangerouslySetInnerHTML={{ __html: html }} />;
}
