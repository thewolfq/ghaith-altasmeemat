import React, { useEffect, useMemo, useRef, useState } from 'react';
import { composeTemplate, initialStateFor } from '../lib/compose.js';
import { ensureMonoMetrics } from '../lib/monograms.js';
import { useOrnamentSvgs } from '../lib/hooks.js';
import { CARD_W, CARD_H } from '../lib/templateUtils.js';

/**
 * يعرض القالب المنقّى بمقاسه الأساسي 540×960 ملائماً للمساحة المتاحة.
 * fit="width": العرض يحدد الارتفاع (9:16). fit="contain": يملأ الحاوية مع الحفاظ على النسبة.
 * lazy: تُجهَّز المعاينة عند اقترابها من الظهور فقط.
 */
export default function FitHtml({ template, state = null, lazy = false, replayKey = 0, fit = 'width', className = '', noAnim = false, rounded = true }) {
  const hostRef = useRef(null);
  const [box, setBox] = useState({ w: 0, h: 0 });
  const [visible, setVisible] = useState(!lazy);
  const [metricsTick, setMetricsTick] = useState(0);
  const ornamentSvgs = useOrnamentSvgs();

  useEffect(() => {
    const el = hostRef.current;
    if (!el) return undefined;
    const ro = new ResizeObserver(([entry]) => {
      const r = entry.contentRect;
      setBox({ w: r.width, h: r.height });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    if (!lazy || visible) return undefined;
    const el = hostRef.current;
    if (!el) return undefined;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setVisible(true);
          io.disconnect();
        }
      },
      { rootMargin: '320px 0px' },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [lazy, visible]);

  const effectiveState = useMemo(() => state || (template ? initialStateFor(template) : null), [state, template]);
  const mono = effectiveState?.mono;
  const monoKey = mono ? `${mono.family}|${mono.a}|${mono.b}` : '';

  useEffect(() => {
    let alive = true;
    if (mono && visible) {
      ensureMonoMetrics(mono).then((changed) => {
        if (alive && changed) setMetricsTick((t) => t + 1);
      });
    }
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [monoKey, visible]);

  const composed = useMemo(() => {
    if (!template || !visible) return null;
    try {
      return composeTemplate(template, effectiveState, { ornamentSvgs, noAnim });
    } catch {
      return null;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [template, effectiveState, ornamentSvgs, visible, metricsTick, noAnim]);

  const scale = fit === 'contain' ? Math.min(box.w / CARD_W, box.h / CARD_H) || 0 : box.w / CARD_W || 0;
  const top = fit === 'contain' ? Math.max(0, (box.h - CARD_H * scale) / 2) : 0;
  const hostStyle = fit === 'width' ? { aspectRatio: `${CARD_W} / ${CARD_H}` } : {};

  return (
    <div ref={hostRef} className={`fit-host ${rounded ? 'rounded-xl' : ''} ${className}`} style={hostStyle}>
      {!composed && <div className="absolute inset-0 skeleton" />}
      {composed && scale > 0 && (
        <div
          key={replayKey}
          className="fit-stage"
          style={{ width: CARD_W, height: CARD_H, top, transform: `translateX(-50%) scale(${scale})`, pointerEvents: 'none' }}
          aria-hidden="true"
        >
          <style dangerouslySetInnerHTML={{ __html: composed.css }} />
          <div dangerouslySetInnerHTML={{ __html: composed.html }} />
        </div>
      )}
    </div>
  );
}
