import React, { useState } from 'react';
import { Image as ImageIcon, FileText, Film, Loader2 } from 'lucide-react';
import { exportPng, exportPdf } from '../lib/exportUtils.js';
import { useToast } from './Toast.jsx';

/** شريط التصدير المحلي: PNG 2x/3x، PDF، MP4 (فرع الفيديو). حفظ على الجهاز فقط — لا مشاركة ولا QR. */
export default function ExportBar({ template, getState, title, onVideo, compact = false }) {
  const [busy, setBusy] = useState(null);
  const toast = useToast();
  const run = async (kind, fn) => {
    setBusy(kind);
    try {
      const res = await fn();
      toast(`تم الحفظ محلياً: ${res.location}`);
    } catch (e) {
      toast(`تعذر التصدير: ${e.message || 'خطأ غير معروف'}`, 'error');
    } finally {
      setBusy(null);
    }
  };
  const btn = compact ? 'btn-outline px-3 py-2 text-xs' : 'btn-outline text-sm';
  return (
    <div className="flex flex-wrap gap-2">
      <button className={btn} disabled={!!busy} onClick={() => run('png2', () => exportPng(template, getState(), { scale: 2, title }))}>
        {busy === 'png2' ? <Loader2 size={15} className="animate-spin" /> : <ImageIcon size={15} />} PNG 2x
      </button>
      <button className={btn} disabled={!!busy} onClick={() => run('png3', () => exportPng(template, getState(), { scale: 3, title }))}>
        {busy === 'png3' ? <Loader2 size={15} className="animate-spin" /> : <ImageIcon size={15} />} PNG 3x
      </button>
      <button className={btn} disabled={!!busy} onClick={() => run('pdf', () => exportPdf(template, getState(), { title }))}>
        {busy === 'pdf' ? <Loader2 size={15} className="animate-spin" /> : <FileText size={15} />} PDF
      </button>
      {onVideo && (
        <button className={btn} disabled={!!busy} onClick={onVideo}>
          <Film size={15} /> فيديو MP4
        </button>
      )}
    </div>
  );
}
