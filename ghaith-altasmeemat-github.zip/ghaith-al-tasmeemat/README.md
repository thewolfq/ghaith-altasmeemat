# غيث التصميمات
تطبيق ويب تقدمي (PWA) ومشروع هجين عبر Capacitor لإنشاء دعوات عربية. مبني باستخدام React وVite وFirebase Authentication (Google فقط) وDexie/IndexedDB وTailwind CSS. يتضمن Web App Manifest وخدمة Service Worker لتخزين واجهة التطبيق الأساسية مؤقتاً واستخدامها عند انقطاع الاتصال.

## المتطلبات والإعداد
- Node.js 20+ ومشروع Firebase مع تفعيل Authentication → Google وإضافة نطاق الموقع المعتمد.
- انسخ `.env.example` إلى `.env.local` وأدخل قيم Firebase Web App، ثم:
```bash
npm install
npm run dev
```
التطبيق لا يسمح بتجاوز شاشة الدخول. دون إعداد Firebase يظهر تنبيه وتبقى عملية الدخول معطلة.

## Gemini الآمن
لا يوجد حقل مفتاح API في الواجهة ولا يُرسل المفتاح إليها. الدالة callable في `functions/` تتطلب Firebase Auth، وتستقبل المفتاح كسِرّ خادمي. في حال عدم نشرها يعمل وضع محاكاة محلي موضّح للمستخدم.
```bash
cd functions && npm install
firebase functions:secrets:set GEMINI_API_KEY
cd ..
firebase deploy --only functions:generateInvitationTemplates
```
أدخل المفتاح في المطالبة التفاعلية فقط، لا تضعه في الواجهة أو Git. وحّد منطقة الدالة مع `VITE_FIREBASE_FUNCTIONS_REGION`.

## Android / Capacitor
```bash
npm install
npx cap add android
# ضع google-services.json في android/app/ واضبط OAuth client ID وبصمات SHA-1/SHA-256 في Firebase
npm run cap:sync
npm run cap:android
```
يلزم إعداد Firebase Android وOAuth قبل بناء APK. تسجيل الدخول الأصلي يستخدم `@capacitor-firebase/authentication`.

## التخزين
IndexedDB عبر Dexie. حد أقصى 50 قالباً مفضلاً و30 دعوة محفوظة. البيانات محلية على الجهاز ولا تُرفع إلى Firebase.

## التصاميم الإبداعية وعدم التكرار
- `src/lib/creative.js`: 4 هياكل (قوس الصورة، قوس كحلي، سماء وسحب، حلقة الذهب) × 9 لوحات × 6 زخارف × 6 أزواج خطوط. تُحفظ توقيعات ما عُرض (localStorage: gh_seen_designs) فلا تتكرر عند «تحديث القوالب».
- مكان الصورة: `data-image="photo"` يظهر في شاشة التعبئة كحقل رفع صورة، وتُحفظ داخل الدعوة.
- «صمّم على غرار صورة»: دالة `designFromReference` (تتطلب نشر الدوال وتفعيل Gemini).


## القوالب الفاخرة المتحركة (luxury.js)
- 6 هياكل × 8 لوحات × 5 أنماط زخرفة، تظهر عناصرها بالتتابع كما في الدعوات المرجعية، مع زر «إعادة التشغيل» في شاشة تعبئة الدعوة.
- المونوغرام: `monograms.js` يحوّل حروف المستخدم (شامة، ب) إلى مسارات SVG، ويمكن اختيار أول حرف من الاسم أو حرف مخصص. لإضافة حرف جديد أضف مساره إلى `VEC`.
- خانة `data-mono="1"` في أي قالب تُملأ تلقائياً. معاينات القوائم ثابتة والحركة في معاينة الدعوة فقط.
