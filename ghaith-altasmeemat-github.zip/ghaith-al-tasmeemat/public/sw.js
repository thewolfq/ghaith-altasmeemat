/* Service Worker — غيث التصميمات 2.0.0 [F2-S12]
   - قشرة التطبيق + الأيقونة + manifest مخزنة مسبقاً.
   - التنقّل: network-first ثم fallback للكاش.
   - أصول البناء الثابتة: cache-first بحد 90 مدخلاً.
   - الخطوط: تُخزن بعد أول تحميل ناجح وتبقى متاحة دون اتصال.
   - لا يتم التقاط أي طلب خارجي (مثل مزود الذكاء الاصطناعي). */
const VERSION = 'v2.0.0';
const SHELL = `ghaith-shell-${VERSION}`;
const ASSETS = `ghaith-assets-${VERSION}`;
const FONTS = `ghaith-fonts-${VERSION}`;
const MAX_ASSETS = 90;
const SHELL_URLS = ['./', './index.html', './icon.svg', './manifest.webmanifest'];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(SHELL).then((c) => c.addAll(SHELL_URLS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('ghaith-') && ![SHELL, ASSETS, FONTS].includes(k)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

async function trim(cacheName, max) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  for (let i = 0; i < keys.length - max; i++) await cache.delete(keys[i]);
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(SHELL).then((c) => c.put('./index.html', copy));
          return res;
        })
        .catch(() => caches.match('./index.html').then((r) => r || caches.match('./'))),
    );
    return;
  }

  if (url.pathname.includes('/fonts/')) {
    event.respondWith(
      caches.open(FONTS).then((cache) =>
        cache.match(req).then(
          (hit) =>
            hit ||
            fetch(req).then((res) => {
              if (res.ok) cache.put(req, res.clone());
              return res;
            }),
        ),
      ),
    );
    return;
  }

  if (url.pathname.includes('/assets/') || /\.(js|css|svg|webmanifest|woff2)$/.test(url.pathname)) {
    event.respondWith(
      caches.match(req).then(
        (hit) =>
          hit ||
          fetch(req).then((res) => {
            if (res.ok) {
              const copy = res.clone();
              caches.open(ASSETS).then((c) => c.put(req, copy).then(() => trim(ASSETS, MAX_ASSETS)));
            }
            return res;
          }),
      ),
    );
  }
});
