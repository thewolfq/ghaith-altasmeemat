// يضبط مشروع أندرويد بعد `npx cap add android`:
// minSdk 29 (Android 10)، compile/target SDK 35، أذونات التخزين اللازمة لحفظ الملفات في Documents على Android 10،
// وإذن الإنترنت (للميزات السحابية الاختيارية وروابط التحديث اليدوي فقط).
// آمن للتشغيل أكثر من مرة (idempotent).
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const android = path.join(root, 'android');
const MIN_SDK = 29;
const COMPILE_SDK = 35;
const TARGET_SDK = 35;

if (!fs.existsSync(android)) {
  console.error('✖ مجلد android غير موجود. شغّل أولاً: npx cap add android');
  process.exit(1);
}

// 1) variables.gradle
const varsFile = path.join(android, 'variables.gradle');
if (fs.existsSync(varsFile)) {
  let v = fs.readFileSync(varsFile, 'utf8');
  const setVar = (name, val) => {
    const re = new RegExp(`(${name}\\s*=\\s*)\\d+`);
    v = re.test(v) ? v.replace(re, `$1${val}`) : v.replace(/ext\s*\{/, `ext {\n    ${name} = ${val}`);
  };
  setVar('minSdkVersion', MIN_SDK);
  setVar('compileSdkVersion', COMPILE_SDK);
  setVar('targetSdkVersion', TARGET_SDK);
  fs.writeFileSync(varsFile, v);
  console.log(`✔ variables.gradle: minSdk ${MIN_SDK}, compileSdk ${COMPILE_SDK}, targetSdk ${TARGET_SDK}`);
} else {
  console.warn('⚠ لم يُعثر على android/variables.gradle — اضبط القيم يدوياً.');
}

// 2) AndroidManifest.xml
const manifestFile = path.join(android, 'app', 'src', 'main', 'AndroidManifest.xml');
if (fs.existsSync(manifestFile)) {
  let m = fs.readFileSync(manifestFile, 'utf8');
  const perms = [
    '<uses-permission android:name="android.permission.INTERNET" />',
    // حفظ الملفات المصدّرة في Documents على Android 10 فقط؛ من Android 11 فما فوق لا حاجة لإذن لكتابة ملفات التطبيق
    '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />',
    '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />',
    // Android 13+ (API 33+): أذونات الوسائط الدقيقة لاستيراد الصور والصوت (منتقي الملفات يعمل بدونها، لكنها موثّقة حسب المواصفة)
    '<uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />',
    '<uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />',
  ];
  for (const p of perms) {
    const name = p.match(/android:name="([^"]+)"/)[1];
    if (!m.includes(`android:name="${name}"`)) m = m.replace(/<\/manifest>\s*$/, `    ${p}\n</manifest>\n`);
  }
  if (!m.includes('requestLegacyExternalStorage')) m = m.replace(/<application\b/, '<application\n        android:requestLegacyExternalStorage="true"');
  fs.writeFileSync(manifestFile, m);
  console.log('✔ AndroidManifest.xml: INTERNET + تخزين (حتى API 29/32) + READ_MEDIA_IMAGES/AUDIO + requestLegacyExternalStorage');
} else {
  console.warn('⚠ لم يُعثر على AndroidManifest.xml');
}

// 3) اسم التطبيق العربي
const stringsFile = path.join(android, 'app', 'src', 'main', 'res', 'values', 'strings.xml');
if (fs.existsSync(stringsFile)) {
  let s = fs.readFileSync(stringsFile, 'utf8');
  s = s.replace(/(<string name="app_name">)[^<]*(<\/string>)/, '$1غيث التصميمات$2').replace(/(<string name="title_activity_main">)[^<]*(<\/string>)/, '$1غيث التصميمات$2');
  fs.writeFileSync(stringsFile, s);
  console.log('✔ strings.xml: app_name = غيث التصميمات');
}

// 4) رقم الإصدار 2.0.0
const appGradle = path.join(android, 'app', 'build.gradle');
if (fs.existsSync(appGradle)) {
  let g = fs.readFileSync(appGradle, 'utf8');
  g = g.replace(/versionName\s+"[^"]*"/, 'versionName "2.0.0"').replace(/versionCode\s+\d+/, 'versionCode 20000');
  fs.writeFileSync(appGradle, g);
  console.log('✔ build.gradle: versionName 2.0.0 (versionCode 20000)');
}

console.log('\nالتالي: npm run cap:sync ثم npm run cap:android لفتح Android Studio وبناء APK.');
