// يتحقق من أن حجم المشروع القابل للتسليم (بدون node_modules/android) والبناء dist ضمن حد 50MB
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const LIMIT = 50 * 1024 * 1024;
const SKIP = new Set(['node_modules', 'android', '.git', '.vite', 'Unselected files']);

function dirSize(dir, skip = true) {
  let total = 0;
  if (!fs.existsSync(dir)) return 0;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (skip && SKIP.has(e.name)) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) total += dirSize(p, skip);
    else if (e.isFile()) total += fs.statSync(p).size;
  }
  return total;
}

const fmt = (b) => (b > 1048576 ? `${(b / 1048576).toFixed(2)} MB` : `${(b / 1024).toFixed(1)} KB`);
const project = dirSize(root);
const dist = dirSize(path.join(root, 'dist'), false);
const fonts = dirSize(path.join(root, 'public', 'fonts'), false);

console.log(`المشروع (بدون node_modules/android): ${fmt(project)}`);
console.log(`الخطوط المدمجة: ${fmt(fonts)}`);
console.log(`مجلد البناء dist: ${dist ? fmt(dist) : 'غير موجود — شغّل npm run build'}`);
const ok = project <= LIMIT && dist <= LIMIT;
console.log(ok ? '✔ ضمن حد 50MB' : '✖ تجاوز حد 50MB');
process.exit(ok ? 0 : 1);
