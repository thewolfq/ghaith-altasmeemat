/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    screens: {
      xs: '380px',
      sm: '700px',
      lg: '1000px',
      xl: '1260px',
    },
    extend: {
      colors: {
        brand: { DEFAULT: '#0f766e', dark: '#115e59', light: '#ccfbf1', soft: '#e6f4f1' },
        gold: { DEFAULT: '#d6a85f', dark: '#b8893f', light: '#f6ead3' },
        canvas: { DEFAULT: '#f5f8f6', deep: '#eaf1ed' },
        ink: { DEFAULT: '#17302b', soft: '#4b625c', mute: '#7d918b' },
      },
      fontFamily: {
        ui: ['Cairo', 'Tajawal', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        soft: '0 6px 24px -8px rgba(15, 63, 56, 0.18)',
        lift: '0 14px 40px -12px rgba(15, 63, 56, 0.28)',
      },
      borderRadius: { xl2: '1.25rem' },
    },
  },
  plugins: [],
};
