npm install
npm run build
npx cap add android   # مرة واحدة
npx cap sync android
cd android && ./gradlew assembleDebug   # للاختبار
# للإصدار: أنشئ keystore ثم KEYSTORE_PASS=.. KEY_PASS=.. ./gradlew assembleRelease
