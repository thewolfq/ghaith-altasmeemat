# غيث التصميمات — Ghaith Al-Tasmeemat
المطور: عبدالوارث الذيب — الإصدار 1.0.0

## التشغيل
npm install && npm run dev

## البناء والنشر
- الويب: npm run build ثم النشر على Vercel (Output: dist)
- APK: راجع docs/BUILD-APK.md

## الحالة
الأسبوع 1 (إثبات الفكرة): شاشة استكشاف + توليد Gemini + تصدير PNG. بقية الأسابيع قيد التنفيذ.

## البناء على GitHub
راجع docs/GITHUB-GUIDE.md (APK لأندرويد 8-16 + Vercel).
