// html-to-image يعتمد على محرك المتصفح لتشكيل الحروف، فلا حاجة لمعالجة يدوية.
export const waitFonts = () => (document.fonts ? document.fonts.ready : Promise.resolve())
