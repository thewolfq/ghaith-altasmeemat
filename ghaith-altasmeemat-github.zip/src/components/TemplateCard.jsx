export default function TemplateCard({ html, scale = 0.55 }) {
  return (
    <div className="stage" style={{ width: 540 * scale, height: 960 * scale }}>
      <iframe title="preview" sandbox="allow-same-origin" srcDoc={html}
        style={{ width: 540, height: 960, border: 0, transform: `scale(${scale})`, transformOrigin: 'top right' }} />
    </div>
  )
}
