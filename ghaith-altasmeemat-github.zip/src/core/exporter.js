import { toPng } from 'html-to-image'
import { waitFonts } from '../utils/arabic-shaping.js'
// node: عنصر DOM يحوي القالب (داخل iframe نمرر iframe.contentDocument.body)
export async function exportPng(node) {
  await waitFonts()
  return toPng(node, { width: 540, height: 960, pixelRatio: 2, cacheBust: true })
}
