import { FIELDS } from './fields-dictionary.js'
export const FILTERS = {
  occasion: { label: 'المناسبة', options: ['زفاف','خطوبة','عقد قران','مواليد','تخرج','عيد ميلاد','عزاء','دعوة عامة'] },
  hostGender: { label: 'جنس مقدم الدعوة', options: ['ذكر','أنثى'] },
  style: { label: 'الستايل', options: ['كلاسيكي','حديث','شعبي','ملكي','بسيط'] },
  palette: { label: 'لوحة الألوان', options: ['روز جولد','كحلي ذهبي','زمردي','أبيض أسود','دافئ','بارد'] },
  luxury: { label: 'مستوى الفخامة', options: ['بسيط','متوسط','فاخر'] }
}
export function buildPrompt(sel, special = '', errors = []) {
  const lines = Object.entries(sel).filter(([, v]) => v).map(([k, v]) => `- ${FILTERS[k].label}: ${v}`)
  return `أنت مصمم دعوات عربي. أنتج قالب HTML واحداً كاملاً لدعوة مناسبة، وأعد الكود فقط بلا شرح ولا علامات markdown.
قواعد إلزامية:
- المقاس 540px × 960px (عنصر جذر بهذا الحجم)
- لا سكربتات مطلقاً، الخطوط من Google Fonts فقط، الزخارف SVG مدمجة بلا صور خارجية
- الألوان عبر CSS Variables في :root
- كل نص قابل للتعديل داخل عنصر يحمل data-field، والنص بداخله هو القيمة الافتراضية
- أسماء الحقول المسموحة: ${[...new Set(Object.values(FIELDS).flat())].join(', ')}
- استخدم زخرفة SVG للفصل بين الأسماء، لا & ولا ×
- لا تكتب "نجليهما" أو "العريسين"؛ استخدم صيغة محايدة
- الأسماء بحجم 40-50px، هوامش 36px على الأقل، توزيع عمودي متوازن (justify-content: space-between)
- اكتب البيانات الافتراضية بصيغة جنس مقدم الدعوة المختار
${lines.length ? 'الفلاتر:\n' + lines.join('\n') : 'لا فلاتر: اختر ما تراه مناسباً.'}
${special ? 'ملاحظات ذات أولوية عالية: ' + special : ''}
${errors.length ? 'أخطاء المحاولة السابقة يجب إصلاحها:\n- ' + errors.join('\n- ') : ''}`
}
