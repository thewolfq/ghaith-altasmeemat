export const FIELDS = {
  common: ['date_hijri','date_gregorian','time','venue','map_url','note','rsvp_phone','hashtag'],
  wedding: ['host_name','families','bride','groom'],
  newborn: ['baby_name','parents'],
  graduation: ['graduate_name','degree'],
  condolence: ['deceased_name','family_name'],
  birthday: ['person_name','age']
}
