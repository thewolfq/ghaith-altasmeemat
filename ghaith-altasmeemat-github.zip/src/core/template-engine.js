export const readFields = html => {
  const doc = new DOMParser().parseFromString(html, 'text/html')
  return [...doc.querySelectorAll('[data-field]')].map(e => ({ name: e.dataset.field, value: e.textContent.trim() }))
}
export const fillTemplate = (html, values) => {
  const doc = new DOMParser().parseFromString(html, 'text/html')
  doc.querySelectorAll('[data-field]').forEach(e => { if (values[e.dataset.field] != null) e.textContent = values[e.dataset.field] })
  return '<!doctype html>' + doc.documentElement.outerHTML
}
