export function validate(html) {
  const errors = []
  if (!/540\s*px/.test(html) || !/960\s*px/.test(html)) errors.push('المقاس 540×960 غير موجود')
  if (/<script/i.test(html) || /\son\w+\s*=/i.test(html)) errors.push('القالب يحتوي سكربتات')
  if ((html.match(/data-field=/g) || []).length < 3) errors.push('عدد data-field قليل')
  if (!/:root\s*\{/.test(html)) errors.push('لا توجد CSS Variables في :root')
  if (/العريسين/.test(html)) errors.push('صياغة خاطئة: العريسين')
  if (/data-field="(bride|groom)"[^>]*>[^<]*[&×][^<]*</.test(html)) errors.push('رمز & أو × بين الأسماء، استخدم زخرفة SVG')
  return errors
}
export const sanitize = html => html
  .replace(/^\s*```(?:html)?\s*|\s*```\s*$/g, '')
  .replace(/<script[\s\S]*?<\/script>/gi, '')
  .replace(/\son\w+="[^"]*"/gi, '')
