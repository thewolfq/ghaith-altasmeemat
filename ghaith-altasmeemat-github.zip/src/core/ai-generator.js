import { buildPrompt } from './prompt-builder.js'
import { validate, sanitize } from './validator.js'
const MODEL = 'gemini-2.0-flash' // غيّره إذا تغيّر اسم النموذج المتاح
async function call(key, prompt) {
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(key)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
  })
  if (!r.ok) throw new Error('فشل الاتصال بـ Gemini (' + r.status + ')، تحقق من المفتاح')
  const d = await r.json()
  return sanitize(d.candidates?.[0]?.content?.parts?.[0]?.text || '')
}
// محاولة أولى + إعادتان كحد أقصى مع إبلاغ الـ AI بالأخطاء
export async function generateTemplate(key, sel, special) {
  let errors = [], html = ''
  for (let i = 0; i < 3; i++) {
    html = await call(key, buildPrompt(sel, special, errors))
    errors = validate(html)
    if (!errors.length) break
  }
  return { html, errors }
}
