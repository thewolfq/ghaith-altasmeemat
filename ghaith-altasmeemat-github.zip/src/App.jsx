import { useState } from 'react'
import Home from './screens/home.jsx'
import Explore from './screens/explore.jsx'
import About from './screens/about.jsx'
const TABS = [['home','الرئيسية',Home],['explore','استكشاف',Explore],['about','عن البرنامج',About]]
export default function App() {
  const [t, setT] = useState('home'); const Cur = TABS.find(x => x[0] === t)[2]
  return (<>
    <header><img src="./logo.svg" alt=""/><div><b>غيث التصميمات</b><small>عبدالوارث الذيب</small></div></header>
    <main><Cur go={setT} /></main>
    <footer>غيث التصميمات v1.0.0 — عبدالوارث الذيب</footer>
    <nav>{TABS.map(([k, l]) => <button key={k} className={t === k ? 'on' : ''} onClick={() => setT(k)}>{l}</button>)}</nav>
  </>)
}
