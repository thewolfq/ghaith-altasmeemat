import { useState } from 'react'
import { FILTERS } from '../core/prompt-builder.js'
import { generateTemplate } from '../core/ai-generator.js'
import { exportPng } from '../core/exporter.js'
import TemplateCard from '../components/TemplateCard.jsx'
import { store } from '../utils/helpers.js'
export default function Explore() {
  const [sel, setSel] = useState({}), [special, setSpecial] = useState('')
  const [key, setKey] = useState(store.get('gemini_key')), [busy, setBusy] = useState(false)
  const [res, setRes] = useState(null), [err, setErr] = useState(''), [png, setPng] = useState('')
  const run = async () => {
    setBusy(true); setErr(''); setPng('')
    try { store.set('gemini_key', key); setRes(await generateTemplate(key, sel, special)) }
    catch (e) { setErr(e.message) } finally { setBusy(false) }
  }
  const doExport = async () => {
    const f = document.querySelector('.stage iframe')
    try { setPng(await exportPng(f.contentDocument.body)) } catch (e) { setErr('فشل التصدير: ' + e.message) }
  }
  return (<>
    <h2>استكشاف القوالب</h2>
    <input type="password" placeholder="مفتاح Gemini API" value={key} onChange={e => setKey(e.target.value)} />
    {Object.entries(FILTERS).map(([k, f]) => (
      <select key={k} value={sel[k] || ''} onChange={e => setSel({ ...sel, [k]: e.target.value })}>
        <option value="">{f.label} (افتراضي)</option>{f.options.map(o => <option key={o}>{o}</option>)}
      </select>))}
    <textarea maxLength={200} rows={2} placeholder="حالة خاصة (اختياري، 200 حرف)" value={special} onChange={e => setSpecial(e.target.value)} />
    <button className="btn" disabled={busy || !key} onClick={run}>{busy ? 'جارٍ التوليد…' : '✨ تحديث القوالب'}</button>
    {err && <div className="err">{err}</div>}
    {res && <>
      {res.errors.length > 0 && <div className="warn">ملاحظات التحقق: {res.errors.join('، ')}</div>}
      <TemplateCard html={res.html} />
      <button className="btn alt" onClick={doExport}>تصدير PNG (اختبار Arabic shaping)</button>
      {png && <img src={png} alt="الناتج" style={{ width: '100%', marginTop: 12 }} />}
    </>}
  </>)
}
