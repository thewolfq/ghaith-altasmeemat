export default function Home({ go }) {
  return (<><h2>أهلاً بك — عبدالوارث الذيب</h2>
  <button className="btn" onClick={() => go('explore')}>توليد قالب</button></>)
}
